package com.example.chunkinfo;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class ChunkScanner {
    // Edit this list to change what counts as "non natural".
    private static final Set<Block> TARGETS = new HashSet<>(Arrays.asList(
            Blocks.ENCHANTING_TABLE, Blocks.SPAWNER, Blocks.ENDER_CHEST,
            Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL,
            Blocks.CRAFTING_TABLE, Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER,
            Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL,
            Blocks.BEACON, Blocks.BREWING_STAND, Blocks.HOPPER, Blocks.DISPENSER, Blocks.DROPPER,
            Blocks.TNT, Blocks.JUKEBOX, Blocks.NOTE_BLOCK, Blocks.LECTERN,
            Blocks.GRINDSTONE, Blocks.STONECUTTER, Blocks.LOOM, Blocks.CARTOGRAPHY_TABLE,
            Blocks.SMITHING_TABLE, Blocks.FLETCHING_TABLE, Blocks.RESPAWN_ANCHOR,
            Blocks.OBSERVER, Blocks.PISTON, Blocks.STICKY_PISTON,
            Blocks.REPEATER, Blocks.COMPARATOR, Blocks.REDSTONE_LAMP
    ));

    private static boolean isTarget(BlockState st) {
        Block b = st.getBlock();
        return TARGETS.contains(b) || b instanceof BedBlock || b instanceof ShulkerBoxBlock;
    }

    public static ScanResult scan(LevelChunk chunk, int cx, int cz) {
        ScanResult r = new ScanResult(cx, cz);
        LevelChunkSection[] sections = chunk.getSections();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection sec = sections[i];
            if (sec == null || sec.hasOnlyAir() || !sec.maybeHas(ChunkScanner::isTarget)) continue;
            int baseY = chunk.getMinY() + i * 16;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState st = sec.getBlockState(x, y, z);
                        if (!isTarget(st)) continue;
                        r.total++;
                        r.counts.merge(st.getBlock(), 1, Integer::sum);
                        if (r.samples.size() < 5) {
                            r.samples.add(new BlockPos(cx * 16 + x, baseY + y, cz * 16 + z));
                        }
                    }
                }
            }
        }
        return r;
    }
}
