package com.example.chunkinfo;

import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class ChunkScanner {
    // Edit this list to change what counts as "non natural".
    private static final Set<Block> TARGETS = new HashSet<>(Arrays.asList(
            Blocks.ENCHANTING_TABLE, Blocks.SPAWNER, Blocks.ENDER_CHEST,
            Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL,
            Blocks.CRAFTING_TABLE, Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER,
            Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL,
            Blocks.BEACON, Blocks.BREWING_STAND, Blocks.HOPPER, Blocks.DISPENSER, Blocks.DROPPER,
            Blocks.TNT, Blocks.JUKEBOX, Blocks.NOTE_BLOCK, Blocks.LECTERN,
            Blocks.GRINDSTONE, Blocks.STONECUTTER, Blocks.LOOM, Blocks.CARTOGRAPHY_TABLE,
            Blocks.SMITHING_TABLE, Blocks.FLETCHING_TABLE, Blocks.RESPAWN_ANCHOR,
            Blocks.OBSERVER, Blocks.PISTON, Blocks.STICKY_PISTON,
            Blocks.REPEATER, Blocks.COMPARATOR, Blocks.REDSTONE_LAMP
    ));

    private static boolean isTarget(BlockState st) {
        Block b = st.getBlock();
        return TARGETS.contains(b) || b instanceof BedBlock || b instanceof ShulkerBoxBlock;
    }

    public static ScanResult scan(WorldChunk chunk) {
        ScanResult r = new ScanResult(chunk.getPos());
        ChunkSection[] sections = chunk.getSectionArray();
        for (int i = 0; i < sections.length; i++) {
            ChunkSection sec = sections[i];
            if (sec == null || sec.isEmpty() || !sec.hasAny(ChunkScanner::isTarget)) continue;
            int baseY = chunk.getBottomY() + i * 16;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState st = sec.getBlockState(x, y, z);
                        if (!isTarget(st)) continue;
                        r.total++;
                        r.counts.merge(st.getBlock(), 1, Integer::sum);
                        if (r.samples.size() < 5) {
                            r.samples.add(new BlockPos(chunk.getPos().getStartX() + x, baseY + y,
                                    chunk.getPos().getStartZ() + z));
                        }
                    }
                }
            }
        }
        return r;
    }
}
