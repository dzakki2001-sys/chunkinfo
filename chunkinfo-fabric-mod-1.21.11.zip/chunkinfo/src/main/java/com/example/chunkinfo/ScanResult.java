package com.example.chunkinfo;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ScanResult {
    public final int cx, cz;
    public final Map<Block, Integer> counts = new HashMap<>();
    public final List<BlockPos> samples = new ArrayList<>();
    public int total;

    public ScanResult(int cx, int cz) {
        this.cx = cx;
        this.cz = cz;
    }
}
