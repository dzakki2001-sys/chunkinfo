package com.example.chunkinfo;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** One HUD panel with two sections: chunk scan result and nearby players. */
public class HudPanel {
    private static final int W = 176;

    private static int TEXT, MUTED, GREEN, ACC, ACC_T;

    private static class Row {
        final boolean header;
        final String left, right;
        final int lc, rc;

        Row(boolean header, String left, String right, int lc, int rc) {
            this.header = header;
            this.left = left;
            this.right = right;
            this.lc = lc;
            this.rc = rc;
        }

        int height() {
            return header ? 14 : 11;
        }
    }

    private static class Hit {
        String name;
        int x, y, z;
        float dist;
    }

    public static void render(DrawContext c, MinecraftClient mc) {
        Settings s = Settings.get();
        if ((!s.panel && !s.radar) || mc.world == null || mc.player == null || mc.options.hudHidden) return;

        boolean mand = s.uiStyle == 0;
        TEXT = mand ? 0xFFE6E9F2 : 0xFFEDEDF5;
        MUTED = mand ? 0xFF8E97AB : 0xFF8B8BA3;
        GREEN = 0xFF4ADE80;
        ACC = s.accentColor();
        ACC_T = mand ? Ui.shade(ACC, 40) : ACC;
        TextRenderer tr = mc.textRenderer;

        List<Row> rows = new ArrayList<>();
        if (s.panel) addScan(rows, s);
        if (s.radar) addPlayers(rows, mc, s);

        int h = 8 + 14 + (mand ? 2 : 0) + 6;
        for (Row r : rows) h += r.height();

        int sw = mc.getWindow().getScaledWidth();
        int x = s.panelPos == 0 ? sw - W - 6 : 6;
        int y = 6;

        if (mand) {
            Ui.bevel(c, x, y, W, h, 0xFF2B3140, 0xFF4C566A, 0xFF161A24, 0xFF0B0D13);
            String title = "Chunk Info";
            c.drawTextWithShadow(tr, title, x + (W - tr.getWidth(title)) / 2, y + 6, 0xFFB8C0D4);
            c.fill(x + 6, y + 17, x + W - 6, y + 18, 0xFF161A24);
            c.fill(x + 6, y + 18, x + W - 6, y + 19, 0xFF4C566A);
            Ui.logo(c, x + 6, y + 3, 2, ACC);
        } else {
            Ui.outlined(c, x, y, W, h, 5, 0xE60C0C13, 0xFF2B2B3F);
            Ui.hfade(c, x + 6, y + 1, W - 12, 1, ACC, 220, 0);
            Ui.logo(c, x + 6, y + 3, 2, ACC);
            c.drawTextWithShadow(tr, "CHUNK INFO", x + 22, y + 7, 0xFFEDEDF5);
        }

        int ry = y + 8 + 14 + (mand ? 2 : 0);
        for (Row row : rows) {
            if (row.header) {
                c.drawTextWithShadow(tr, row.left, x + 8, ry, ACC_T);
                if (mand) {
                    c.fill(x + 8, ry + 10, x + W - 8, ry + 11, 0xFF161A24);
                    c.fill(x + 8, ry + 11, x + W - 8, ry + 12, 0xFF4C566A);
                } else {
                    Ui.hfade(c, x + 8, ry + 10, W - 16, 1, ACC, 160, 0);
                }
            } else {
                int rw = row.right.isEmpty() ? 0 : tr.getWidth(row.right) + 6;
                c.drawTextWithShadow(tr, fit(tr, row.left, W - 16 - rw), x + 8, ry, row.lc);
                if (!row.right.isEmpty()) {
                    c.drawTextWithShadow(tr, row.right, x + W - 8 - tr.getWidth(row.right), ry, row.rc);
                }
            }
            ry += row.height();
        }
    }

    private static void addScan(List<Row> rows, Settings s) {
        ScanResult r = ChunkInfoClient.last;
        rows.add(new Row(true, "CHUNK SCAN", "", 0, 0));
        if (r == null) {
            String msg = ChunkInfoClient.status != null ? ChunkInfoClient.status : "Look at a chunk and press G";
            rows.add(new Row(false, msg, "", MUTED, 0));
            return;
        }
        rows.add(new Row(false, "Chunk " + r.pos.x + ", " + r.pos.z, "", MUTED, 0));
        if (r.total == 0) {
            rows.add(new Row(false, "Clean - nothing found", "", GREEN, 0));
            return;
        }
        rows.add(new Row(false, r.total + (r.total == 1 ? " crafted block" : " crafted blocks"), "", ACC_T, 0));
        List<Map.Entry<Block, Integer>> list = new ArrayList<>(r.counts.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        int shown = 0;
        for (Map.Entry<Block, Integer> e : list) {
            if (shown++ >= 6) break;
            rows.add(new Row(false, e.getKey().getName().getString(), "x" + e.getValue(), TEXT, ACC_T));
        }
        if (list.size() > 6) rows.add(new Row(false, "+" + (list.size() - 6) + " more types", "", MUTED, 0));
        if (s.showCoords && !r.samples.isEmpty()) {
            rows.add(new Row(false, "Found at", "", MUTED, 0));
            for (BlockPos p : r.samples) {
                rows.add(new Row(false, p.getX() + " " + p.getY() + " " + p.getZ(), "", TEXT, 0));
            }
        }
    }

    private static void addPlayers(List<Row> rows, MinecraftClient mc, Settings s) {
        double range = s.radarChunks * 16.0;
        List<Hit> hits = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isInvisible()) continue;
            float d = mc.player.distanceTo(p);
            if (d > range) continue;
            Hit h = new Hit();
            h.name = p.getName().getString();
            h.x = p.getBlockX();
            h.y = p.getBlockY();
            h.z = p.getBlockZ();
            h.dist = d;
            hits.add(h);
        }
        hits.sort((a, b) -> Float.compare(a.dist, b.dist));

        rows.add(new Row(true, "PLAYERS (" + hits.size() + ")", "", 0, 0));
        if (hits.isEmpty()) {
            rows.add(new Row(false, "None within " + s.radarChunks + " chunks", "", MUTED, 0));
            return;
        }
        int shown = Math.min(hits.size(), Math.max(1, s.radarMax));
        for (int i = 0; i < shown; i++) {
            Hit hit = hits.get(i);
            rows.add(new Row(false, hit.name, Math.round(hit.dist) + "m", TEXT, ACC_T));
            rows.add(new Row(false, hit.x + "  " + hit.y + "  " + hit.z, "", MUTED, 0));
        }
        if (hits.size() > shown) rows.add(new Row(false, "+" + (hits.size() - shown) + " more", "", MUTED, 0));
    }

    private static String fit(TextRenderer tr, String s, int max) {
        if (tr.getWidth(s) <= max) return s;
        while (s.length() > 1 && tr.getWidth(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
