package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class SettingsScreen extends Screen {
    // Neon style colours
    private static final int BG = 0xF2101018, SIDE = 0xFF0C0C13, SURF = 0xFF171722, SURF_H = 0xFF20202F,
            LINE = 0xFF2B2B3F, OFF = 0xFF34344A, GREEN = 0xFF4ADE80, AMBER = 0xFFFBBF24;
    // Mandala style colours
    private static final int M_PANEL = 0xFF2B3140, M_LIGHT = 0xFF4C566A, M_DARK = 0xFF161A24, M_BORDER = 0xFF0B0D13,
            M_SLOT = 0xFF1E2330, M_SLOT_H = 0xFF272E3F, M_SLOT_DK = 0xFF12151D, M_SLOT_LT = 0xFF3A4357,
            M_WELL = 0xFF10131A;
    private static final String[] TABS = {"Scan", "Border", "Panel", "Players", "Blocks", "Keys"};

    private int tab = 0, blockPage = 0, accent;
    private boolean prevY, leftDown, clicked, dirty, pendingClick, mand;
    private int cText, cMuted;
    private double pendingX, pendingY, clickX, clickY;
    private int mx, my;
    private String dragId = null;

    // content area
    private int cx, cy, cw, ch, colW;

    public SettingsScreen() {
        super(Text.literal("Chunk Info"));
    }

    @Override
    protected void init() {
        // Invisible full-screen button: the game's own click handling feeds us clicks and taps.
        ButtonWidget catcher = ButtonWidget.builder(Text.empty(), b -> onCatch())
                .dimensions(0, 0, this.width, this.height).build();
        catcher.setAlpha(0f);
        this.addDrawableChild(catcher);
        prevY = keyDown(GLFW.GLFW_KEY_Y);
    }

    private void onCatch() {
        MinecraftClient mc = MinecraftClient.getInstance();
        pendingX = mc.mouse.getX() * mc.getWindow().getScaledWidth() / (double) mc.getWindow().getWidth();
        pendingY = mc.mouse.getY() * mc.getWindow().getScaledHeight() / (double) mc.getWindow().getHeight();
        pendingClick = true;
    }

    private boolean keyDown(int key) {
        return GLFW.glfwGetKey(MinecraftClient.getInstance().getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
    }

    private boolean mouseDown() {
        return GLFW.glfwGetMouseButton(MinecraftClient.getInstance().getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    public boolean shouldPause() {
        return false;
    }

    public void removed() {
        Settings.save();
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (TABS[tab].equals("Blocks")) blockPage += verticalAmount < 0 ? 1 : -1;
        return true;
    }

    // ---------- helpers ----------

    private static boolean hit(double px, double py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private boolean hov(int x, int y, int w, int h) {
        return hit(mx, my, x, y, w, h);
    }

    private boolean clk(int x, int y, int w, int h) {
        return clicked && hit(clickX, clickY, x, y, w, h);
    }

    private void text(DrawContext c, String s, int x, int y, int color) {
        c.drawTextWithShadow(this.textRenderer, s, x, y, color);
    }

    private int tw(String s) {
        return this.textRenderer.getWidth(s);
    }

    private String fit(String s, int max) {
        if (tw(s) <= max) return s;
        while (s.length() > 1 && tw(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private int cellX(int i) {
        return cx + (i % 2) * (colW + 8);
    }

    private int cellY(int i) {
        return cy + 24 + (i / 2) * 28;
    }

    private static float snap(float v, float step) {
        return Math.round(v / step) * step;
    }

    private int valColor() {
        return mand ? Ui.shade(accent, 25) : accent;
    }

    /** Background of a control row. Mandala: inset slot. Neon: rounded card. */
    private void card(DrawContext c, int x, int y, int w, int h, boolean hv) {
        if (mand) Ui.bevel(c, x, y, w, h, hv ? M_SLOT_H : M_SLOT, M_SLOT_DK, M_SLOT_LT, M_BORDER);
        else Ui.rrect(c, x, y, w, h, 5, hv ? SURF_H : SURF);
    }

    // ---------- controls ----------

    private boolean toggle(DrawContext c, String label, boolean v, int x, int y, int w, int dot) {
        boolean h = hov(x, y, w, 24);
        card(c, x, y, w, 24, h);
        int tx = x + 8;
        if (dot != 0) {
            Ui.rrect(c, x + 8, y + 10, 4, 4, 2, dot);
            tx = x + 17;
        }
        text(c, fit(label, w - 34 - (tx - x)), tx, y + 8, cText);
        if (mand) {
            int bx = x + w - 22, by = y + 5;
            Ui.bevel(c, bx, by, 14, 14, M_WELL, 0xFF0B0D13, 0xFF343C4F, M_BORDER);
            if (v) {
                c.fill(bx + 3, by + 3, bx + 11, by + 11, accent);
                c.fill(bx + 3, by + 3, bx + 11, by + 4, Ui.shade(accent, 60));
                c.fill(bx + 3, by + 10, bx + 11, by + 11, Ui.shade(accent, -50));
            }
        } else {
            int sx = x + w - 30, sy = y + 7;
            Ui.rrect(c, sx, sy, 22, 10, 5, v ? accent : OFF);
            Ui.rrect(c, sx + (v ? 12 : 0), sy, 10, 10, 5, 0xFFFFFFFF);
        }
        if (clk(x, y, w, 24)) {
            dirty = true;
            return !v;
        }
        return v;
    }

    private float slider(DrawContext c, String id, String label, String val, float v, float min, float max, int x, int y, int w) {
        boolean h = hov(x, y, w, 24) || id.equals(dragId);
        card(c, x, y, w, 24, h);
        text(c, label, x + 8, y + 4, cText);
        text(c, val, x + w - 8 - tw(val), y + 4, valColor());
        int tx = x + 8, tw = w - 16, ty = y + 17;
        float f = Math.max(0f, Math.min(1f, (v - min) / (max - min)));
        if (mand) {
            Ui.bevel(c, tx, ty - 1, tw, 5, M_WELL, 0xFF0B0D13, 0xFF343C4F, M_BORDER);
            int fw = (int) ((tw - 2) * f);
            if (fw > 0) c.fill(tx + 1, ty, tx + 1 + fw, ty + 3, accent);
            Ui.bevel(c, tx + (int) ((tw - 7) * f), ty - 4, 7, 10, 0xFF7F8AA6, 0xFFB4BED6, 0xFF3A4357, M_BORDER);
        } else {
            Ui.rrect(c, tx, ty, tw, 3, 1, OFF);
            Ui.rrect(c, tx, ty, Math.max(2, (int) (tw * f)), 3, 1, accent);
            Ui.rrect(c, tx + (int) (tw * f) - 3, ty - 2, 6, 7, 3, 0xFFFFFFFF);
        }

        if (clk(x, y, w, 24)) {
            dragId = id;
            dirty = true;
            return min + Math.max(0f, Math.min(1f, (float) (clickX - tx) / tw)) * (max - min);
        }
        if (leftDown && id.equals(dragId)) {
            dirty = true;
            return min + Math.max(0f, Math.min(1f, (float) (mx - tx) / tw)) * (max - min);
        }
        return v;
    }

    private int cycle(DrawContext c, String label, String[] opts, int cur, int x, int y, int w) {
        boolean h = hov(x, y, w, 24);
        card(c, x, y, w, 24, h);
        text(c, label, x + 8, y + 8, cText);
        String val = "< " + opts[Math.floorMod(cur, opts.length)] + " >";
        text(c, val, x + w - 8 - tw(val), y + 8, valColor());
        if (clk(x, y, w, 24)) {
            dirty = true;
            return (cur + 1) % opts.length;
        }
        return cur;
    }

    private boolean button(DrawContext c, String label, int x, int y, int w, int h, boolean primary) {
        boolean hv = hov(x, y, w, h);
        if (mand) {
            int fill = primary ? Ui.shade(accent, hv ? -20 : -45) : (hv ? 0xFF343C4F : 0xFF2A3140);
            Ui.bevel(c, x, y, w, h, fill, primary ? Ui.shade(accent, 60) : 0xFF4C566A,
                    primary ? Ui.shade(accent, -90) : M_DARK, M_BORDER);
        } else {
            int bg = primary ? Ui.alpha(accent, hv ? 0xFF : 0xCC) : (hv ? SURF_H : SURF);
            Ui.rrect(c, x, y, w, h, 5, bg);
        }
        text(c, label, x + (w - tw(label)) / 2, y + (h - 8) / 2, primary ? 0xFFFFFFFF : cText);
        return clk(x, y, w, h);
    }

    private void mandalaArt(DrawContext c, int mcx, int mcy, int R, long t, int col) {
        double rot = t / 4000.0;
        int[] counts = {8, 16, 24, 32};
        for (int k = 0; k < 4; k++) {
            double r = R * (0.30 + 0.23 * k);
            int n = counts[k];
            double dir = (k % 2 == 0) ? 1 : -1;
            for (int i = 0; i < n; i++) {
                double a = rot * dir * (1 + k * 0.3) + i * (Math.PI * 2 / n);
                int x = mcx + (int) Math.round(Math.cos(a) * r);
                int y = mcy + (int) Math.round(Math.sin(a) * r);
                int s = (k % 2 == 0) ? 2 : 1;
                c.fill(x, y, x + s, y + s, Ui.alpha(col, 0x38 + k * 0x1A));
            }
        }
        for (int i = 0; i < 12; i++) {
            double a = rot * 0.6 + i * Math.PI / 6;
            for (double rr = R * 0.12; rr < R * 0.30; rr += 3) {
                int x = mcx + (int) Math.round(Math.cos(a) * rr);
                int y = mcy + (int) Math.round(Math.sin(a) * rr);
                c.fill(x, y, x + 1, y + 1, Ui.alpha(col, 0x70));
            }
        }
        c.fill(mcx - 1, mcy - 1, mcx + 2, mcy + 2, Ui.alpha(col, 0xCC));
    }

    // ---------- render ----------

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Settings s = Settings.get();
        mx = mouseX;
        my = mouseY;
        long t = System.currentTimeMillis();

        boolean down = mouseDown();
        leftDown = down;
        boolean yd = keyDown(GLFW.GLFW_KEY_Y);
        if (yd && !prevY) {
            this.close();
            return;
        }
        prevY = yd;

        clicked = pendingClick;
        clickX = pendingX;
        clickY = pendingY;
        pendingClick = false;
        if (!down && !clicked) {
            dragId = null;
            if (dirty) {
                Settings.save();
                dirty = false;
            }
        }

        accent = s.accentColor();
        mand = s.uiStyle == 0;
        cText = mand ? 0xFFE6E9F2 : 0xFFEDEDF5;
        cMuted = mand ? 0xFF8E97AB : 0xFF8B8BA3;

        ctx.fill(0, 0, this.width, this.height, mand ? 0x99000000 : 0xB0000000);

        int pw = Math.min(440, this.width - 16);
        int ph = Math.min(250, this.height - 16);
        int px = (this.width - pw) / 2;
        int py = (this.height - ph) / 2;
        int sw = 86;
        int top = mand ? 20 : 6;

        if (mand) {
            Ui.bevel(ctx, px, py, pw, ph, M_PANEL, M_LIGHT, M_DARK, M_BORDER);
            String title = "Chunk Info";
            text(ctx, title, px + (pw - tw(title)) / 2, py + 8, 0xFFB8C0D4);
            // close button
            int bx = px + pw - 22, by = py + 5;
            boolean hv = hov(bx, by, 16, 14);
            Ui.bevel(ctx, bx, by, 16, 14, hv ? 0xFF343C4F : 0xFF2A3140, 0xFF4C566A, M_DARK, M_BORDER);
            text(ctx, "x", bx + 8 - tw("x") / 2, by + 3, cText);
            if (clk(bx, by, 16, 14)) {
                this.close();
                return;
            }
            // sidebar well
            Ui.bevel(ctx, px + 6, py + top, sw, ph - top - 6, 0xFF1A1F2B, 0xFF0F1219, 0xFF343C4F, 0xFF0B0D13);
        } else {
            Ui.rrect(ctx, px - 2, py - 2, pw + 4, ph + 4, 9, Ui.alpha(accent, 0x55));
            Ui.outlined(ctx, px, py, pw, ph, 7, BG, LINE);
            Ui.rrect(ctx, px + 6, py + 6, sw, ph - 12, 6, SIDE);
        }

        // circle ornament + logo (both styles)
        mandalaArt(ctx, px + 6 + sw / 2, py + ph - 52, 40, t, accent);
        Ui.logo(ctx, px + 11, py + top + 4, 6, accent);
        text(ctx, "Chunk", px + 40, py + top + 7, valColor());
        text(ctx, "Info", px + 40, py + top + 18, cText);

        // tabs
        for (int i = 0; i < TABS.length; i++) {
            int tx = px + 10, ty = py + top + 34 + i * 22, tw2 = sw - 8;
            boolean act = tab == i;
            boolean hv = hov(tx, ty, tw2, 18);
            if (mand) {
                Ui.bevel(ctx, tx, ty, tw2, 18,
                        act ? M_SLOT : (hv ? 0xFF2F3748 : 0xFF262C3A),
                        act ? M_SLOT_DK : 0xFF424B60,
                        act ? M_SLOT_LT : 0xFF151922, M_BORDER);
                if (act) Ui.studFrame(ctx, tx, ty, tw2, 18, accent);
                text(ctx, TABS[i], tx + 9, ty + 5, act ? 0xFFFFFFFF : 0xFFB8C0D4);
            } else {
                if (act) Ui.rrect(ctx, tx, ty, tw2, 18, 5, Ui.alpha(accent, 0x30));
                else if (hv) Ui.rrect(ctx, tx, ty, tw2, 18, 5, 0xFF16161F);
                if (act) Ui.rrect(ctx, tx, ty + 3, 2, 12, 1, accent);
                text(ctx, TABS[i], tx + 9, ty + 5, act ? cText : cMuted);
            }
            if (clk(tx, ty, tw2, 18)) tab = i;
        }

        // content area
        cx = px + sw + 18;
        cy = py + top + (mand ? 4 : 8);
        cw = pw - sw - 30;
        ch = ph - (cy - py) - 14;
        colW = (cw - 8) / 2;

        text(ctx, TABS[tab].toUpperCase(), cx, cy, mand ? 0xFFB8C0D4 : cText);
        if (mand) {
            ctx.fill(cx, cy + 11, cx + cw, cy + 12, M_DARK);
            ctx.fill(cx, cy + 12, cx + cw, cy + 13, M_LIGHT);
        } else {
            Ui.hfade(ctx, cx, cy + 11, cw, 1, accent, 255, 0);
        }

        String tn = TABS[tab];
        if (tn.equals("Scan")) drawScanTab(ctx, s);
        else if (tn.equals("Border")) drawBorderTab(ctx, s);
        else if (tn.equals("Panel")) drawPanelTab(ctx, s);
        else if (tn.equals("Players")) drawPlayersTab(ctx, s);
        else if (tn.equals("Blocks")) drawBlocksTab(ctx, s);
        else drawKeysTab(ctx);

        String foot = "Y / Esc to close";
        text(ctx, foot, px + pw - 10 - tw(foot), py + ph - 13, cMuted);
    }

    private void drawScanTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.autoScan = toggle(ctx, "Auto scan", s.autoScan, cellX(i), cellY(i), colW, 0);
        i++;
        s.scanTarget = cycle(ctx, "Scan target", Settings.SCAN_TARGETS, s.scanTarget, cellX(i), cellY(i), colW);
        i++;
        s.autoTicks = Math.round(slider(ctx, "autoticks", "Auto scan rate", s.autoTicks + " ticks", s.autoTicks, 5, 60,
                cellX(i), cellY(i), colW));
        text(ctx, "Auto scan checks one chunk and updates the panel for you.", cx, cellY(4) - 4, cMuted);
        text(ctx, "Looking at = chunk under your crosshair. Standing in = your chunk.", cx, cellY(4) + 8, cMuted);
        text(ctx, "G scans once with the same target. K clears everything.", cx, cellY(4) + 20, cMuted);
    }

    private void drawBorderTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.borders = toggle(ctx, "Show border", s.borders, cellX(i), cellY(i), colW, 0);
        i++;
        s.style = cycle(ctx, "Style", Settings.STYLES, s.style, cellX(i), cellY(i), colW);
        i++;
        s.gap = snap(slider(ctx, "gap", "Particle gap", String.format("%.2f", s.gap), s.gap, 0.2f, 2.0f,
                cellX(i), cellY(i), colW), 0.05f);
        i++;
        s.pulseTicks = Math.round(slider(ctx, "pulse", "Update rate", s.pulseTicks + " ticks", s.pulseTicks, 2, 20,
                cellX(i), cellY(i), colW));
        i++;
        s.heightRange = Math.round(slider(ctx, "height", "Height range", "+-" + s.heightRange, s.heightRange, 16, 128,
                cellX(i), cellY(i), colW) / 4f) * 4;
        i++;
        s.maxChunks = Math.round(slider(ctx, "dist", "Max distance", s.maxChunks + " chunks", s.maxChunks, 2, 16,
                cellX(i), cellY(i), colW));
        i++;
        s.rings = toggle(ctx, "Ring lines", s.rings, cellX(i), cellY(i), colW, 0);
        i++;
        s.ringEvery = Math.round(slider(ctx, "ring", "Ring spacing", s.ringEvery + " blocks", s.ringEvery, 4, 32,
                cellX(i), cellY(i), colW) / 2f) * 2;
        i++;
        s.dustSize = snap(slider(ctx, "dust", "Dust size", String.format("%.1f", s.dustSize), s.dustSize, 1f, 4f,
                cellX(i), cellY(i), colW), 0.5f);
        i++;
        s.showClean = toggle(ctx, "Clean chunk border", s.showClean, cellX(i), cellY(i), colW, 0);
    }

    private void drawPanelTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.panel = toggle(ctx, "Show scan results", s.panel, cellX(i), cellY(i), colW, 0);
        i++;
        s.showCoords = toggle(ctx, "Show coordinates", s.showCoords, cellX(i), cellY(i), colW, 0);
        i++;
        s.panelPos = cycle(ctx, "Panel position", Settings.POSITIONS, s.panelPos, cellX(i), cellY(i), colW);
        i++;
        s.accent = cycle(ctx, "Accent color", Settings.ACCENT_NAMES, s.accent, cellX(i), cellY(i), colW);
        i++;
        s.uiStyle = cycle(ctx, "UI style", Settings.UI_STYLES, s.uiStyle, cellX(i), cellY(i), colW);
        text(ctx, "One panel shows the scan and nearby players.", cx, cellY(6) + 2, cMuted);
    }

    private void drawPlayersTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.radar = toggle(ctx, "Show players", s.radar, cellX(i), cellY(i), colW, 0);
        i++;
        s.radarChunks = Math.round(slider(ctx, "rchunks", "Range", s.radarChunks + " chunks", s.radarChunks, 2, 16,
                cellX(i), cellY(i), colW));
        i++;
        s.radarMax = Math.round(slider(ctx, "rmax", "Max players", String.valueOf(s.radarMax), s.radarMax, 3, 10,
                cellX(i), cellY(i), colW));
        text(ctx, "Lists players your game has loaded, with coordinates.", cx, cellY(4) - 4, cMuted);
        text(ctx, "Invisible players are not shown. Move the panel in the Panel tab.", cx, cellY(4) + 8, cMuted);
    }

    private void drawBlocksTab(DrawContext ctx, Settings s) {
        // legend
        int lx = cx + cw;
        String l2 = "in structures";
        String l1 = "never natural";
        lx -= tw(l2);
        text(ctx, l2, lx, cy, cMuted);
        lx -= 10;
        Ui.rrect(ctx, lx, cy + 3, 4, 4, 2, AMBER);
        lx -= tw(l1) + 6;
        text(ctx, l1, lx, cy, cMuted);
        lx -= 10;
        Ui.rrect(ctx, lx, cy + 3, 4, 4, 2, GREEN);

        int rows = Math.max(2, (ch - 24 - 30) / 28);
        int per = rows * 2;
        int total = Targets.ALL.size();
        int pages = (total + per - 1) / per;
        blockPage = Math.max(0, Math.min(blockPage, pages - 1));

        for (int k = 0; k < per; k++) {
            int idx = blockPage * per + k;
            if (idx >= total) break;
            Targets.Entry e = Targets.ALL.get(idx);
            boolean on = Targets.isOn(e);
            boolean nv = toggle(ctx, e.label, on, cellX(k), cellY(k), colW, e.defaultOn ? GREEN : AMBER);
            if (nv != on) {
                s.blocks.put(e.label, nv);
                Targets.rebuild();
            }
        }

        int by = cy + ch - 22;
        if (button(ctx, "<", cx, by, 20, 20, false)) blockPage--;
        String pg = (blockPage + 1) + "/" + pages;
        text(ctx, pg, cx + 26, by + 6, cMuted);
        if (button(ctx, ">", cx + 28 + tw(pg), by, 20, 20, false)) blockPage++;

        int bw = 62;
        if (button(ctx, "Defaults", cx + cw - bw, by, bw, 20, true)) {
            s.blocks.clear();
            Targets.rebuild();
            dirty = true;
        }
        if (button(ctx, "All off", cx + cw - bw * 2 - 6, by, bw, 20, false)) {
            for (Targets.Entry e : Targets.ALL) s.blocks.put(e.label, false);
            Targets.rebuild();
            dirty = true;
        }
    }

    private void drawKeysTab(DrawContext ctx) {
        String[][] rows = {
                {"G", "Scan once (target is set in the Scan tab)"},
                {"K", "Clear all borders and the panel"},
                {"Y", "Open / close this menu"}
        };
        int y = cy + 26;
        for (String[] r : rows) {
            if (mand) Ui.bevel(ctx, cx, y, 22, 18, M_SLOT, M_SLOT_DK, M_SLOT_LT, M_BORDER);
            else Ui.rrect(ctx, cx, y, 22, 18, 4, Ui.alpha(accent, 0x40));
            text(ctx, r[0], cx + 11 - tw(r[0]) / 2, y + 5, valColor());
            text(ctx, r[1], cx + 32, y + 5, cText);
            y += 26;
        }
        text(ctx, "Rebind keys in Options > Controls > Key Binds.", cx, y + 6, cMuted);
        text(ctx, "Settings are saved to config/chunkinfo.json.", cx, y + 20, cMuted);
    }
}
