package com.example.chunkinfo;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class InfoPanel {
    private static final int BG = 0xE60C0C13, LINE = 0xFF2B2B3F, TEXT = 0xFFEDEDF5, MUTED = 0xFF8B8BA3, GREEN = 0xFF4ADE80;
    private static final int W = 176;

    private static class Row {
        final String left, right;
        final int lc, rc;

        Row(String left, String right, int lc, int rc) {
            this.left = left;
            this.right = right;
            this.lc = lc;
            this.rc = rc;
        }
    }

    public static void render(DrawContext c, MinecraftClient mc) {
        Settings s = Settings.get();
        if (!s.panel || mc.world == null || mc.player == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int acc = s.accentColor();
        ScanResult r = ChunkInfoClient.last;

        List<Row> rows = new ArrayList<>();
        if (r == null) {
            String msg = ChunkInfoClient.status != null ? ChunkInfoClient.status : "Look at a chunk and press G";
            rows.add(new Row(msg, "", MUTED, 0));
        } else {
            rows.add(new Row("Chunk " + r.pos.x + ", " + r.pos.z, "", MUTED, 0));
            if (r.total == 0) {
                rows.add(new Row("Clean - nothing found", "", GREEN, 0));
            } else {
                rows.add(new Row(r.total + (r.total == 1 ? " crafted block" : " crafted blocks"), "", acc, 0));
                List<Map.Entry<Block, Integer>> list = new ArrayList<>(r.counts.entrySet());
                list.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
                int shown = 0;
                for (Map.Entry<Block, Integer> e : list) {
                    if (shown++ >= 6) break;
                    rows.add(new Row(e.getKey().getName().getString(), "x" + e.getValue(), TEXT, acc));
                }
                if (list.size() > 6) rows.add(new Row("+" + (list.size() - 6) + " more types", "", MUTED, 0));
                if (s.showCoords && !r.samples.isEmpty()) {
                    rows.add(new Row("Found at", "", MUTED, 0));
                    for (BlockPos p : r.samples) {
                        if (rows.size() > 16) break;
                        rows.add(new Row(p.getX() + " " + p.getY() + " " + p.getZ(), "", TEXT, 0));
                    }
                }
            }
        }

        int h = 8 + 14 + rows.size() * 11 + 6;
        int sw = mc.getWindow().getScaledWidth();
        int x = s.panelPos == 0 ? sw - W - 6 : 6;
        int y = 6;

        Ui.outlined(c, x, y, W, h, 5, BG, LINE);
        Ui.hfade(c, x + 6, y + 1, W - 12, 1, acc, 220, 0);
        Ui.rrect(c, x + 8, y + 9, 4, 4, 2, acc);
        c.drawTextWithShadow(tr, "CHUNK SCAN", x + 16, y + 7, TEXT);

        int ry = y + 8 + 14;
        for (Row row : rows) {
            int rw = row.right.isEmpty() ? 0 : tr.getWidth(row.right) + 6;
            String left = fit(tr, row.left, W - 16 - rw);
            c.drawTextWithShadow(tr, left, x + 8, ry, row.lc);
            if (!row.right.isEmpty()) {
                c.drawTextWithShadow(tr, row.right, x + W - 8 - tr.getWidth(row.right), ry, row.rc);
            }
            ry += 11;
        }
    }

    private static String fit(TextRenderer tr, String s, int max) {
        if (tr.getWidth(s) <= max) return s;
        while (s.length() > 1 && tr.getWidth(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
