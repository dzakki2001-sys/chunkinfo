package com.example.chunkinfo;

import net.minecraft.client.gui.DrawContext;

public final class Ui {
    private Ui() {}

    public static int alpha(int color, int a) {
        return ((a & 0xFF) << 24) | (color & 0xFFFFFF);
    }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    public static void outlined(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(c, x - 1, y - 1, w + 2, h + 2, r + 1, border);
        rrect(c, x, y, w, h, r, fill);
    }

    public static void hfade(DrawContext c, int x, int y, int w, int h, int color, int aFrom, int aTo) {
        int seg = 3;
        for (int i = 0; i < w; i += seg) {
            float f = (float) i / Math.max(1, w);
            int a = (int) (aFrom + (aTo - aFrom) * f);
            c.fill(x + i, y, Math.min(x + w, x + i + seg), y + h, alpha(color, a));
        }
    }
}
