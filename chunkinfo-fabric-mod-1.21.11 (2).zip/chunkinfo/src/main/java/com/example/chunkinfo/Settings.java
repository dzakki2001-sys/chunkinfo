package com.example.chunkinfo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Settings {
    public static final int[] ACCENTS = {0xFFFF3B5C, 0xFFA855F7, 0xFF22D3EE, 0xFF84CC16};
    public static final String[] ACCENT_NAMES = {"Crimson", "Violet", "Cyan", "Lime"};
    public static final String[] STYLES = {"Flame", "Soul fire", "End rod", "Red dust"};
    public static final String[] POSITIONS = {"Top right", "Top left"};

    public boolean borders = true;
    public boolean rings = true;
    public boolean panel = true;
    public boolean showCoords = true;
    public int style = 0;
    public int pulseTicks = 5;
    public int heightRange = 32;
    public int maxChunks = 8;
    public int ringEvery = 16;
    public int accent = 0;
    public int panelPos = 0;
    public float gap = 0.5f;
    public float dustSize = 3.0f;
    public Map<String, Boolean> blocks = new HashMap<>();

    private static Settings instance = new Settings();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Settings get() {
        return instance;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("chunkinfo.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Settings s = GSON.fromJson(Files.readString(f), Settings.class);
                if (s != null) instance = s;
            }
        } catch (Exception ignored) {
        }
        if (instance.blocks == null) instance.blocks = new HashMap<>();
        Targets.rebuild();
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(instance));
        } catch (Exception ignored) {
        }
    }

    public int accentColor() {
        return ACCENTS[Math.floorMod(accent, ACCENTS.length)];
    }
}
