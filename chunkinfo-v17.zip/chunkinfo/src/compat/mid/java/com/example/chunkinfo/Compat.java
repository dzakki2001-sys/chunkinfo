package com.example.chunkinfo;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;

/** Parts of the game API that differ between Minecraft versions. This is the 1.21.5 - 1.21.8 flavour. */
public final class Compat {
    private Compat() {}

    public static KeyBinding key(String name, int code) {
        return new KeyBinding(name, InputUtil.Type.KEYSYM, code, "category.chunkinfo.main");
    }

    public static void particle(ClientWorld w, ParticleEffect e, double x, double y, double z) {
        w.addImportantParticleClient(e, x, y, z, 0, 0, 0);
    }

    public static ParticleEffect dust(int rgb, float scale) {
        return new DustParticleEffect(rgb, scale);
    }

    public static int selectedSlot(net.minecraft.entity.player.PlayerEntity p) {
        return p.getInventory().getSelectedSlot();
    }

    public static void selectSlot(net.minecraft.entity.player.PlayerEntity p, int slot) {
        p.getInventory().setSelectedSlot(slot);
    }
}
