package com.example.chunkinfo;

import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Which blocks count as "player-made". defaultOn = crafted blocks that never generate naturally. */
public class Targets {
    public static class Entry {
        public final String label;
        public final boolean defaultOn;
        public final int special; // 0 = normal, 1 = any shulker box, 2 = any bed
        public final Block[] blocks;

        Entry(String label, boolean defaultOn, int special, Block... blocks) {
            this.label = label;
            this.defaultOn = defaultOn;
            this.special = special;
            this.blocks = blocks;
        }
    }

    public static final List<Entry> ALL = new ArrayList<>();
    private static final Set<Block> ACTIVE = new HashSet<>();
    private static boolean shulker, bed;

    private static void add(String label, boolean on, Block... b) {
        ALL.add(new Entry(label, on, 0, b));
    }

    static {
        // Crafted blocks that never generate in the world (ON by default)
        add("Enchanting Table", true, Blocks.ENCHANTING_TABLE);
        add("Ender Chest", true, Blocks.ENDER_CHEST);
        add("Beacon", true, Blocks.BEACON);
        add("Conduit", true, Blocks.CONDUIT);
        add("Anvil (any)", true, Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL);
        add("Hopper", true, Blocks.HOPPER);
        add("Dropper", true, Blocks.DROPPER);
        add("Observer", true, Blocks.OBSERVER);
        add("Daylight Detector", true, Blocks.DAYLIGHT_DETECTOR);
        add("Lodestone", true, Blocks.LODESTONE);
        add("Note Block", true, Blocks.NOTE_BLOCK);
        add("Jukebox", true, Blocks.JUKEBOX);
        add("Target Block", true, Blocks.TARGET);
        add("Redstone Lamp", true, Blocks.REDSTONE_LAMP);
        add("Respawn Anchor", true, Blocks.RESPAWN_ANCHOR);
        ALL.add(new Entry("Shulker Box (any)", true, 1));

        // Blocks that can also generate inside structures (OFF by default)
        add("Mob Spawner", false, Blocks.SPAWNER);
        add("Chest", false, Blocks.CHEST);
        add("Trapped Chest", false, Blocks.TRAPPED_CHEST);
        add("Barrel", false, Blocks.BARREL);
        add("Crafting Table", false, Blocks.CRAFTING_TABLE);
        add("Furnace", false, Blocks.FURNACE);
        add("Blast Furnace", false, Blocks.BLAST_FURNACE);
        add("Smoker", false, Blocks.SMOKER);
        add("Brewing Stand", false, Blocks.BREWING_STAND);
        add("Lectern", false, Blocks.LECTERN);
        add("Loom", false, Blocks.LOOM);
        add("Cartography Table", false, Blocks.CARTOGRAPHY_TABLE);
        add("Smithing Table", false, Blocks.SMITHING_TABLE);
        add("Fletching Table", false, Blocks.FLETCHING_TABLE);
        add("Grindstone", false, Blocks.GRINDSTONE);
        add("Stonecutter", false, Blocks.STONECUTTER);
        add("Composter", false, Blocks.COMPOSTER);
        add("TNT", false, Blocks.TNT);
        add("Piston", false, Blocks.PISTON);
        add("Sticky Piston", false, Blocks.STICKY_PISTON);
        add("Repeater", false, Blocks.REPEATER);
        add("Comparator", false, Blocks.COMPARATOR);
        add("Dispenser", false, Blocks.DISPENSER);
        ALL.add(new Entry("Bed (any)", false, 2));
    }

    public static boolean isOn(Entry e) {
        return Settings.get().blocks.getOrDefault(e.label, e.defaultOn);
    }

    public static void rebuild() {
        ACTIVE.clear();
        shulker = false;
        bed = false;
        for (Entry e : ALL) {
            if (!isOn(e)) continue;
            for (Block b : e.blocks) ACTIVE.add(b);
            if (e.special == 1) shulker = true;
            if (e.special == 2) bed = true;
        }
    }

    public static boolean isTarget(BlockState st) {
        Block b = st.getBlock();
        return ACTIVE.contains(b) || (shulker && b instanceof ShulkerBoxBlock) || (bed && b instanceof BedBlock);
    }
}
