package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.SimpleOption;

/** Performance presets, vanilla option helpers and zoom. Everything here is a normal client setting. */
public final class Perf {
    private Perf() {}

    private static boolean zooming = false;
    private static Integer savedFov = null;
    private static Double savedSens = null;

    public static int getInt(MinecraftClient mc, String k) {
        GameOptions o = mc.options;
        switch (k) {
            case "view": return o.getViewDistance().getValue();
            case "sim": return o.getSimulationDistance().getValue();
            case "fps": return o.getMaxFps().getValue();
            case "entity": return (int) Math.round(o.getEntityDistanceScaling().getValue() * 100);
            case "fovfx": return (int) Math.round(o.getFovEffectScale().getValue() * 100);
            case "blend": return o.getBiomeBlendRadius().getValue();
            case "clouds": {
                CloudRenderMode m = o.getCloudRenderMode().getValue();
                return m == CloudRenderMode.OFF ? 0 : (m == CloudRenderMode.FAST ? 1 : 2);
            }
            case "particles": return Math.min(2, ((Enum<?>) o.getParticles().getValue()).ordinal());
            default: return 0;
        }
    }

    public static void setInt(MinecraftClient mc, String k, int v) {
        GameOptions o = mc.options;
        try {
            switch (k) {
                case "view": o.getViewDistance().setValue(v); break;
                case "sim": o.getSimulationDistance().setValue(v); break;
                case "fps": o.getMaxFps().setValue(v); break;
                case "entity": o.getEntityDistanceScaling().setValue(v / 100.0); break;
                case "fovfx": o.getFovEffectScale().setValue(v / 100.0); break;
                case "blend": o.getBiomeBlendRadius().setValue(v); break;
                case "clouds":
                    o.getCloudRenderMode().setValue(v == 0 ? CloudRenderMode.OFF
                            : (v == 1 ? CloudRenderMode.FAST : CloudRenderMode.FANCY));
                    break;
                case "particles": setEnum(o.getParticles(), v); break;
                default:
            }
        } catch (Throwable ignored) {
        }
    }

    /** Sets an enum option by position without naming its class (the class moved between versions). */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setEnum(SimpleOption opt, int ordinal) {
        Object[] all = ((Enum<?>) opt.getValue()).getDeclaringClass().getEnumConstants();
        opt.setValue(all[Math.max(0, Math.min(all.length - 1, ordinal))]);
    }

    public static boolean getBool(MinecraftClient mc, String k) {
        GameOptions o = mc.options;
        switch (k) {
            case "bob": return o.getBobView().getValue();
            case "shadows": return o.getEntityShadows().getValue();
            case "sprint": return o.getSprintToggled().getValue();
            case "sneak": return o.getSneakToggled().getValue();
            default: return false;
        }
    }

    public static void setBool(MinecraftClient mc, String k, boolean v) {
        GameOptions o = mc.options;
        try {
            switch (k) {
                case "bob": o.getBobView().setValue(v); break;
                case "shadows": o.getEntityShadows().setValue(v); break;
                case "sprint": o.getSprintToggled().setValue(v); break;
                case "sneak": o.getSneakToggled().setValue(v); break;
                default:
            }
        } catch (Throwable ignored) {
        }
    }

    /** 0 = Fast (PvP), 1 = Balanced, 2 = Quality. */
    public static void preset(MinecraftClient mc, int p) {
        if (p == 3) {
            setInt(mc, "view", 4);
            setInt(mc, "sim", 5);
            setInt(mc, "fps", 260);
            setInt(mc, "entity", 50);
            setInt(mc, "blend", 0);
            setInt(mc, "clouds", 0);
            setInt(mc, "particles", 2);
            setBool(mc, "shadows", false);
            save();
            return;
        }
        if (p == 0) {
            setInt(mc, "view", 8);
            setInt(mc, "sim", 5);
            setInt(mc, "fps", 260);
            setInt(mc, "entity", 75);
            setInt(mc, "blend", 1);
            setInt(mc, "clouds", 0);
            setInt(mc, "particles", 1);
            setBool(mc, "shadows", false);
        } else if (p == 1) {
            setInt(mc, "view", 12);
            setInt(mc, "sim", 8);
            setInt(mc, "fps", 144);
            setInt(mc, "entity", 100);
            setInt(mc, "blend", 3);
            setInt(mc, "clouds", 1);
            setInt(mc, "particles", 1);
            setBool(mc, "shadows", true);
        } else {
            setInt(mc, "view", 16);
            setInt(mc, "sim", 12);
            setInt(mc, "fps", 120);
            setInt(mc, "entity", 150);
            setInt(mc, "blend", 5);
            setInt(mc, "clouds", 2);
            setInt(mc, "particles", 0);
            setBool(mc, "shadows", true);
        }
        save();
    }

    public static void save() {
        try {
            MinecraftClient.getInstance().options.write();
        } catch (Throwable ignored) {
        }
    }

    private static int checkT = 0, low = 0, calm = 0, level = 0;
    private static boolean active = false;
    private static Integer savedMaxFps = null;
    private static final int[] SAMPLES = new int[3];
    private static int sampleN = 0;
    private static int bView, bEntity, bPart, bClouds, bBlend;
    private static boolean bShadows;

    public static int boostLevel() {
        return active ? level : 0;
    }

    private static void applyLevel(MinecraftClient mc, int lv) {
        int minV = Math.max(2, Settings.get().boostMinView);
        setInt(mc, "view", lv >= 5 ? Math.min(bView, minV) : (lv >= 3 ? Math.max(minV, bView - 2) : bView));
        setInt(mc, "entity", lv >= 1 ? Math.min(bEntity, 75) : bEntity);
        setInt(mc, "particles", lv >= 5 ? 2 : (lv >= 2 ? Math.max(bPart, 1) : bPart));
        setInt(mc, "clouds", lv >= 4 ? 0 : bClouds);
        setBool(mc, "shadows", lv >= 4 ? false : bShadows);
        setInt(mc, "blend", lv >= 4 ? Math.min(bBlend, 1) : bBlend);
    }

    /**
     * FPS Boost. When on, it checks your FPS every second. If FPS stays under the target it moves one level
     * up (5 levels: entity distance, particles, render distance, clouds and shadows, then the minimum).
     * When FPS is high for a while it steps back down. Turning it off restores your own settings.
     * Also caps FPS while the window is unfocused.
     */
    public static void boostTick(MinecraftClient mc) {
        Settings s = Settings.get();
        try {
            boolean unfocused = s.unfocusedLimit && !mc.isWindowFocused();
            if (unfocused && savedMaxFps == null) {
                savedMaxFps = mc.options.getMaxFps().getValue();
                mc.options.getMaxFps().setValue(Math.min(30, savedMaxFps));
            } else if (!unfocused && savedMaxFps != null) {
                mc.options.getMaxFps().setValue(savedMaxFps);
                savedMaxFps = null;
            }
        } catch (Throwable ignored) {
        }
        if (mc.world == null || mc.player == null) return;

        if (s.fpsBoost && !active) {
            bView = getInt(mc, "view");
            bEntity = getInt(mc, "entity");
            bPart = getInt(mc, "particles");
            bClouds = getInt(mc, "clouds");
            bBlend = getInt(mc, "blend");
            bShadows = getBool(mc, "shadows");
            active = true;
            level = 0;
            low = 0;
            calm = 0;
            sampleN = 0;
        } else if (!s.fpsBoost && active) {
            applyLevel(mc, 0);
            active = false;
            level = 0;
            save();
        }
        if (!active) return;

        if (++checkT < 20) return;
        checkT = 0;
        if (mc.currentScreen != null || !mc.isWindowFocused()) return;

        SAMPLES[sampleN++ % SAMPLES.length] = mc.getCurrentFps();
        if (sampleN < SAMPLES.length) return;
        int fps = (SAMPLES[0] + SAMPLES[1] + SAMPLES[2]) / 3;

        if (fps < s.fpsTarget * 0.92) {
            calm = 0;
            if (++low >= 2 && level < 5) {
                level++;
                applyLevel(mc, level);
                low = 0;
            }
        } else if (fps > s.fpsTarget * 1.4) {
            low = 0;
            if (++calm >= 6 && level > 0) {
                level--;
                applyLevel(mc, level);
                calm = 0;
            }
        } else {
            low = 0;
            calm = 0;
        }
    }

    /** Hold the zoom key: lowers FOV and mouse speed, then restores both. */
    public static void tick(MinecraftClient mc, KeyBinding zoomKey) {
        Settings s = Settings.get();
        boolean want = s.zoom && mc.player != null && mc.currentScreen == null && zoomKey.isPressed();
        try {
            if (want && !zooming) {
                zooming = true;
                savedFov = mc.options.getFov().getValue();
                savedSens = mc.options.getMouseSensitivity().getValue();
                mc.options.getFov().setValue(Math.max(30, Math.min(110, s.zoomFov)));
                mc.options.getMouseSensitivity().setValue(savedSens * 0.4);
            } else if (!want && zooming) {
                zooming = false;
                if (savedFov != null) mc.options.getFov().setValue(savedFov);
                if (savedSens != null) mc.options.getMouseSensitivity().setValue(savedSens);
                savedFov = null;
                savedSens = null;
            }
        } catch (Throwable ignored) {
        }
    }
}
