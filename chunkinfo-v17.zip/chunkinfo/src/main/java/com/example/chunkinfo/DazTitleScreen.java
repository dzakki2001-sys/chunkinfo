package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Simple client-style main menu that replaces the vanilla title screen. */
public class DazTitleScreen extends Screen {
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Mods", "Options", "Quit"};
    private final int[] bx = new int[5], by = new int[5], bw = new int[5];
    private final float[] hoverAnim = new float[5];
    private int menuTop;
    private long last = 0;

    public DazTitleScreen() {
        super(Text.literal("Daz Client"));
    }

    private ButtonWidget hot(int x, int y, int w, int h, Runnable r) {
        ButtonWidget b = ButtonWidget.builder(Text.empty(), btn -> r.run()).dimensions(x, y, w, h).build();
        b.setAlpha(0f);
        return b;
    }

    @Override
    protected void init() {
        int w = Math.min(230, this.width - 40);
        int x = (this.width - w) / 2;
        menuTop = Math.max(this.height / 2 - 6, 112);
        int half = (w - 8) / 2;
        bx[0] = x; by[0] = menuTop; bw[0] = w;
        bx[1] = x; by[1] = menuTop + 30; bw[1] = w;
        bx[2] = x; by[2] = menuTop + 60; bw[2] = half;
        bx[3] = x + half + 8; by[3] = menuTop + 60; bw[3] = half;
        bx[4] = x; by[4] = menuTop + 90; bw[4] = w;

        MinecraftClient mc = MinecraftClient.getInstance();
        this.addDrawableChild(hot(bx[0], by[0], bw[0], 24, () -> mc.setScreen(new SelectWorldScreen(this))));
        this.addDrawableChild(hot(bx[1], by[1], bw[1], 24, () -> mc.setScreen(new MultiplayerScreen(this))));
        this.addDrawableChild(hot(bx[2], by[2], bw[2], 24, () -> mc.setScreen(new ModsScreen(this))));
        this.addDrawableChild(hot(bx[3], by[3], bw[3], 24, () -> mc.setScreen(new OptionsScreen(this, mc.options))));
        this.addDrawableChild(hot(bx[4], by[4], bw[4], 24, mc::scheduleStop));
    }

    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Settings s = Settings.get();
        Theme T = Theme.of(s.uiStyle);
        boolean neon = s.uiStyle == 1;
        int acc = s.accentColor();
        int w = this.width, h = this.height;
        long now = System.currentTimeMillis();
        double t = now / 1000.0;
        double dt = last == 0 ? 0.016 : Math.min(0.1, (now - last) / 1000.0);
        last = now;

        c.fill(0, 0, w, h, neon ? 0xFF0B0B12 : Ui.shade(T.dark, 4));
        Fx.draw(c, neon ? 1 : (T.fx != 0 ? T.fx : 1), 0, 0, w, h, t, acc);
        c.fillGradient(0, 0, w, h / 3, 0x66000000, 0x00000000);
        c.fillGradient(0, h * 2 / 3, w, h, 0x00000000, 0x66000000);

        int cell = 8, ls = 3 * cell + 6;
        int sc = Math.max(2, Math.min(4, h / 80));
        int blockH = ls + 8 + 5 * sc;
        int top = Math.max(6, menuTop - 20 - blockH);
        Ui.logo(c, w / 2 - ls / 2, top, cell, acc);
        PixelFont.drawCentered(c, "DAZ CLIENT", w / 2, top + ls + 8, sc, acc);

        int card = neon ? 0xFF171722 : Ui.alpha(T.slot, 0xFF), cardHov = neon ? 0xFF20202F : Ui.alpha(T.slotH, 0xFF);
        int text = neon ? 0xFFEDEDF5 : T.text, muted = neon ? 0xFF8B8BA3 : T.muted;
        for (int i = 0; i < 5; i++) {
            boolean hov = mx >= bx[i] && mx < bx[i] + bw[i] && my >= by[i] && my < by[i] + 24;
            hoverAnim[i] += ((hov ? 1f : 0f) - hoverAnim[i]) * (float) Math.min(1.0, dt * 14);
            Ui.rrect(c, bx[i], by[i], bw[i], 24, 6, hov ? cardHov : card);
            int uw = (int) ((bw[i] - 16) * hoverAnim[i]);
            c.fill(bx[i] + (bw[i] - uw) / 2, by[i] + 21, bx[i] + (bw[i] + uw) / 2, by[i] + 22, acc);
            c.drawTextWithShadow(this.textRenderer, LABELS[i], bx[i] + (bw[i] - this.textRenderer.getWidth(LABELS[i])) / 2,
                    by[i] + 8, text);
        }

        String ver = "Minecraft " + ModManager.gameVersion();
        c.drawTextWithShadow(this.textRenderer, ver, 6, h - 12, muted);
        String user = "";
        try {
            user = mc.getSession().getUsername();
        } catch (Throwable ignored) {
        }
        if (user != null && !user.isEmpty()) {
            c.drawTextWithShadow(this.textRenderer, user, w - 6 - this.textRenderer.getWidth(user), h - 12, muted);
        }
    }
}
