package com.example.chunkinfo;

/** Colour palettes for the bevel-style UI. fx = animated background effect id (see Fx). */
public class Theme {
    public final String name;
    public final int panel, light, dark, border, slot, slotH, slotDk, slotLt, well, side, sideDk, sideLt,
            tab, tabH, tabLt, tabDk, btn, btnH, btnLt, text, muted, title, fx;

    private Theme(String name, int panel, int light, int dark, int border,
                  int slot, int slotH, int slotDk, int slotLt, int well,
                  int side, int sideDk, int sideLt,
                  int tab, int tabH, int tabLt, int tabDk,
                  int btn, int btnH, int btnLt,
                  int text, int muted, int title, int fx) {
        this.name = name;
        this.panel = panel;
        this.light = light;
        this.dark = dark;
        this.border = border;
        this.slot = slot;
        this.slotH = slotH;
        this.slotDk = slotDk;
        this.slotLt = slotLt;
        this.well = well;
        this.side = side;
        this.sideDk = sideDk;
        this.sideLt = sideLt;
        this.tab = tab;
        this.tabH = tabH;
        this.tabLt = tabLt;
        this.tabDk = tabDk;
        this.btn = btn;
        this.btnH = btnH;
        this.btnLt = btnLt;
        this.text = text;
        this.muted = muted;
        this.title = title;
        this.fx = fx;
    }

    // index = Settings.uiStyle (index 1 is the rounded "Neon" style, which does not use a Theme)
    private static final Theme MANDALA = new Theme("Mandala",
            0xFF2B3140, 0xFF4C566A, 0xFF161A24, 0xFF0B0D13,
            0xFF1E2330, 0xFF272E3F, 0xFF12151D, 0xFF3A4357, 0xFF10131A,
            0xFF1A1F2B, 0xFF0F1219, 0xFF343C4F,
            0xFF262C3A, 0xFF2F3748, 0xFF424B60, 0xFF151922,
            0xFF2A3140, 0xFF343C4F, 0xFF4C566A,
            0xFFE6E9F2, 0xFF8E97AB, 0xFFB8C0D4, 0);

    private static final Theme COSMOS = new Theme("Cosmos",
            0xFF141233, 0xFF3B3A7A, 0xFF08071A, 0xFF04040E,
            0xB0100E2A, 0xC0191640, 0xFF07061A, 0xFF4A4890, 0xFF0A0920,
            0xB00B0A24, 0xFF05040F, 0xFF3B3A7A,
            0xC0171538, 0xD0221F52, 0xFF4A4890, 0xFF05040F,
            0xFF24215A, 0xFF312D75, 0xFF5A57B0,
            0xFFE8E6FF, 0xFF9A98D0, 0xFFC9C6FF, 1);

    private static final Theme MATRIX = new Theme("Matrix",
            0xFF06120A, 0xFF1E5A33, 0xFF020804, 0xFF010402,
            0xB0071A0E, 0xC00B2A16, 0xFF020A05, 0xFF2A7A45, 0xFF030E07,
            0xB0040F08, 0xFF010503, 0xFF1E5A33,
            0xC0082414, 0xD00D3820, 0xFF2A7A45, 0xFF020A05,
            0xFF0E3A1E, 0xFF14522B, 0xFF2F8A4E,
            0xFFC8FFD9, 0xFF5FA877, 0xFF8CF0B0, 2);

    private static final Theme EMBER = new Theme("Ember",
            0xFF1C0F0C, 0xFF5A2E22, 0xFF0C0605, 0xFF060302,
            0xB0220F0A, 0xC0331611, 0xFF0E0605, 0xFF7A3D2A, 0xFF140805,
            0xB0160A07, 0xFF080302, 0xFF5A2E22,
            0xC02A130D, 0xD03D1C14, 0xFF7A3D2A, 0xFF0E0605,
            0xFF4A2016, 0xFF63291C, 0xFF9A4A32,
            0xFFFFE9DD, 0xFFC79A86, 0xFFFFC9A8, 3);

    private static final Theme SYNTH = new Theme("Synth",
            0xFF1B1038, 0xFF5B2E8F, 0xFF0B0518, 0xFF050210,
            0xB01A0C36, 0xC0271350, 0xFF0A0418, 0xFF8A3FD0, 0xFF0F0624,
            0xB0120A2A, 0xFF060214, 0xFF5B2E8F,
            0xC0220F48, 0xD0331868, 0xFF8A3FD0, 0xFF0A0418,
            0xFF3A1A78, 0xFF4C2398, 0xFFB35CFF,
            0xFFFFE6FF, 0xFFC49AE6, 0xFFFFB3F0, 4);

    private static final Theme SAKURA = new Theme("Sakura",
            0xFF2A1C2B, 0xFF6B4B6E, 0xFF140B15, 0xFF0A050B,
            0xB02A1A2D, 0xC03A2640, 0xFF150B17, 0xFF8E6593, 0xFF1B0F1C,
            0xB01E1220, 0xFF0D060E, 0xFF6B4B6E,
            0xC0321F35, 0xD0442B48, 0xFF8E6593, 0xFF150B17,
            0xFF5A3560, 0xFF73437A, 0xFFB07BB8,
            0xFFFFEAF4, 0xFFD2A9C2, 0xFFFFC2DD, 5);

    private static final Theme AURORA = new Theme("Aurora",
            0xFF0E1A24, 0xFF2E5A6E, 0xFF060D13, 0xFF03070A,
            0xB00A1620, 0xC0112430, 0xFF050B10, 0xFF3A7A8C, 0xFF08121A,
            0xB0081018, 0xFF03080C, 0xFF2E5A6E,
            0xC00F2230, 0xD0183446, 0xFF3A7A8C, 0xFF050B10,
            0xFF164055, 0xFF1E5470, 0xFF4C9DB5,
            0xFFE6FBFF, 0xFF8FB8C4, 0xFFB9F0FF, 6);

    private static final Theme FROST = new Theme("Frost",
            0xFF1B2733, 0xFF5B7A96, 0xFF0C131B, 0xFF060A0F,
            0xB01A2530, 0xC0243342, 0xFF0B1118, 0xFF7FA0BD, 0xFF111B25,
            0xB0141E29, 0xFF080D13, 0xFF5B7A96,
            0xC0213040, 0xD02D4156, 0xFF7FA0BD, 0xFF0B1118,
            0xFF2F4760, 0xFF3B5B7A, 0xFF8DB4D6,
            0xFFF2F8FF, 0xFFA9BDD0, 0xFFD6E8FA, 7);

    private static final Theme[] ALL = {MANDALA, MANDALA, COSMOS, MATRIX, EMBER, SYNTH, SAKURA, AURORA, FROST};

    public static Theme of(int style) {
        return ALL[Math.floorMod(style, ALL.length)];
    }
}
