package com.example.chunkinfo;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public class ChunkInfoClient implements ClientModInitializer {
    // Chunks that were scanned and contain crafted blocks (they get a border).
    static final Map<Long, ScanResult> flagged = new HashMap<>();
    // Result shown in the info panel.
    public static ScanResult last = null;
    public static String status = null;

    private static int tickCounter = 0;
    private KeyBinding scanKey, clearKey, menuKey, wpKey, zoomKey, swapAKey, swapBKey;

    @Override
    public void onInitializeClient() {
        Settings.load();
        Data.load();

        scanKey = reg("key.chunkinfo.scan", GLFW.GLFW_KEY_G);
        clearKey = reg("key.chunkinfo.clear", GLFW.GLFW_KEY_K);
        menuKey = reg("key.chunkinfo.menu", GLFW.GLFW_KEY_Y);
        wpKey = reg("key.chunkinfo.waypoint", GLFW.GLFW_KEY_B);
        zoomKey = reg("key.chunkinfo.zoom", GLFW.GLFW_KEY_C);
        swapAKey = reg("key.chunkinfo.swap_a", GLFW.GLFW_KEY_V);
        swapBKey = reg("key.chunkinfo.swap_b", GLFW.GLFW_KEY_UNKNOWN);

        LoadingScreen.register();

        ClientReceiveMessageEvents.ALLOW_GAME.register(ChatFilter::allow);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Perf.tick(mc, zoomKey);
            Perf.boostTick(mc);
            if (Settings.get().clientTitle && mc.currentScreen != null && mc.currentScreen.getClass() == TitleScreen.class) {
                mc.setScreen(new DazTitleScreen());
            }
            while (swapAKey.wasPressed()) Swap.run(mc, Settings.get().swapA1, Settings.get().swapA2);
            while (swapBKey.wasPressed()) Swap.run(mc, Settings.get().swapB1, Settings.get().swapB2);
            if (mc.world == null || mc.player == null) {
                flagged.clear();
                last = null;
                status = null;
                return;
            }
            while (clearKey.wasPressed()) {
                flagged.clear();
                last = null;
                status = "Cleared";
            }
            while (scanKey.wasPressed()) scanNow(mc, false);
            while (wpKey.wasPressed()) {
                Data.Mark nm = Marks.addWaypoint(mc);
                if (nm != null && Settings.get().marksAsk && mc.currentScreen == null) {
                    mc.setScreen(new SettingsScreen(SettingsScreen.MARKS_TAB, nm));
                }
            }
            Marks.tick(mc);
            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ModsScreen(null));
            }
            autoScanTick(mc);
            if (Settings.get().borders) drawBorders(mc);
        });

        HudRenderCallback.EVENT.register((ctx, tick) -> {
            MinecraftClient m = MinecraftClient.getInstance();
            ClientHud.render(ctx, m);
            HudPanel.render(ctx, m);
            WaypointHud.render(ctx, m);
        });
    }

    private static KeyBinding reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(Compat.key(name, key));
    }

    private static long autoCleanKey = Long.MIN_VALUE;
    private static int autoTicks = 0;

    // Which chunk to scan: the one you look at, or the one you stand in.
    private static ChunkPos targetChunk(MinecraftClient mc) {
        if (Settings.get().scanTarget == 1) return mc.player.getChunkPos();
        if (mc.getCameraEntity() == null) return null;
        double dist = mc.options.getViewDistance().getValue() * 16.0;
        HitResult hit = mc.getCameraEntity().raycast(dist, 1.0f, false);
        BlockPos bp = (hit instanceof BlockHitResult b && hit.getType() == HitResult.Type.BLOCK)
                ? b.getBlockPos()
                : BlockPos.ofFloored(hit.getPos());
        return new ChunkPos(bp);
    }

    private static void scanNow(MinecraftClient mc, boolean auto) {
        ChunkPos cp = targetChunk(mc);
        if (cp == null) return;
        WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z);
        if (chunk == null) {
            if (!auto) {
                last = null;
                status = "Chunk " + cp.x + ", " + cp.z + " is not loaded";
            }
            return;
        }

        status = null;
        ScanResult r = ChunkScanner.scan(chunk);
        last = r;
        if (Settings.get().history && r.total > 0) Data.record(mc, r);
        long key = cp.toLong();
        if (auto) {
            // in auto mode a clean chunk is only marked while it is the target; chunks with finds stay marked
            if (autoCleanKey != Long.MIN_VALUE && autoCleanKey != key) {
                ScanResult old = flagged.get(autoCleanKey);
                if (old != null && old.total == 0) flagged.remove(autoCleanKey);
                autoCleanKey = Long.MIN_VALUE;
            }
            if (r.total == 0) autoCleanKey = key;
        }
        flagged.put(key, r);
    }

    private static void autoScanTick(MinecraftClient mc) {
        Settings s = Settings.get();
        if (!s.autoScan) return;
        if (++autoTicks < Math.max(2, s.autoTicks)) return;
        autoTicks = 0;
        scanNow(mc, true);
    }

    private static ParticleEffect effect(Settings s) {
        switch (Math.floorMod(s.style, 4)) {
            case 1:
                return ParticleTypes.SOUL_FIRE_FLAME;
            case 2:
                return ParticleTypes.END_ROD;
            case 3:
                return Compat.dust(0xFF2020, s.dustSize);
            default:
                return ParticleTypes.FLAME;
        }
    }

    private static ParticleEffect cleanEffect(Settings s) {
        if (Math.floorMod(s.style, 4) == 3) return Compat.dust(0x20FF40, s.dustSize);
        return ParticleTypes.END_ROD;
    }

    private static int line(MinecraftClient mc, ParticleEffect e, double x1, double y1, double z1,
                            double x2, double y2, double z2, double gap) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int n = Math.max(1, (int) Math.ceil(len / gap));
        for (int i = 0; i <= n; i++) {
            double f = (double) i / n;
            Compat.particle(mc.world, e, x1 + dx * f, y1 + dy * f, z1 + dz * f);
        }
        return n + 1;
    }

    // Dense glowing border around every flagged chunk.
    private static void drawBorders(MinecraftClient mc) {
        Settings s = Settings.get();
        if (flagged.isEmpty() || ++tickCounter % Math.max(1, s.pulseTicks) != 0) return;

        ParticleEffect eFound = effect(s);
        ParticleEffect eClean = cleanEffect(s);
        double gap = Math.max(0.2, s.gap);
        ChunkPos pc = mc.player.getChunkPos();
        int py = (int) mc.player.getY();
        int bottom = mc.world.getBottomY();
        int top = bottom + mc.world.getHeight();
        int yLow = Math.max(bottom, py - s.heightRange);
        int yHigh = Math.min(top, py + s.heightRange);
        int budget = 4000;

        for (ScanResult r : flagged.values()) {
            if (budget <= 0) return;
            if (r.total == 0 && !s.showClean) continue;
            ParticleEffect e = r.total > 0 ? eFound : eClean;
            if (Math.abs(r.pos.x - pc.x) > s.maxChunks || Math.abs(r.pos.z - pc.z) > s.maxChunks) continue;

            double x0 = r.pos.getStartX(), z0 = r.pos.getStartZ();
            double x1 = x0 + 16, z1 = z0 + 16;

            // four solid vertical corner lines
            budget -= line(mc, e, x0, yLow, z0, x0, yHigh, z0, gap);
            budget -= line(mc, e, x1, yLow, z0, x1, yHigh, z0, gap);
            budget -= line(mc, e, x0, yLow, z1, x0, yHigh, z1, gap);
            budget -= line(mc, e, x1, yLow, z1, x1, yHigh, z1, gap);

            // solid horizontal rings
            if (s.rings) {
                int every = Math.max(2, s.ringEvery);
                for (int y = Math.floorDiv(yLow + every - 1, every) * every; y <= yHigh; y += every) {
                    budget -= line(mc, e, x0, y, z0, x1, y, z0, gap);
                    budget -= line(mc, e, x1, y, z0, x1, y, z1, gap);
                    budget -= line(mc, e, x1, y, z1, x0, y, z1, gap);
                    budget -= line(mc, e, x0, y, z1, x0, y, z0, gap);
                }
            }
        }
    }
}
