package com.example.chunkinfo;

import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Hides spammy server/system messages (ads, vote messages, ...). */
public class ChatFilter {
    public static final List<String> recent = new ArrayList<>();
    public static int hidden = 0;
    private static final String[] ADS = {"store.", "/store", "discord.gg", "tiktok", "lootdrop", "/vote", "voted"};

    /** Fabric ALLOW_GAME callback: return false to hide the message. */
    public static boolean allow(Text message, boolean overlay) {
        if (overlay) return true;
        String raw = message.getString().trim();
        String low = raw.toLowerCase();
        Settings s = Settings.get();
        if (s.chatFilter) {
            if (s.chatAds) {
                for (String k : ADS) {
                    if (low.contains(k)) {
                        hidden++;
                        return false;
                    }
                }
            }
            for (String k : s.chatCustom) {
                if (!k.isEmpty() && low.contains(k)) {
                    hidden++;
                    return false;
                }
            }
        }
        if (!raw.isEmpty()) {
            recent.remove(raw);
            recent.add(0, raw);
            while (recent.size() > 12) recent.remove(recent.size() - 1);
        }
        return true;
    }

    /** Keyword used when you block a message from the recent list. */
    public static String keyFor(String message) {
        String k = message.trim().toLowerCase();
        return k.length() > 48 ? k.substring(0, 48) : k;
    }
}
