package com.example.chunkinfo;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Item icons you can pick for a waypoint. */
public class Icons {
    public static class Icon {
        public final String id;
        public final Item item;
        public final ItemStack stack;

        Icon(String id, Item item) {
            this.id = id;
            this.item = item;
            this.stack = new ItemStack(item);
        }
    }

    public static final List<Icon> ALL = new ArrayList<>();

    private static void add(String id, Item item) {
        ALL.add(new Icon(id, item));
    }

    static {
        add("compass", Items.COMPASS);
        add("ender_pearl", Items.ENDER_PEARL);
        add("diamond", Items.DIAMOND);
        add("emerald", Items.EMERALD);
        add("gold", Items.GOLD_INGOT);
        add("iron", Items.IRON_INGOT);
        add("netherite", Items.NETHERITE_INGOT);
        add("chest", Items.CHEST);
        add("ender_chest", Items.ENDER_CHEST);
        add("bed", Items.RED_BED);
        add("crafting", Items.CRAFTING_TABLE);
        add("furnace", Items.FURNACE);
        add("anvil", Items.ANVIL);
        add("enchanting", Items.ENCHANTING_TABLE);
        add("beacon", Items.BEACON);
        add("totem", Items.TOTEM_OF_UNDYING);
        add("sword", Items.DIAMOND_SWORD);
        add("pickaxe", Items.DIAMOND_PICKAXE);
        add("tnt", Items.TNT);
        add("skull", Items.SKELETON_SKULL);
        add("nether_star", Items.NETHER_STAR);
        add("elytra", Items.ELYTRA);
        add("map", Items.MAP);
        add("apple", Items.GOLDEN_APPLE);
        add("spawner", Items.SPAWNER);
        add("obsidian", Items.OBSIDIAN);
        add("trident", Items.TRIDENT);
        add("shield", Items.SHIELD);
    }

    public static String idOf(Data.Mark m, boolean death) {
        if (m.icon != null && !m.icon.isEmpty()) return m.icon;
        return death ? "skull" : "compass";
    }

    public static ItemStack stack(Data.Mark m, boolean death) {
        String id = idOf(m, death);
        for (Icon i : ALL) if (i.id.equals(id)) return i.stack;
        return ALL.get(0).stack;
    }
}
