package com.example.chunkinfo;

import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ScanResult {
    public final ChunkPos pos;
    public final Map<Block, Integer> counts = new HashMap<>();
    public final List<BlockPos> samples = new ArrayList<>();
    public int total;

    public ScanResult(ChunkPos pos) {
        this.pos = pos;
    }
}
