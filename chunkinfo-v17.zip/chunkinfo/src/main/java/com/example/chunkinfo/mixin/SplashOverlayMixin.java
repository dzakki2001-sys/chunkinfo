package com.example.chunkinfo.mixin;

import com.example.chunkinfo.LoadingScreen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SplashOverlay.class)
public class SplashOverlayMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void daz$drawSplash(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        LoadingScreen.drawSplash(context);
    }
}
