package com.example.chunkinfo;

import net.minecraft.client.gui.DrawContext;

import java.util.HashMap;
import java.util.Map;

/** Tiny 5x5 pixel font, drawn with plain fills. Safe to use while the game is still loading. */
public final class PixelFont {
    private PixelFont() {}

    private static final Map<Character, String[]> G = new HashMap<>();

    private static void put(char c, String... rows) {
        G.put(c, rows);
    }

    static {
        put('A', ".###.", "#...#", "#####", "#...#", "#...#");
        put('C', ".####", "#....", "#....", "#....", ".####");
        put('D', "####.", "#...#", "#...#", "#...#", "####.");
        put('E', "#####", "#....", "####.", "#....", "#####");
        put('G', ".####", "#....", "#.###", "#...#", ".####");
        put('I', "#####", "..#..", "..#..", "..#..", "#####");
        put('L', "#....", "#....", "#....", "#....", "#####");
        put('N', "#...#", "##..#", "#.#.#", "#..##", "#...#");
        put('O', ".###.", "#...#", "#...#", "#...#", ".###.");
        put('T', "#####", "..#..", "..#..", "..#..", "..#..");
        put('Z', "#####", "...#.", "..#..", ".#...", "#####");
    }

    public static int width(String s, int sc) {
        return Math.max(0, s.length() * 6 * sc - sc);
    }

    public static void draw(DrawContext c, String s, int x, int y, int sc, int color) {
        int shadow = Ui.alpha(0xFF000000, 0x90);
        for (int pass = 0; pass < 2; pass++) {
            int cx = x + (pass == 0 ? Math.max(1, sc / 2) : 0);
            int oy = y + (pass == 0 ? Math.max(1, sc / 2) : 0);
            int col = pass == 0 ? shadow : color;
            for (char ch : s.toCharArray()) {
                String[] g = G.get(ch);
                if (g != null) {
                    for (int r = 0; r < 5; r++) {
                        for (int k = 0; k < 5; k++) {
                            if (g[r].charAt(k) == '#') {
                                c.fill(cx + k * sc, oy + r * sc, cx + (k + 1) * sc, oy + (r + 1) * sc, col);
                            }
                        }
                    }
                }
                cx += 6 * sc;
            }
        }
    }

    public static void drawCentered(DrawContext c, String s, int cx, int y, int sc, int color) {
        draw(c, s, cx - width(s, sc) / 2, y, sc, color);
    }
}
