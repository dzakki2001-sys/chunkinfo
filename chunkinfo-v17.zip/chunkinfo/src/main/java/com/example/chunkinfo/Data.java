package com.example.chunkinfo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Saved data: death point, waypoints and scan history (config/chunkinfo-data.json). */
public class Data {
    public static class Mark {
        public String name = "", dim = "", server = "", icon = "";
        public int x, y, z;

        public Mark() {
        }

        public Mark(String name, int x, int y, int z, String dim, String server) {
            this.name = name;
            this.x = x;
            this.y = y;
            this.z = z;
            this.dim = dim;
            this.server = server;
        }
    }

    public static class Hist {
        public String dim = "", server = "", summary = "";
        public int cx, cz, total, x, y, z;
        public long time;
    }

    public Mark death = null;
    public List<Mark> marks = new ArrayList<>();
    public List<Hist> history = new ArrayList<>();

    private static Data instance = new Data();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Data get() {
        return instance;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("chunkinfo-data.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Data d = GSON.fromJson(Files.readString(f), Data.class);
                if (d != null) instance = d;
            }
        } catch (Exception ignored) {
        }
        if (instance.marks == null) instance.marks = new ArrayList<>();
        if (instance.history == null) instance.history = new ArrayList<>();
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(instance));
        } catch (Exception ignored) {
        }
    }

    /** Remember a scan that found crafted blocks. One entry per chunk. */
    public static void record(MinecraftClient mc, ScanResult r) {
        String server = Marks.server(mc), dim = Marks.dim(mc);

        List<Map.Entry<Block, Integer>> list = new ArrayList<>(r.counts.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(3, list.size()); i++) {
            if (i > 0) sb.append(", ");
            sb.append(list.get(i).getKey().getName().getString()).append(" x").append(list.get(i).getValue());
        }
        String summary = sb.toString();

        Data d = get();
        Hist found = null;
        for (Hist h : d.history) {
            if (h.cx == r.pos.x && h.cz == r.pos.z && h.server.equals(server) && h.dim.equals(dim)) {
                found = h;
                break;
            }
        }
        if (found != null && found.total == r.total && found.summary.equals(summary)) return;

        if (found == null) found = new Hist();
        else d.history.remove(found);
        d.history.add(0, found);

        found.server = server;
        found.dim = dim;
        found.cx = r.pos.x;
        found.cz = r.pos.z;
        found.total = r.total;
        found.summary = summary;
        found.time = System.currentTimeMillis();
        if (!r.samples.isEmpty()) {
            BlockPos p = r.samples.get(0);
            found.x = p.getX();
            found.y = p.getY();
            found.z = p.getZ();
        }
        while (d.history.size() > 100) d.history.remove(d.history.size() - 1);
        save();
    }
}
