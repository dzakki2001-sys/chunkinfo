package com.example.chunkinfo;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Changes your skin through Mojang's official skin API. Your login token is sent only to
 * api.minecraftservices.com, only when you press "Use", and it is never saved or shown.
 */
public final class SkinChanger {
    private SkinChanger() {}

    public static volatile String status = "";

    public static Path dir() {
        Path p = FabricLoader.getInstance().getGameDir().resolve("dazclient").resolve("skins");
        try {
            Files.createDirectories(p);
        } catch (IOException ignored) {
        }
        return p;
    }

    public static List<Path> list() {
        List<Path> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".png")).sorted().forEach(out::add);
        } catch (IOException ignored) {
        }
        return out;
    }

    private static void checkPng(byte[] b) throws IOException {
        if (b.length < 24 || (b[0] & 0xFF) != 0x89 || b[1] != 'P' || b[2] != 'N' || b[3] != 'G') {
            throw new IOException("not a PNG file");
        }
        int w = ((b[16] & 0xFF) << 24) | ((b[17] & 0xFF) << 16) | ((b[18] & 0xFF) << 8) | (b[19] & 0xFF);
        int h = ((b[20] & 0xFF) << 24) | ((b[21] & 0xFF) << 16) | ((b[22] & 0xFF) << 8) | (b[23] & 0xFF);
        if (w != 64 || (h != 64 && h != 32)) throw new IOException("skin must be 64x64 or 64x32, this is " + w + "x" + h);
    }

    /** Downloads a public skin by username into the skins folder. */
    public static void fetch(String name) {
        try {
            status = "Looking up " + name + "...";
            if (!name.matches("[A-Za-z0-9_]{3,16}")) throw new IOException("invalid username");
            JsonObject prof = JsonParser.parseString(
                    Web.getString("https://api.mojang.com/users/profiles/minecraft/" + name)).getAsJsonObject();
            String id = prof.get("id").getAsString();
            String real = prof.get("name").getAsString();
            JsonObject sess = JsonParser.parseString(
                    Web.getString("https://sessionserver.mojang.com/session/minecraft/profile/" + id)).getAsJsonObject();
            String value = null;
            for (JsonElement e : sess.getAsJsonArray("properties")) {
                JsonObject p = e.getAsJsonObject();
                if (p.get("name").getAsString().equals("textures")) value = p.get("value").getAsString();
            }
            if (value == null) throw new IOException("no skin data");
            JsonObject tex = JsonParser.parseString(new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8))
                    .getAsJsonObject().getAsJsonObject("textures");
            if (tex == null || !tex.has("SKIN")) throw new IOException("this player has no custom skin");
            JsonObject skin = tex.getAsJsonObject("SKIN");
            String url = skin.get("url").getAsString();
            boolean slim = skin.has("metadata") && skin.getAsJsonObject("metadata").has("model")
                    && skin.getAsJsonObject("metadata").get("model").getAsString().equals("slim");
            if (!url.startsWith("http://textures.minecraft.net/") && !url.startsWith("https://textures.minecraft.net/")) {
                throw new IOException("unexpected skin host");
            }
            byte[] png = Web.get(url.replace("http://", "https://"), 200000);
            checkPng(png);
            Files.write(dir().resolve(real + (slim ? "_slim" : "") + ".png"), png);
            status = "Saved " + real + (slim ? " (slim arms)" : "") + ". Tap Use to wear it.";
        } catch (Exception e) {
            status = "Fetch failed: " + e.getMessage();
        }
    }

    /** Uploads the skin to your account. Other players see it after you rejoin. */
    public static void apply(Path file, boolean slim) {
        try {
            status = "Uploading skin...";
            byte[] png = Files.readAllBytes(file);
            checkPng(png);
            String token = MinecraftClient.getInstance().getSession().getAccessToken();
            if (token == null || token.length() < 20) throw new IOException("you are not signed in with a Microsoft account");
            Map<String, String> fields = new LinkedHashMap<>();
            fields.put("variant", slim ? "slim" : "classic");
            StringBuilder resp = new StringBuilder();
            int code = Web.postMultipart("https://api.minecraftservices.com/minecraft/profile/skins", token, fields,
                    "file", file.getFileName().toString().replaceAll("[^A-Za-z0-9._-]", "_"), png, resp);
            if (code != 200) throw new IOException("Mojang answered HTTP " + code);
            status = "Skin changed! Rejoin the world or server to see it.";
        } catch (Exception e) {
            status = "Upload failed: " + e.getMessage();
        }
    }
}
