package com.example.chunkinfo;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public class ChunkScanner {
    public static ScanResult scan(WorldChunk chunk) {
        ScanResult r = new ScanResult(chunk.getPos());
        ChunkSection[] sections = chunk.getSectionArray();
        for (int i = 0; i < sections.length; i++) {
            ChunkSection sec = sections[i];
            if (sec == null || sec.isEmpty() || !sec.hasAny(Targets::isTarget)) continue;
            int baseY = chunk.getBottomY() + i * 16;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState st = sec.getBlockState(x, y, z);
                        if (!Targets.isTarget(st)) continue;
                        r.total++;
                        r.counts.merge(st.getBlock(), 1, Integer::sum);
                        if (r.samples.size() < 5) {
                            r.samples.add(new BlockPos(chunk.getPos().getStartX() + x, baseY + y,
                                    chunk.getPos().getStartZ() + z));
                        }
                    }
                }
            }
        }
        return r;
    }
}
