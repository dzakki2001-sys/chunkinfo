package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Watermark, HUD widgets, keystrokes and the custom crosshair. */
public final class ClientHud {
    private ClientHud() {}

    private static final List<Long> LEFT = new ArrayList<>(), RIGHT = new ArrayList<>();
    private static boolean lPrev, rPrev;
    private static final int[] HIST = new int[60];
    private static int histHead = 0;
    private static long histAt = 0, lastFrame = 0;
    private static final float[] KEY = new float[7];

    private static final class Row {
        final String label, value;
        final int color;

        Row(String label, String value, int color) {
            this.label = label;
            this.value = value;
            this.color = color;
        }
    }

    public static void render(DrawContext c, MinecraftClient mc) {
        if (mc.world == null || mc.player == null || mc.options.hudHidden) return;
        Settings s = Settings.get();
        long now = System.currentTimeMillis();
        double dt = lastFrame == 0 ? 0.016 : Math.min(0.1, (now - lastFrame) / 1000.0);
        lastFrame = now;
        pollClicks(mc);
        if (now - histAt >= 250) {
            histAt = now;
            HIST[histHead] = mc.getCurrentFps();
            histHead = (histHead + 1) % HIST.length;
        }
        if (s.watermark) drawWatermark(c, mc, false);
        widgets(c, mc, s, dt);
        if (mc.currentScreen == null) crosshair(c, mc, s);
    }

    private static void pollClicks(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        long h = mc.getWindow().getHandle();
        boolean l = mc.currentScreen == null && GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = mc.currentScreen == null && GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !lPrev) LEFT.add(now);
        if (r && !rPrev) RIGHT.add(now);
        lPrev = l;
        rPrev = r;
        LEFT.removeIf(t -> now - t > 1000);
        RIGHT.removeIf(t -> now - t > 1000);
    }

    // ---------- watermark ----------

    /** Small logo + name in a corner, faint on purpose, with a slow shimmer. */
    public static void drawWatermark(DrawContext c, MinecraftClient mc, boolean title) {
        Settings s = Settings.get();
        if (!s.watermark) return;
        TextRenderer tr = mc.textRenderer;
        String name = "Daz Client";
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int logo = 9;
        int tw = tr.getWidth(name);
        int w = logo + 5 + tw;
        int pos = Math.floorMod(s.watermarkPos, 4);
        int x = (pos == 1 || pos == 3) ? sw - w - 4 : 4;
        int y = (pos >= 2) ? sh - logo - 4 : 4;
        int a = Math.max(20, Math.min(100, s.watermarkAlpha)) * 255 / 100;
        Ui.logo(c, x, y, 1, s.accentColor());
        int tx = x + logo + 5;
        c.drawTextWithShadow(tr, name, tx, y + 1, Ui.alpha(0xFFFFFFFF, a));
        double sweep = (System.currentTimeMillis() / 1000.0 % 7.0) / 7.0;
        int bx = tx + (int) (sweep * (tw + 16)) - 8;
        for (int i = 0; i < 6; i++) {
            int px = bx + i;
            if (px >= tx && px < tx + tw) c.fill(px, y + 1, px + 1, y + 9, Ui.alpha(s.accentColor(), (int) (a * 0.5 * (1 - Math.abs(i - 2.5) / 3.0))));
        }
    }

    // ---------- widgets ----------

    private static int fpsColor(int fps, int target) {
        return fps >= target ? 0xFF4ADE80 : (fps >= target * 0.6 ? 0xFFFBBF24 : 0xFFF0605A);
    }

    private static void box(DrawContext c, int x, int y, int w, int h, Theme T, boolean neon, int a) {
        if (neon) Ui.outlined(c, x, y, w, h, 3, Ui.alpha(0xFF0C0C13, a), 0xFF2B2B3F);
        else Ui.bevel(c, x, y, w, h, Ui.alpha(T.panel, a), T.light, T.dark, T.border);
    }

    private static void widgets(DrawContext c, MinecraftClient mc, Settings s, double dt) {
        if (!(s.wFps || s.wCps || s.wPing || s.wCoords || s.wKeys || s.wClock || s.wSpeed)) return;
        Theme T = Theme.of(s.uiStyle);
        boolean neon = s.uiStyle == 1;
        TextRenderer tr = mc.textRenderer;
        int acc = s.accentColor();
        int text = neon ? 0xFFEDEDF5 : T.text, muted = neon ? 0xFF8B8BA3 : T.muted;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int pos = Math.floorMod(s.wPos, 4);
        boolean right = pos == 1 || pos == 3, bottom = pos >= 2;
        int a = Math.max(20, Math.min(100, s.widgetAlpha)) * 255 / 100;

        List<Row> rows = new ArrayList<>();
        int fps = mc.getCurrentFps();
        if (s.wFps) rows.add(new Row("FPS", String.valueOf(fps), fpsColor(fps, s.fpsTarget)));
        if (s.wCps) {
            int top = Math.max(LEFT.size(), RIGHT.size());
            rows.add(new Row("CPS", LEFT.size() + " | " + RIGHT.size(), top >= 10 ? acc : text));
        }
        if (s.wPing) {
            PlayerListEntry e = mc.getNetworkHandler() == null ? null
                    : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            int ms = e == null ? -1 : e.getLatency();
            rows.add(new Row("PING", ms < 0 ? "-" : ms + "ms", ms < 0 ? text : (ms < 60 ? 0xFF4ADE80 : (ms < 120 ? 0xFFFBBF24 : 0xFFF0605A))));
        }
        if (s.wCoords) {
            rows.add(new Row("XYZ", mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ(), text));
        }
        if (s.wSpeed) {
            Vec3d v = mc.player.getVelocity();
            rows.add(new Row("SPEED", String.format("%.1f b/s", Math.sqrt(v.x * v.x + v.z * v.z) * 20), text));
        }
        if (s.wClock) {
            LocalTime lt = LocalTime.now();
            rows.add(new Row("TIME", String.format("%02d:%02d", lt.getHour(), lt.getMinute()), text));
        }

        boolean graph = s.wFps && s.wFpsGraph;
        int total = rows.size() * 16 + (graph ? 24 : 0) + (s.wKeys ? 68 : 0);
        int y = bottom ? sh - 6 - total : 18;
        for (Row r : rows) {
            int w = tr.getWidth(r.label) + tr.getWidth(r.value) + 16;
            int x = right ? sw - w - 4 : 4;
            box(c, x, y, w, 14, T, neon, a);
            c.drawTextWithShadow(tr, r.label, x + 5, y + 3, muted);
            c.drawTextWithShadow(tr, r.value, x + w - 5 - tr.getWidth(r.value), y + 3, r.color);
            y += 16;
        }
        if (graph) {
            int gw = 66, x = right ? sw - gw - 4 : 4;
            box(c, x, y, gw, 20, T, neon, a);
            int cap = Math.max(30, (int) (s.fpsTarget * 1.5));
            for (int i = 0; i < HIST.length; i++) {
                int v = HIST[(histHead + i) % HIST.length];
                int bh = Math.min(16, v * 16 / cap);
                if (bh > 0) c.fill(x + 3 + i, y + 18 - bh, x + 4 + i, y + 18, fpsColor(v, s.fpsTarget));
            }
            y += 24;
        }
        if (s.wKeys) keystrokes(c, mc, tr, right ? sw - 62 : 4, y, T, neon, acc, text, a, dt);
    }

    private static void key(DrawContext c, TextRenderer tr, int i, int x, int y, int w, int h, String label,
                            boolean down, Theme T, boolean neon, int acc, int text, int a, double dt) {
        KEY[i] += ((down ? 1f : 0f) - KEY[i]) * (float) Math.min(1.0, dt * 16);
        float k = KEY[i];
        box(c, x, y, w, h, T, neon, a);
        if (k > 0.02f) {
            c.fill(x + 1, y + 1, x + w - 1, y + h - 1, Ui.alpha(acc, (int) (0xC8 * k)));
        }
        if (!label.isEmpty()) {
            c.drawTextWithShadow(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1,
                    k > 0.5f ? 0xFFFFFFFF : text);
        }
    }

    private static void keystrokes(DrawContext c, MinecraftClient mc, TextRenderer tr, int x, int y,
                                   Theme T, boolean neon, int acc, int text, int a, double dt) {
        var o = mc.options;
        key(c, tr, 0, x + 20, y, 18, 18, "W", o.forwardKey.isPressed(), T, neon, acc, text, a, dt);
        key(c, tr, 1, x, y + 20, 18, 18, "A", o.leftKey.isPressed(), T, neon, acc, text, a, dt);
        key(c, tr, 2, x + 20, y + 20, 18, 18, "S", o.backKey.isPressed(), T, neon, acc, text, a, dt);
        key(c, tr, 3, x + 40, y + 20, 18, 18, "D", o.rightKey.isPressed(), T, neon, acc, text, a, dt);
        key(c, tr, 4, x, y + 40, 28, 14, "L " + LEFT.size(), o.attackKey.isPressed(), T, neon, acc, text, a, dt);
        key(c, tr, 5, x + 30, y + 40, 28, 14, "R " + RIGHT.size(), o.useKey.isPressed(), T, neon, acc, text, a, dt);
        key(c, tr, 6, x, y + 56, 58, 8, "", o.jumpKey.isPressed(), T, neon, acc, text, a, dt);
    }

    // ---------- crosshair ----------

    private static void crosshair(DrawContext c, MinecraftClient mc, Settings s) {
        if (!s.crosshair) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int cx = sw / 2, cy = sh / 2;
        int extra = 0;
        if (s.chDynamic) {
            Vec3d v = mc.player.getVelocity();
            if (v.x * v.x + v.z * v.z > 0.0025) extra += 1;
            if (mc.player.isSprinting()) extra += 2;
        }
        drawCrosshairAt(c, cx, cy, extra);

        // the vanilla attack indicator is hidden with the vanilla crosshair, so this replaces it
        if (s.chCooldown) {
            float cd = mc.player.getAttackCooldownProgress(0.0f);
            if (cd < 0.999f) {
                int y = cy + Math.max(0, s.chGap) + extra + s.chSize + 7;
                int half = 10;
                c.fill(cx - half - 1, y - 1, cx + half + 1, y + 3, 0x99000000);
                int base = s.chColorMode == 1 ? 0xFF000000 | MathHelper.hsvToRgb(s.chHue / 360f, 1f, 1f) : s.accentColor();
                c.fill(cx - half, y, cx - half + (int) (2 * half * cd), y + 2, base);
            }
        }
    }

    public static void drawCrosshairAt(DrawContext c, int cx, int cy, int extraGap) {
        drawCrosshairAt(c, cx, cy, extraGap, 0);
    }

    /** cap > 0 limits the size, used for the small preview in the menu. */
    public static void drawCrosshairAt(DrawContext c, int cx, int cy, int extraGap, int cap) {
        Settings s = Settings.get();
        double t = System.currentTimeMillis() / 1000.0;
        int base;
        if (s.chColorMode == 1) base = 0xFF000000 | MathHelper.hsvToRgb(s.chHue / 360f, 1f, 1f);
        else if (s.chColorMode == 2) base = 0xFF000000 | MathHelper.hsvToRgb((float) ((t * 0.2) % 1.0), 0.8f, 1f);
        else base = s.accentColor();
        int a = Math.max(20, Math.min(100, s.chOpacity)) * 255 / 100;
        int color = Ui.alpha(base, a);
        int line = Ui.alpha(0xFF000000, a * 200 / 255);

        int size = Math.max(2, s.chSize), gap = Math.max(0, s.chGap) + extraGap, th = Math.max(1, s.chThick);
        if (cap > 0) {
            size = Math.min(size, cap);
            gap = Math.min(gap, cap / 2);
        }
        int lo = -(th / 2), hi = lo + th;
        List<int[]> r = new ArrayList<>();

        switch (Math.floorMod(s.chStyle, 8)) {
            case 1:
                r.add(new int[]{cx - size, cy + lo, cx + size + 1, cy + hi});
                r.add(new int[]{cx + lo, cy - size, cx + hi, cy + size + 1});
                break;
            case 2: {
                int d = Math.max(1, size / 3);
                r.add(new int[]{cx - d, cy - d, cx + d + 1, cy + d + 1});
                break;
            }
            case 3: {
                int pts = Math.max(16, size * 6);
                for (int i = 0; i < pts; i++) {
                    double ang = i * Math.PI * 2 / pts;
                    int px = cx + (int) Math.round(Math.cos(ang) * (size + gap));
                    int py = cy + (int) Math.round(Math.sin(ang) * (size + gap));
                    r.add(new int[]{px + lo, py + lo, px + lo + th, py + lo + th});
                }
                break;
            }
            case 4:
                r.add(new int[]{cx - gap - size, cy + lo, cx - gap, cy + hi});
                r.add(new int[]{cx + gap + 1, cy + lo, cx + gap + 1 + size, cy + hi});
                r.add(new int[]{cx + lo, cy + gap + 1, cx + hi, cy + gap + 1 + size});
                break;
            case 5: {
                int rad = size + gap;
                for (int dy = -rad; dy <= rad; dy++) {
                    int half = rad - Math.abs(dy);
                    r.add(new int[]{cx - half, cy + dy, cx - half + th, cy + dy + 1});
                    if (half > 0) r.add(new int[]{cx + half - th + 1, cy + dy, cx + half + 1, cy + dy + 1});
                }
                break;
            }
            case 6: { // chevron pointing up
                for (int k = 0; k <= size; k++) {
                    int yy = cy - gap - size + k;
                    r.add(new int[]{cx - k, yy, cx - k + th, yy + th});
                    r.add(new int[]{cx + k - th + 1, yy, cx + k + 1, yy + th});
                }
                break;
            }
            case 7: { // square outline
                int rad = size / 2 + gap;
                r.add(new int[]{cx - rad, cy - rad, cx + rad + 1, cy - rad + th});
                r.add(new int[]{cx - rad, cy + rad + 1 - th, cx + rad + 1, cy + rad + 1});
                r.add(new int[]{cx - rad, cy - rad, cx - rad + th, cy + rad + 1});
                r.add(new int[]{cx + rad + 1 - th, cy - rad, cx + rad + 1, cy + rad + 1});
                break;
            }
            default:
                r.add(new int[]{cx - gap - size, cy + lo, cx - gap, cy + hi});
                r.add(new int[]{cx + gap + 1, cy + lo, cx + gap + 1 + size, cy + hi});
                r.add(new int[]{cx + lo, cy - gap - size, cx + hi, cy - gap});
                r.add(new int[]{cx + lo, cy + gap + 1, cx + hi, cy + gap + 1 + size});
        }
        if (s.chDot && s.chStyle != 2) r.add(new int[]{cx, cy, cx + 1, cy + 1});

        if (s.chOutline) {
            for (int[] q : r) c.fill(q[0] - 1, q[1] - 1, q[2] + 1, q[3] + 1, line);
        }
        for (int[] q : r) c.fill(q[0], q[1], q[2], q[3], color);
    }
}
