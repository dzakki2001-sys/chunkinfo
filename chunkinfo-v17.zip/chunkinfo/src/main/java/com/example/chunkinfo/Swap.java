package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.screen.slot.SlotActionType;

/** Item swap: one key press = one action. Nothing happens automatically. */
public final class Swap {
    private Swap() {}

    private static int clampSlot(int v) {
        return Math.max(1, Math.min(9, v)) - 1;
    }

    /** a and b are hotbar slots 1-9. Mode 0 switches the selected slot, mode 1 swaps the two items. */
    public static void run(MinecraftClient mc, int a, int b) {
        if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;
        int sa = clampSlot(a), sb = clampSlot(b);
        if (sa == sb) return;

        if (Settings.get().swapMode == 0) {
            int cur = Compat.selectedSlot(mc.player);
            Compat.selectSlot(mc.player, cur == sa ? sb : sa);
        } else {
            // player inventory screen: hotbar slots are 36-44, SWAP exchanges with hotbar slot "button"
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, 36 + sa, sb,
                    SlotActionType.SWAP, mc.player);
        }
    }
}
