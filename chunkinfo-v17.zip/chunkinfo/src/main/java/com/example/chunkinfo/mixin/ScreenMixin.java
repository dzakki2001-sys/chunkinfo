package com.example.chunkinfo.mixin;

import com.example.chunkinfo.VanillaStyle;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public class ScreenMixin {
    @Inject(method = "renderBackground", at = @At("TAIL"), require = 0)
    private void daz$styleBackground(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        VanillaStyle.draw(context, (Screen) (Object) this);
    }
}
