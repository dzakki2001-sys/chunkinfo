package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Client-style mod list: one card per feature with a big toggle and a gear for its settings. */
public class ModsScreen extends Screen {
    private static final class Mod {
        final String name, desc, group, sub;
        final int icon;
        final Supplier<Boolean> get;
        final Consumer<Boolean> set;
        float anim = -1f;

        Mod(String name, String desc, int icon, String group, String sub, Supplier<Boolean> get, Consumer<Boolean> set) {
            this.name = name;
            this.desc = desc;
            this.icon = icon;
            this.group = group;
            this.sub = sub;
            this.get = get;
            this.set = set;
        }
    }

    private final Screen parent;
    private final List<Mod> mods = new ArrayList<>();
    private int page = 0, pageCount = 1, px, py, pw, ph, cardW, count;
    private static final int CARD_H = 46, GAP = 8;
    private final int[] cx = new int[30], cy = new int[30], ci = new int[30];
    private int prevX, nextX, setX, doneX, footY;
    private long last = 0;

    public ModsScreen(Screen parent) {
        super(Text.literal("Daz Client"));
        this.parent = parent;
        Settings s = Settings.get();
        add("FPS Boost", "Keeps FPS near your target", 4, "Client", "Boost", () -> s.fpsBoost, v -> s.fpsBoost = v);
        add("FPS counter", "Shows your FPS", 4, "Client", "HUD", () -> s.wFps, v -> s.wFps = v);
        add("CPS counter", "Clicks per second", 4, "Client", "HUD", () -> s.wCps, v -> s.wCps = v);
        add("Ping", "Your latency", 4, "Client", "HUD", () -> s.wPing, v -> s.wPing = v);
        add("Keystrokes", "WASD, mouse and jump", 4, "Client", "HUD", () -> s.wKeys, v -> s.wKeys = v);
        add("Coordinates", "Your XYZ on screen", 4, "Client", "HUD", () -> s.wCoords, v -> s.wCoords = v);
        add("Watermark", "Small faint logo", 4, "Client", "HUD", () -> s.watermark, v -> s.watermark = v);
        add("Crosshair", "Custom crosshair", 4, "Client", "Crosshair", () -> s.crosshair, v -> s.crosshair = v);
        add("Zoom", "Hold C to zoom", 4, "Client", "Extras", () -> s.zoom, v -> s.zoom = v);
        add("Waypoints", "Hologram markers", 2, "Marks", "Hologram", () -> s.marksWp, v -> s.marksWp = v);
        add("Death point", "Marks where you died", 2, "Marks", "Hologram", () -> s.marksDeath, v -> s.marksDeath = v);
        add("Auto scan", "Scans the chunk you look at", 0, "Scan", "Chunk", () -> s.autoScan, v -> s.autoScan = v);
        add("Chunk border", "Glowing chunk edges", 0, "Scan", "Border", () -> s.borders, v -> s.borders = v);
        add("Scan panel", "Scan results box", 1, "Panel", "Layout", () -> s.panel, v -> s.panel = v);
        add("Player list", "Players near you", 1, "Panel", "Players", () -> s.radar, v -> s.radar = v);
        add("Info panel", "Biome, light, facing", 1, "Panel", "Info", () -> s.info, v -> s.info = v);
        add("Chat filter", "Hides server spam", 3, "Chat", "Settings", () -> s.chatFilter, v -> s.chatFilter = v);
        add("Option styling", "Themed options screens", 4, "Client", "Extras", () -> s.styleVanilla, v -> s.styleVanilla = v);
        add("Loading screen", "Branded loading screens", 4, "Client", "Extras", () -> s.loadingScreen, v -> s.loadingScreen = v);
    }

    private void add(String name, String desc, int icon, String group, String sub, Supplier<Boolean> g, Consumer<Boolean> st) {
        mods.add(new Mod(name, desc, icon, group, sub, g, st));
    }

    private ButtonWidget hot(int x, int y, int w, int h, Runnable r) {
        ButtonWidget b = ButtonWidget.builder(Text.empty(), btn -> r.run()).dimensions(x, y, w, h).build();
        b.setAlpha(0f);
        return b;
    }

    @Override
    protected void init() {
        pw = Math.min(500, this.width - 20);
        ph = Math.min(290, this.height - 20);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
        int cols = pw >= 440 ? 3 : 2;
        cardW = (pw - 24 - (cols - 1) * GAP) / cols;
        int gridTop = py + 46, gridBottom = py + ph - 36;
        int rows = Math.max(1, (gridBottom - gridTop + GAP) / (CARD_H + GAP));
        int per = Math.min(cols * rows, cx.length);
        pageCount = Math.max(1, (mods.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pageCount - 1));
        count = 0;

        for (int k = 0; k < per; k++) {
            int idx = page * per + k;
            if (idx >= mods.size()) break;
            int x = px + 12 + (k % cols) * (cardW + GAP);
            int y = gridTop + (k / cols) * (CARD_H + GAP);
            cx[count] = x;
            cy[count] = y;
            ci[count] = idx;
            count++;
            Mod m = mods.get(idx);
            this.addDrawableChild(hot(x + cardW - 24, y + 2, 22, 20, () ->
                    MinecraftClient.getInstance().setScreen(SettingsScreen.at(m.group, m.sub, this))));
            this.addDrawableChild(hot(x, y, cardW, CARD_H, () -> {
                m.set.accept(!m.get.get());
                Settings.save();
            }));
        }

        footY = py + ph - 28;
        prevX = px + 12;
        String pg = (page + 1) + "/" + pageCount;
        nextX = px + 12 + 22 + 6 + this.textRenderer.getWidth(pg) + 6;
        doneX = px + pw - 12 - 70;
        setX = doneX - 6 - 90;
        this.addDrawableChild(hot(px + pw - 26, py + 10, 16, 16, this::close));
        this.addDrawableChild(hot(doneX, footY, 70, 20, this::close));
        this.addDrawableChild(hot(setX, footY, 90, 20, () ->
                MinecraftClient.getInstance().setScreen(SettingsScreen.at("Scan", "Chunk", this))));
        this.addDrawableChild(hot(prevX, footY, 22, 20, () -> {
            page = Math.max(0, page - 1);
            this.clearAndInit();
        }));
        this.addDrawableChild(hot(nextX, footY, 22, 20, () -> {
            page = Math.min(pageCount - 1, page + 1);
            this.clearAndInit();
        }));
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }

    private static boolean hit(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int tw(String s) {
        return this.textRenderer.getWidth(s);
    }

    private String fit(String s, int max) {
        if (tw(s) <= max) return s;
        while (s.length() > 1 && tw(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private void chip(DrawContext c, int x, int y, int w, int h, String label, boolean hov, boolean primary,
                      int card, int cardHov, int acc, int text) {
        int bg = primary ? Ui.shade(acc, hov ? -10 : -35) : (hov ? cardHov : card);
        Ui.rrect(c, x, y, w, h, 5, bg);
        c.drawTextWithShadow(this.textRenderer, label, x + (w - tw(label)) / 2, y + (h - 8) / 2, primary ? 0xFFFFFFFF : text);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        Settings s = Settings.get();
        Theme T = Theme.of(s.uiStyle);
        boolean neon = s.uiStyle == 1;
        int acc = s.accentColor();
        long now = System.currentTimeMillis();
        double dt = last == 0 ? 0.016 : Math.min(0.1, (now - last) / 1000.0);
        last = now;
        int panel = neon ? 0xFF101018 : T.panel;
        int card = neon ? 0xFF171722 : Ui.alpha(T.slot, 0xFF), cardHov = neon ? 0xFF20202F : Ui.alpha(T.slotH, 0xFF);
        int text = neon ? 0xFFEDEDF5 : T.text, muted = neon ? 0xFF8B8BA3 : T.muted;
        int off = 0xFF3A3A4E;

        c.fill(0, 0, this.width, this.height, 0xB8000000);
        Ui.rrect(c, px - 1, py - 1, pw + 2, ph + 2, 9, Ui.alpha(acc, 0x40));
        Ui.rrect(c, px, py, pw, ph, 8, Ui.alpha(panel, 0xF6));

        Ui.logo(c, px + 12, py + 10, 4, acc);
        c.drawTextWithShadow(this.textRenderer, "Daz Client", px + 36, py + 11, text);
        c.drawTextWithShadow(this.textRenderer, "Mods", px + 36, py + 22, muted);
        boolean xh = hit(mx, my, px + pw - 26, py + 10, 16, 16);
        Ui.rrect(c, px + pw - 26, py + 10, 16, 16, 4, xh ? cardHov : card);
        c.drawTextWithShadow(this.textRenderer, "x", px + pw - 18 - tw("x") / 2, py + 14, text);
        c.fill(px + 12, py + 38, px + pw - 12, py + 39, Ui.alpha(acc, 0x50));

        for (int k = 0; k < count; k++) {
            Mod m = mods.get(ci[k]);
            int x = cx[k], y = cy[k];
            boolean on = m.get.get();
            if (m.anim < 0) m.anim = on ? 1f : 0f;
            m.anim += ((on ? 1f : 0f) - m.anim) * (float) Math.min(1.0, dt * 14);
            boolean hov = hit(mx, my, x, y, cardW, CARD_H);
            Ui.rrect(c, x, y, cardW, CARD_H, 6, hov ? cardHov : card);
            if (on) Ui.rrect(c, x, y + 8, 3, CARD_H - 16, 1, acc);
            Ui.icon(c, m.icon, x + 10, y + 10, on ? acc : muted);
            c.drawTextWithShadow(this.textRenderer, fit(m.name, cardW - 60), x + 24, y + 9, text);
            c.drawTextWithShadow(this.textRenderer, fit(m.desc, cardW - 20), x + 10, y + 24, muted);
            boolean gh = hit(mx, my, x + cardW - 24, y + 2, 22, 20);
            Ui.icon(c, 6, x + cardW - 17, y + 9, gh ? text : muted);
            int tx = x + cardW - 38, ty = y + CARD_H - 15;
            Ui.rrect(c, tx, ty, 28, 11, 5, lerp(off, acc, m.anim));
            Ui.rrect(c, tx + 1 + (int) (m.anim * 17), ty + 1, 9, 9, 4, 0xFFFFFFFF);
        }

        String pg = (page + 1) + "/" + pageCount;
        chip(c, prevX, footY, 22, 20, "<", hit(mx, my, prevX, footY, 22, 20), false, card, cardHov, acc, text);
        c.drawTextWithShadow(this.textRenderer, pg, prevX + 28, footY + 6, muted);
        chip(c, nextX, footY, 22, 20, ">", hit(mx, my, nextX, footY, 22, 20), false, card, cardHov, acc, text);
        chip(c, setX, footY, 90, 20, "All settings", hit(mx, my, setX, footY, 90, 20), false, card, cardHov, acc, text);
        chip(c, doneX, footY, 70, 20, "Done", hit(mx, my, doneX, footY, 70, 20), true, card, cardHov, acc, text);
    }
}
