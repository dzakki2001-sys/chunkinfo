package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Hologram waypoints: drawn on the HUD, so they show through walls and from far away. */
public class WaypointHud {

    public static void render(DrawContext c, MinecraftClient mc) {
        Settings s = Settings.get();
        if (!(s.marksDeath || s.marksWp)) return;
        if (mc.world == null || mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;

        String server = Marks.server(mc), dim = Marks.dim(mc);
        Data d = Data.get();
        List<Data.Mark> list = new ArrayList<>();
        if (s.marksDeath && d.death != null && d.death.server.equals(server) && d.death.dim.equals(dim)) {
            list.add(d.death);
        }
        if (s.marksWp) {
            for (Data.Mark m : d.marks) if (m.server.equals(server) && m.dim.equals(dim)) list.add(m);
        }
        if (list.isEmpty()) return;

        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        Vec3d eye = mc.player.getEyePos();

        double yaw = Math.toRadians(mc.player.getYaw());
        double pitch = Math.toRadians(mc.player.getPitch());
        double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        // camera basis: forward, right, up
        double fx = -sy * cp, fy = -sp, fz = cy * cp;
        double rx = -cy, rz = -sy;
        double ux = -sy * sp, uy = cp, uz = cy * sp;

        double fov = mc.options.getFov().getValue();
        double tanH = Math.tan(Math.toRadians(fov) / 2.0);
        double aspect = (double) sw / sh;
        double t = System.currentTimeMillis() / 1000.0;
        int acc = s.accentColor();
        int R = 12 + 3 * Math.max(1, Math.min(3, s.marksSize));

        for (Data.Mark m : list) {
            double dx = m.x + 0.5 - eye.x, dy = m.y + 1.0 - eye.y, dz = m.z + 0.5 - eye.z;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (s.marksRange < 5000 && dist > s.marksRange) continue;
            if (dist < 1.5) continue;

            double xc = dx * rx + dz * rz;
            double yc = dx * ux + dy * uy + dz * uz;
            double zc = dx * fx + dy * fy + dz * fz;

            boolean front = zc > 0.1;
            double px, py;
            if (front) {
                px = sw / 2.0 + ((xc / zc) / (tanH * aspect)) * sw / 2.0;
                py = sh / 2.0 - ((yc / zc) / tanH) * sh / 2.0;
            } else {
                px = sw / 2.0 + xc * 1000;
                py = sh / 2.0 - yc * 1000;
            }

            boolean on = front && px > 24 && px < sw - 24 && py > 30 && py < sh - 50;
            if (!on) {
                double vx = px - sw / 2.0, vy = py - sh / 2.0;
                if (Math.abs(vx) < 1e-6 && Math.abs(vy) < 1e-6) vy = 1;
                double scale = Math.min((sw / 2.0 - 26) / Math.max(1e-6, Math.abs(vx)),
                        (sh / 2.0 - 46) / Math.max(1e-6, Math.abs(vy)));
                px = sw / 2.0 + vx * scale;
                py = sh / 2.0 + vy * scale;
            }

            boolean death = m == d.death;
            int col = death ? 0xFFFF5A5A : acc;
            String distText = dist >= 1000 ? String.format("%.1fkm", dist / 1000.0) : Math.round(dist) + "m";
            holo(c, tr, Icons.stack(m, death), (int) px, (int) py, on ? R : 11, col,
                    on ? m.name : null, distText, s.marksAnim, t, sw, sh);
        }
    }

    private static void holo(DrawContext c, TextRenderer tr, ItemStack stack, int cx, int cy, int R, int col,
                             String name, String dist, boolean anim, double t, int sw, int sh) {
        double flick = anim ? 0.88 + 0.12 * Math.sin(t * 14) : 1.0;
        int aEdge = (int) (230 * flick);

        // expanding pulse ring
        if (anim) {
            double ph = (t * 0.9) % 1.0;
            diamond(c, cx, cy, R + (int) (ph * 9), col, (int) (150 * (1 - ph)), 0, t, false);
        }
        // hologram body behind the icon
        diamond(c, cx, cy, R, col, aEdge, 0x40, t, anim);

        // tick marks on the four corners of the diamond
        int tk = Ui.alpha(col, aEdge) ;
        c.fill(cx - 1, cy - R - 4, cx + 1, cy - R - 1, tk);
        c.fill(cx - 1, cy + R + 2, cx + 1, cy + R + 5, tk);
        c.fill(cx - R - 4, cy - 1, cx - R - 1, cy + 1, tk);
        c.fill(cx + R + 2, cy - 1, cx + R + 5, cy + 1, tk);

        // two sparkles orbiting the diamond
        if (anim) {
            for (int k = 0; k < 2; k++) {
                for (int trail = 0; trail < 4; trail++) {
                    double a = t * 1.7 + k * Math.PI - trail * 0.18;
                    int sx = cx + (int) Math.round(Math.cos(a) * (R + 7));
                    int sy = cy + (int) Math.round(Math.sin(a) * (R + 7));
                    int sz = trail == 0 ? 2 : 1;
                    c.fill(sx, sy, sx + sz, sy + sz, Ui.alpha(0xFFFFFFFF, 230 - trail * 55));
                }
            }
        }

        // the item icon
        c.drawItem(stack, cx - 8, cy - 8);

        // beam under the icon
        for (int k = 0; k < 4; k++) {
            c.fill(cx, cy + R + 6 + k * 3, cx + 1, cy + R + 8 + k * 3, Ui.alpha(col, 160 - k * 36));
        }

        // label card
        String l1 = name == null ? dist : name;
        String l2 = name == null ? null : dist;
        int w = Math.max(tr.getWidth(l1), l2 == null ? 0 : tr.getWidth(l2)) + 12;
        int h = l2 == null ? 14 : 24;
        int x = Math.max(2, Math.min(sw - w - 2, cx - w / 2));
        int y = Math.max(2, Math.min(sh - h - 2, cy + R + 20));

        c.fill(x, y, x + w, y + h, 0x99070C14);
        int edge = Ui.alpha(col, 170);
        c.fill(x, y, x + w, y + 1, edge);
        c.fill(x, y + h - 1, x + w, y + h, edge);
        c.fill(x, y, x + 1, y + h, edge);
        c.fill(x + w - 1, y, x + w, y + h, edge);
        // bright corners
        c.fill(x, y, x + 4, y + 1, 0xFFFFFFFF);
        c.fill(x, y, x + 1, y + 4, 0xFFFFFFFF);
        c.fill(x + w - 4, y + h - 1, x + w, y + h, 0xFFFFFFFF);
        c.fill(x + w - 1, y + h - 4, x + w, y + h, 0xFFFFFFFF);
        // small diamonds on the sides
        Ui.diamondDot(c, x - 4, y + h / 2, col);
        Ui.diamondDot(c, x + w + 4, y + h / 2, col);
        // scanlines + moving highlight
        for (int r = 1; r < h - 1; r += 2) c.fill(x + 1, y + r, x + w - 1, y + r + 1, Ui.alpha(col, 22));
        if (anim) {
            int band = (int) ((t * 20) % (h + 8)) - 4;
            for (int r = 0; r < 2; r++) {
                int yy = y + band + r;
                if (yy > y && yy < y + h - 1) c.fill(x + 1, yy, x + w - 1, yy + 1, Ui.alpha(col, 60));
            }
        }

        c.drawTextWithShadow(tr, l1, x + (w - tr.getWidth(l1)) / 2, y + 3, name == null ? col : 0xFFFFFFFF);
        if (l2 != null) c.drawTextWithShadow(tr, l2, x + (w - tr.getWidth(l2)) / 2, y + 13, col);
    }

    private static void diamond(DrawContext c, int cx, int cy, int R, int col, int aEdge, int aFill, double t, boolean anim) {
        for (int dy = -R; dy <= R; dy++) {
            int half = R - Math.abs(dy);
            int yy = cy + dy;
            if (aFill > 0 && half > 1) {
                boolean scan = !anim || (((dy + (int) (t * 10)) & 1) == 0);
                c.fill(cx - half + 1, yy, cx + half, yy + 1, Ui.alpha(col, scan ? aFill : aFill / 3));
            }
            c.fill(cx - half, yy, cx - half + 1, yy + 1, Ui.alpha(col, aEdge));
            c.fill(cx + half, yy, cx + half + 1, yy + 1, Ui.alpha(col, aEdge));
            if (aFill > 0) {
                c.fill(cx - half - 1, yy, cx - half, yy + 1, Ui.alpha(col, aEdge / 3));
                c.fill(cx + half + 1, yy, cx + half + 2, yy + 1, Ui.alpha(col, aEdge / 3));
            }
        }
    }
}
