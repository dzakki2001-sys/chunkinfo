package com.example.chunkinfo;

import net.minecraft.client.gui.DrawContext;

public final class Ui {
    private Ui() {}

    public static int alpha(int color, int a) {
        return ((a & 0xFF) << 24) | (color & 0xFFFFFF);
    }

    /** Add (or subtract, if negative) a value to every colour channel. */
    public static int shade(int color, int d) {
        int a = (color >> 24) & 0xFF;
        int r = Math.max(0, Math.min(255, ((color >> 16) & 0xFF) + d));
        int g = Math.max(0, Math.min(255, ((color >> 8) & 0xFF) + d));
        int b = Math.max(0, Math.min(255, (color & 0xFF) + d));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    public static void outlined(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(c, x - 1, y - 1, w + 2, h + 2, r + 1, border);
        rrect(c, x, y, w, h, r, fill);
    }

    public static void hfade(DrawContext c, int x, int y, int w, int h, int color, int aFrom, int aTo) {
        int seg = 3;
        for (int i = 0; i < w; i += seg) {
            float f = (float) i / Math.max(1, w);
            int a = (int) (aFrom + (aTo - aFrom) * f);
            c.fill(x + i, y, Math.min(x + w, x + i + seg), y + h, alpha(color, a));
        }
    }

    public static int opaque(int color) {
        return 0xFF000000 | (color & 0xFFFFFF);
    }

    /** Vanilla-GUI style box: 1px border, light/dark bevel. Swap tl/br for an inset slot. */
    public static void bevel(DrawContext c, int x, int y, int w, int h, int fill, int tl, int br, int border) {
        c.fill(x, y, x + w, y + 1, border);
        c.fill(x, y + h - 1, x + w, y + h, border);
        c.fill(x, y + 1, x + 1, y + h - 1, border);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, border);
        c.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
        c.fill(x + 1, y + 1, x + w - 1, y + 2, tl);
        c.fill(x + 1, y + 2, x + 2, y + h - 2, tl);
        c.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, br);
        c.fill(x + w - 2, y + 2, x + w - 1, y + h - 2, br);
    }

    private static void box(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2), color);
    }

    /** Pixel corner flourish. dx / dy = +1 or -1 = which way the corner points into the panel. */
    public static void corner(DrawContext c, int x, int y, int dx, int dy, int col, int len) {
        int a = alpha(col, 0xD0);
        int b = alpha(col, 0x70);
        box(c, x, y, x + dx * len, y + dy, a);
        box(c, x, y, x + dx, y + dy * len, a);
        box(c, x + dx * 2, y + dy * 2, x + dx * (len - 1), y + dy * 3, b);
        box(c, x + dx * 2, y + dy * 2, x + dx * 3, y + dy * (len - 1), b);
        box(c, x + dx * 3, y + dy * 3, x + dx * 4, y + dy * 4, alpha(col, 0xFF));
    }

    /** Tiny 5px diamond. */
    public static void diamondDot(DrawContext c, int x, int y, int col) {
        c.fill(x - 2, y, x + 3, y + 1, alpha(col, 0xE0));
        c.fill(x - 1, y - 1, x + 2, y, alpha(col, 0xB0));
        c.fill(x - 1, y + 1, x + 2, y + 2, alpha(col, 0xB0));
        c.fill(x, y - 2, x + 1, y - 1, alpha(col, 0x80));
        c.fill(x, y + 2, x + 1, y + 3, alpha(col, 0x80));
    }

    /** Small chunk-grid logo: 3x3 cells, bright centre. Size = 3*cell + 6. */
    public static void logo(DrawContext c, int x, int y, int cell, int accent) {
        int s = 3 * cell + 6;
        bevel(c, x, y, s, s, 0xFF10131A, 0xFF0B0D13, 0xFF3A4357, 0xFF0B0D13);
        for (int gy = 0; gy < 3; gy++) {
            for (int gx = 0; gx < 3; gx++) {
                int px = x + 2 + gx * (cell + 1);
                int py = y + 2 + gy * (cell + 1);
                boolean ctr = gx == 1 && gy == 1;
                int col = ctr ? shade(accent, 30) : alpha(accent, 0x50 + ((gx + gy) % 2) * 0x28);
                c.fill(px, py, px + cell, py + cell, col);
            }
        }
    }

    /** Copper-style frame with corner studs (like the highlighted furnace output slot). */
    public static void studFrame(DrawContext c, int x, int y, int w, int h, int col) {
        int stud = shade(col, 45);
        c.fill(x, y, x + w, y + 2, col);
        c.fill(x, y + h - 2, x + w, y + h, col);
        c.fill(x, y, x + 2, y + h, col);
        c.fill(x + w - 2, y, x + w, y + h, col);
        c.fill(x - 1, y - 1, x + 3, y + 3, stud);
        c.fill(x + w - 3, y - 1, x + w + 1, y + 3, stud);
        c.fill(x - 1, y + h - 3, x + 3, y + h + 1, stud);
        c.fill(x + w - 3, y + h - 3, x + w + 1, y + h + 1, stud);
    }
}
