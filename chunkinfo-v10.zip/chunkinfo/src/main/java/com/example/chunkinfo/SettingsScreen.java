package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class SettingsScreen extends Screen {
    // Neon style colours
    private static final int BG = 0xF2101018, SIDE = 0xFF0C0C13, SURF = 0xFF171722, SURF_H = 0xFF20202F,
            LINE = 0xFF2B2B3F, OFF = 0xFF34344A, GREEN = 0xFF4ADE80, AMBER = 0xFFFBBF24;
    private Theme T = Theme.of(0);
    private static final String[] TABS = {"Scan", "Border", "Panel", "Players", "Blocks", "Marks",
            "Chat", "History", "Info", "Keys"};

    private int tab = 0, accent, chatMode = 0;
    private final int[] pages = new int[TABS.length];
    private boolean prevY, leftDown, clicked, dirty, pendingClick, mand;
    private int cText, cMuted;
    private double pendingX, pendingY, clickX, clickY;
    private int mx, my;
    private String dragId = null;

    public static final int MARKS_TAB = 5;
    private TextFieldWidget nameField;
    private Data.Mark editMark = null, pendingEdit = null;
    private String editBuffer = "";
    private int marksView = 0;

    // content area
    private int cx, cy, cw, ch, colW;

    public SettingsScreen() {
        super(Text.literal("Chunk Info"));
    }

    /** Open on a tab, optionally straight into the waypoint editor. */
    public SettingsScreen(int startTab, Data.Mark edit) {
        super(Text.literal("Chunk Info"));
        this.tab = startTab;
        this.pendingEdit = edit;
    }

    @Override
    protected void init() {
        // Name field first, so it gets clicks before the full-screen catcher below.
        nameField = new TextFieldWidget(this.textRenderer, 0, 0, 100, 12, Text.empty());
        nameField.setMaxLength(24);
        nameField.setDrawsBackground(false);
        nameField.visible = false;
        this.addDrawableChild(nameField);

        // Invisible full-screen button: the game's own click handling feeds us clicks and taps.
        ButtonWidget catcher = ButtonWidget.builder(Text.empty(), b -> onCatch())
                .dimensions(0, 0, this.width, this.height).build();
        catcher.setAlpha(0f);
        this.addDrawableChild(catcher);
        prevY = keyDown(GLFW.GLFW_KEY_Y);

        if (pendingEdit != null) {
            startEdit(pendingEdit);
            pendingEdit = null;
        } else if (editMark != null) {
            startEdit(editMark);
            nameField.setText(editBuffer);
        }
    }

    private void onCatch() {
        MinecraftClient mc = MinecraftClient.getInstance();
        pendingX = mc.mouse.getX() * mc.getWindow().getScaledWidth() / (double) mc.getWindow().getWidth();
        pendingY = mc.mouse.getY() * mc.getWindow().getScaledHeight() / (double) mc.getWindow().getHeight();
        pendingClick = true;
    }

    private boolean keyDown(int key) {
        return GLFW.glfwGetKey(MinecraftClient.getInstance().getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
    }

    private boolean mouseDown() {
        return GLFW.glfwGetMouseButton(MinecraftClient.getInstance().getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private boolean typing() {
        return editMark != null && nameField != null && nameField.isFocused();
    }

    private void startEdit(Data.Mark m) {
        editMark = m;
        editBuffer = m.name;
        if (nameField != null) {
            nameField.setText(m.name);
            nameField.visible = true;
            nameField.setFocused(true);
            this.setFocused(nameField);
        }
    }

    private void endEdit(boolean save) {
        if (editMark != null && save && nameField != null) {
            String n = nameField.getText().trim();
            if (!n.isEmpty()) editMark.name = n;
            Data.save();
        }
        editMark = null;
        if (nameField != null) {
            nameField.visible = false;
            nameField.setFocused(false);
        }
        this.setFocused(null);
    }

    public boolean shouldPause() {
        return false;
    }

    public void removed() {
        Settings.save();
        Data.save();
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        pages[tab] += verticalAmount < 0 ? 1 : -1;
        return true;
    }

    // ---------- helpers ----------

    private static boolean hit(double px, double py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private boolean hov(int x, int y, int w, int h) {
        return hit(mx, my, x, y, w, h);
    }

    private boolean clk(int x, int y, int w, int h) {
        return clicked && hit(clickX, clickY, x, y, w, h);
    }

    private void text(DrawContext c, String s, int x, int y, int color) {
        c.drawTextWithShadow(this.textRenderer, s, x, y, color);
    }

    private int tw(String s) {
        return this.textRenderer.getWidth(s);
    }

    private String fit(String s, int max) {
        if (tw(s) <= max) return s;
        while (s.length() > 1 && tw(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private int cellX(int i) {
        return cx + (i % 2) * (colW + 8);
    }

    private int cellY(int i) {
        return cy + 24 + (i / 2) * 28;
    }

    private static float snap(float v, float step) {
        return Math.round(v / step) * step;
    }

    private int valColor() {
        return mand ? Ui.shade(accent, 25) : accent;
    }

    /** Background of a control row. Mandala: inset slot. Neon: rounded card. */
    private void card(DrawContext c, int x, int y, int w, int h, boolean hv) {
        if (mand) Ui.bevel(c, x, y, w, h, hv ? T.slotH : T.slot, T.slotDk, T.slotLt, T.border);
        else Ui.rrect(c, x, y, w, h, 5, hv ? SURF_H : SURF);
    }

    // ---------- controls ----------

    private boolean toggle(DrawContext c, String label, boolean v, int x, int y, int w, int dot) {
        boolean h = hov(x, y, w, 24);
        card(c, x, y, w, 24, h);
        int tx = x + 8;
        if (dot != 0) {
            Ui.rrect(c, x + 8, y + 10, 4, 4, 2, dot);
            tx = x + 17;
        }
        text(c, fit(label, w - 34 - (tx - x)), tx, y + 8, cText);
        if (mand) {
            int bx = x + w - 22, by = y + 5;
            Ui.bevel(c, bx, by, 14, 14, T.well, T.dark, T.slotLt, T.border);
            if (v) {
                c.fill(bx + 3, by + 3, bx + 11, by + 11, accent);
                c.fill(bx + 3, by + 3, bx + 11, by + 4, Ui.shade(accent, 60));
                c.fill(bx + 3, by + 10, bx + 11, by + 11, Ui.shade(accent, -50));
            }
        } else {
            int sx = x + w - 30, sy = y + 7;
            Ui.rrect(c, sx, sy, 22, 10, 5, v ? accent : OFF);
            Ui.rrect(c, sx + (v ? 12 : 0), sy, 10, 10, 5, 0xFFFFFFFF);
        }
        if (clk(x, y, w, 24)) {
            dirty = true;
            return !v;
        }
        return v;
    }

    private float slider(DrawContext c, String id, String label, String val, float v, float min, float max, int x, int y, int w) {
        boolean h = hov(x, y, w, 24) || id.equals(dragId);
        card(c, x, y, w, 24, h);
        text(c, label, x + 8, y + 4, cText);
        text(c, val, x + w - 8 - tw(val), y + 4, valColor());
        int tx = x + 8, tw = w - 16, ty = y + 17;
        float f = Math.max(0f, Math.min(1f, (v - min) / (max - min)));
        if (mand) {
            Ui.bevel(c, tx, ty - 1, tw, 5, T.well, T.dark, T.slotLt, T.border);
            int fw = (int) ((tw - 2) * f);
            if (fw > 0) c.fill(tx + 1, ty, tx + 1 + fw, ty + 3, accent);
            Ui.bevel(c, tx + (int) ((tw - 7) * f), ty - 4, 7, 10, Ui.shade(T.btnLt, 20), Ui.shade(T.btnLt, 70), T.slotLt, T.border);
        } else {
            Ui.rrect(c, tx, ty, tw, 3, 1, OFF);
            Ui.rrect(c, tx, ty, Math.max(2, (int) (tw * f)), 3, 1, accent);
            Ui.rrect(c, tx + (int) (tw * f) - 3, ty - 2, 6, 7, 3, 0xFFFFFFFF);
        }

        if (clk(x, y, w, 24)) {
            dragId = id;
            dirty = true;
            return min + Math.max(0f, Math.min(1f, (float) (clickX - tx) / tw)) * (max - min);
        }
        if (leftDown && id.equals(dragId)) {
            dirty = true;
            return min + Math.max(0f, Math.min(1f, (float) (mx - tx) / tw)) * (max - min);
        }
        return v;
    }

    private int cycle(DrawContext c, String label, String[] opts, int cur, int x, int y, int w) {
        boolean h = hov(x, y, w, 24);
        card(c, x, y, w, 24, h);
        text(c, label, x + 8, y + 8, cText);
        String val = "< " + opts[Math.floorMod(cur, opts.length)] + " >";
        text(c, val, x + w - 8 - tw(val), y + 8, valColor());
        if (clk(x, y, w, 24)) {
            dirty = true;
            return (cur + 1) % opts.length;
        }
        return cur;
    }

    private boolean button(DrawContext c, String label, int x, int y, int w, int h, boolean primary) {
        boolean hv = hov(x, y, w, h);
        if (mand) {
            int fill = primary ? Ui.shade(accent, hv ? -20 : -45) : (hv ? T.btnH : T.btn);
            Ui.bevel(c, x, y, w, h, fill, primary ? Ui.shade(accent, 60) : T.btnLt,
                    primary ? Ui.shade(accent, -90) : T.dark, T.border);
        } else {
            int bg = primary ? Ui.alpha(accent, hv ? 0xFF : 0xCC) : (hv ? SURF_H : SURF);
            Ui.rrect(c, x, y, w, h, 5, bg);
        }
        text(c, label, x + (w - tw(label)) / 2, y + (h - 8) / 2, primary ? 0xFFFFFFFF : cText);
        return clk(x, y, w, h);
    }

    /** One list row with a small button on the right. Returns true if that button was clicked. */
    private boolean listRow(DrawContext c, int x, int y, int w, String label, String btn) {
        card(c, x, y, w, 20, false);
        int bw = tw(btn) + 10;
        text(c, fit(label, w - bw - 18), x + 8, y + 6, cText);
        int bx = x + w - bw - 3, by = y + 2;
        boolean hv = hov(bx, by, bw, 16);
        if (mand) Ui.bevel(c, bx, by, bw, 16, hv ? T.btnH : T.btn, T.btnLt, T.dark, T.border);
        else Ui.rrect(c, bx, by, bw, 16, 4, hv ? SURF_H : OFF);
        text(c, btn, bx + 5, by + 4, cText);
        return clk(bx, by, bw, 16);
    }

    private int pager(DrawContext c, int page, int pageCount, int x, int y) {
        int n = Math.max(1, pageCount);
        if (button(c, "<", x, y, 20, 20, false)) page--;
        String pg = (Math.max(0, Math.min(page, n - 1)) + 1) + "/" + n;
        text(c, pg, x + 26, y + 6, cMuted);
        if (button(c, ">", x + 28 + tw(pg), y, 20, 20, false)) page++;
        return Math.max(0, Math.min(page, n - 1));
    }

    private int listRows(int listTop) {
        return Math.max(1, (cy + ch - 26 - listTop) / 22);
    }

    /** Rotating flower ornament. R is chosen from the free space, so it never gets covered. */
    private void ornament(DrawContext c, int mcx, int mcy, int R, long tms, int col) {
        double t = tms / 1000.0;
        double rotA = t * 0.25, rotB = -t * 0.4, rotC = t * 0.7;

        // outer ring of dots
        int nA = Math.max(16, R);
        for (int i = 0; i < nA; i++) {
            double a = rotA + i * Math.PI * 2 / nA;
            int x = mcx + (int) Math.round(Math.cos(a) * R * 0.95);
            int y = mcy + (int) Math.round(Math.sin(a) * R * 0.95);
            boolean big = i % 4 == 0;
            c.fill(x, y, x + (big ? 2 : 1), y + (big ? 2 : 1), Ui.alpha(col, big ? 0xB0 : 0x55));
        }

        if (R >= 16) {
            // eight petals
            for (int p = 0; p < 8; p++) {
                double a = rotB + p * Math.PI / 4;
                double ca = Math.cos(a), sa = Math.sin(a);
                for (int k = 0; k < 5; k++) {
                    double rr = R * (0.38 + 0.1 * k);
                    int x = mcx + (int) Math.round(ca * rr);
                    int y = mcy + (int) Math.round(sa * rr);
                    c.fill(x, y, x + 1, y + 1, Ui.alpha(col, 0x70 + k * 0x18));
                    if (k == 1 || k == 2 || k == 3) {
                        double off = k == 2 ? 2.5 : 1.5;
                        int x1 = mcx + (int) Math.round(ca * rr - sa * off);
                        int y1 = mcy + (int) Math.round(sa * rr + ca * off);
                        int x2 = mcx + (int) Math.round(ca * rr + sa * off);
                        int y2 = mcy + (int) Math.round(sa * rr - ca * off);
                        c.fill(x1, y1, x1 + 1, y1 + 1, Ui.alpha(col, 0x60));
                        c.fill(x2, y2, x2 + 1, y2 + 1, Ui.alpha(col, 0x60));
                    }
                }
            }
            // inner ring
            for (int q = 0; q < 12; q++) {
                double a = rotC + q * Math.PI / 6;
                int x = mcx + (int) Math.round(Math.cos(a) * R * 0.27);
                int y = mcy + (int) Math.round(Math.sin(a) * R * 0.27);
                c.fill(x, y, x + 1, y + 1, Ui.alpha(col, 0x90));
            }
        }

        // pulsing centre
        double pulse = 0.5 + 0.5 * Math.sin(t * 2.2);
        Ui.diamondDot(c, mcx, mcy, Ui.shade(col, (int) (40 * pulse)));
        c.fill(mcx, mcy, mcx + 1, mcy + 1, Ui.alpha(0xFFFFFFFF, 0x90 + (int) (100 * pulse)));
    }

    // ---------- render ----------

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Settings s = Settings.get();
        mx = mouseX;
        my = mouseY;
        long t = System.currentTimeMillis();

        boolean down = mouseDown();
        leftDown = down;
        boolean yd = keyDown(GLFW.GLFW_KEY_Y);
        if (yd && !prevY && !typing()) {
            this.close();
            return;
        }
        prevY = yd;

        clicked = pendingClick;
        clickX = pendingX;
        clickY = pendingY;
        pendingClick = false;
        if (!down && !clicked) {
            dragId = null;
            if (dirty) {
                Settings.save();
                dirty = false;
            }
        }

        accent = s.accentColor();
        mand = s.uiStyle != 1;
        T = Theme.of(s.uiStyle);
        cText = mand ? T.text : 0xFFEDEDF5;
        cMuted = mand ? T.muted : 0xFF8B8BA3;

        ctx.fill(0, 0, this.width, this.height, mand ? 0x99000000 : 0xB0000000);

        int pw = Math.min(440, this.width - 16);
        int ph = Math.min(250, this.height - 16);
        int px = (this.width - pw) / 2;
        int py = (this.height - ph) / 2;
        int sw = 100;
        int top = mand ? 20 : 6;

        if (mand) {
            Ui.bevel(ctx, px, py, pw, ph, T.panel, T.light, T.dark, T.border);
            Fx.draw(ctx, T.fx, px + 2, py + 2, pw - 4, ph - 4, t / 1000.0, accent);
            Ui.corner(ctx, px + 3, py + 3, 1, 1, accent, 8);
            Ui.corner(ctx, px + pw - 3, py + 3, -1, 1, accent, 8);
            Ui.corner(ctx, px + 3, py + ph - 4, 1, -1, accent, 8);
            Ui.corner(ctx, px + pw - 3, py + ph - 4, -1, -1, accent, 8);
            String title = "Chunk Info";
            text(ctx, title, px + (pw - tw(title)) / 2, py + 8, T.title);
            // close button
            int bx = px + pw - 26, by = py + 5;
            boolean hv = hov(bx, by, 16, 14);
            Ui.bevel(ctx, bx, by, 16, 14, hv ? T.btnH : T.btn, T.btnLt, T.dark, T.border);
            text(ctx, "x", bx + 8 - tw("x") / 2, by + 3, cText);
            if (clk(bx, by, 16, 14)) {
                this.close();
                return;
            }
            // sidebar well
            Ui.bevel(ctx, px + 6, py + top, sw, ph - top - 6, T.side, T.sideDk, T.sideLt, T.border);
        } else {
            Ui.rrect(ctx, px - 2, py - 2, pw + 4, ph + 4, 9, Ui.alpha(accent, 0x55));
            Ui.outlined(ctx, px, py, pw, ph, 7, BG, LINE);
            Ui.corner(ctx, px + 3, py + 3, 1, 1, accent, 8);
            Ui.corner(ctx, px + pw - 3, py + 3, -1, 1, accent, 8);
            Ui.corner(ctx, px + 3, py + ph - 4, 1, -1, accent, 8);
            Ui.corner(ctx, px + pw - 3, py + ph - 4, -1, -1, accent, 8);
            Ui.rrect(ctx, px + 6, py + 6, sw, ph - 12, 6, SIDE);
        }

        // circle ornament + logo (both styles)
        int tabRows = (TABS.length + 1) / 2;
        int tabsBottom = py + top + 34 + (tabRows - 1) * 20 + 17;
        int freeTop = tabsBottom + 5;
        int freeBottom = py + ph - 6 - 5;
        int freeH = freeBottom - freeTop;
        int orR = Math.min(freeH / 2, (sw - 10) / 2);
        if (orR >= 12) ornament(ctx, px + 6 + sw / 2, freeTop + freeH / 2, orR, t, accent);
        Ui.logo(ctx, px + 11, py + top + 4, 6, accent);
        text(ctx, "Chunk", px + 40, py + top + 7, valColor());
        text(ctx, "Info", px + 40, py + top + 18, cText);

        // tabs: two columns
        int tabW = 44;
        for (int i = 0; i < TABS.length; i++) {
            int tx = px + 10 + (i % 2) * (tabW + 3), ty = py + top + 34 + (i / 2) * 20;
            boolean act = tab == i;
            boolean hv = hov(tx, ty, tabW, 17);
            String name = TABS[i];
            int nx = tx + (tabW - tw(name)) / 2;
            if (mand) {
                Ui.bevel(ctx, tx, ty, tabW, 17,
                        act ? T.slot : (hv ? T.tabH : T.tab),
                        act ? T.slotDk : T.tabLt,
                        act ? T.slotLt : T.tabDk, T.border);
                if (act) Ui.studFrame(ctx, tx, ty, tabW, 17, accent);
                text(ctx, name, nx, ty + 5, act ? 0xFFFFFFFF : T.title);
            } else {
                if (act) Ui.rrect(ctx, tx, ty, tabW, 17, 5, Ui.alpha(accent, 0x30));
                else if (hv) Ui.rrect(ctx, tx, ty, tabW, 17, 5, 0xFF16161F);
                text(ctx, name, nx, ty + 5, act ? cText : cMuted);
            }
            if (clk(tx, ty, tabW, 17)) tab = i;
        }

        // content area
        cx = px + sw + 18;
        cy = py + top + (mand ? 4 : 8);
        cw = pw - sw - 30;
        ch = ph - (cy - py) - 14;
        colW = (cw - 8) / 2;

        text(ctx, TABS[tab].toUpperCase(), cx, cy, mand ? T.title : cText);
        if (mand) {
            ctx.fill(cx, cy + 11, cx + cw, cy + 12, T.dark);
            ctx.fill(cx, cy + 12, cx + cw, cy + 13, T.light);
        } else {
            Ui.hfade(ctx, cx, cy + 11, cw, 1, accent, 255, 0);
        }
        Ui.diamondDot(ctx, cx + cw - 5, cy + 11, accent);

        String tn = TABS[tab];
        if (tn.equals("Scan")) drawScanTab(ctx, s);
        else if (tn.equals("Border")) drawBorderTab(ctx, s);
        else if (tn.equals("Panel")) drawPanelTab(ctx, s);
        else if (tn.equals("Players")) drawPlayersTab(ctx, s);
        else if (tn.equals("Blocks")) drawBlocksTab(ctx, s);
        else if (tn.equals("Marks")) drawMarksTab(ctx, s);
        else if (tn.equals("Chat")) drawChatTab(ctx, s);
        else if (tn.equals("History")) drawHistoryTab(ctx, s);
        else if (tn.equals("Info")) drawInfoTab(ctx, s);
        else drawKeysTab(ctx);

        String foot = "Y / Esc to close";
        text(ctx, foot, px + pw - 10 - tw(foot), py + ph - 13, cMuted);
    }

    // ---------- tabs ----------

    private void drawScanTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.autoScan = toggle(ctx, "Auto scan", s.autoScan, cellX(i), cellY(i), colW, 0);
        i++;
        s.scanTarget = cycle(ctx, "Scan target", Settings.SCAN_TARGETS, s.scanTarget, cellX(i), cellY(i), colW);
        i++;
        s.autoTicks = Math.round(slider(ctx, "autoticks", "Auto scan rate", s.autoTicks + " ticks", s.autoTicks, 5, 60,
                cellX(i), cellY(i), colW));
        text(ctx, "Auto scan checks one chunk and updates the panel for you.", cx, cellY(4) - 4, cMuted);
        text(ctx, "Looking at = chunk under your crosshair. Standing in = your chunk.", cx, cellY(4) + 8, cMuted);
        text(ctx, "G scans once with the same target. K clears everything.", cx, cellY(4) + 20, cMuted);
    }

    private void drawBorderTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.borders = toggle(ctx, "Show border", s.borders, cellX(i), cellY(i), colW, 0);
        i++;
        s.style = cycle(ctx, "Style", Settings.STYLES, s.style, cellX(i), cellY(i), colW);
        i++;
        s.gap = snap(slider(ctx, "gap", "Particle gap", String.format("%.2f", s.gap), s.gap, 0.2f, 2.0f,
                cellX(i), cellY(i), colW), 0.05f);
        i++;
        s.pulseTicks = Math.round(slider(ctx, "pulse", "Update rate", s.pulseTicks + " ticks", s.pulseTicks, 2, 20,
                cellX(i), cellY(i), colW));
        i++;
        s.heightRange = Math.round(slider(ctx, "height", "Height range", "+-" + s.heightRange, s.heightRange, 16, 128,
                cellX(i), cellY(i), colW) / 4f) * 4;
        i++;
        s.maxChunks = Math.round(slider(ctx, "dist", "Max distance", s.maxChunks + " chunks", s.maxChunks, 2, 16,
                cellX(i), cellY(i), colW));
        i++;
        s.rings = toggle(ctx, "Ring lines", s.rings, cellX(i), cellY(i), colW, 0);
        i++;
        s.ringEvery = Math.round(slider(ctx, "ring", "Ring spacing", s.ringEvery + " blocks", s.ringEvery, 4, 32,
                cellX(i), cellY(i), colW) / 2f) * 2;
        i++;
        s.dustSize = snap(slider(ctx, "dust", "Dust size", String.format("%.1f", s.dustSize), s.dustSize, 1f, 4f,
                cellX(i), cellY(i), colW), 0.5f);
        i++;
        s.showClean = toggle(ctx, "Clean chunk border", s.showClean, cellX(i), cellY(i), colW, 0);
    }

    private void drawPanelTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.panel = toggle(ctx, "Show scan results", s.panel, cellX(i), cellY(i), colW, 0);
        i++;
        s.showCoords = toggle(ctx, "Show coordinates", s.showCoords, cellX(i), cellY(i), colW, 0);
        i++;
        s.panelPos = cycle(ctx, "Panel position", Settings.POSITIONS, s.panelPos, cellX(i), cellY(i), colW);
        i++;
        s.accent = cycle(ctx, "Accent color", Settings.ACCENT_NAMES, s.accent, cellX(i), cellY(i), colW);
        i++;
        s.uiStyle = cycle(ctx, "UI style", Settings.UI_STYLES, s.uiStyle, cellX(i), cellY(i), colW);
        text(ctx, "One panel holds scan, info and players.", cx, cellY(6) + 2, cMuted);
        text(ctx, "Each section has its own tab and on/off switch.", cx, cellY(6) + 14, cMuted);
    }

    private void drawPlayersTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.radar = toggle(ctx, "Show players", s.radar, cellX(i), cellY(i), colW, 0);
        i++;
        s.radarChunks = Math.round(slider(ctx, "rchunks", "Range", s.radarChunks + " chunks", s.radarChunks, 2, 16,
                cellX(i), cellY(i), colW));
        i++;
        s.radarMax = Math.round(slider(ctx, "rmax", "Max players", String.valueOf(s.radarMax), s.radarMax, 3, 10,
                cellX(i), cellY(i), colW));
        text(ctx, "Lists players your game has loaded, with coordinates.", cx, cellY(4) - 4, cMuted);
        text(ctx, "Invisible players are not shown. Move the panel in the Panel tab.", cx, cellY(4) + 8, cMuted);
    }

    private void drawBlocksTab(DrawContext ctx, Settings s) {
        // legend
        int lx = cx + cw;
        String l2 = "in structures";
        String l1 = "never natural";
        lx -= tw(l2);
        text(ctx, l2, lx, cy, cMuted);
        lx -= 10;
        Ui.rrect(ctx, lx, cy + 3, 4, 4, 2, AMBER);
        lx -= tw(l1) + 6;
        text(ctx, l1, lx, cy, cMuted);
        lx -= 10;
        Ui.rrect(ctx, lx, cy + 3, 4, 4, 2, GREEN);

        int rows = Math.max(2, (ch - 24 - 30) / 28);
        int per = rows * 2;
        int total = Targets.ALL.size();
        int pageCount = (total + per - 1) / per;
        pages[tab] = Math.max(0, Math.min(pages[tab], pageCount - 1));

        for (int k = 0; k < per; k++) {
            int idx = pages[tab] * per + k;
            if (idx >= total) break;
            Targets.Entry e = Targets.ALL.get(idx);
            boolean on = Targets.isOn(e);
            boolean nv = toggle(ctx, e.label, on, cellX(k), cellY(k), colW, e.defaultOn ? GREEN : AMBER);
            if (nv != on) {
                s.blocks.put(e.label, nv);
                Targets.rebuild();
            }
        }

        int by = cy + ch - 22;
        pages[tab] = pager(ctx, pages[tab], pageCount, cx, by);

        int bw = 62;
        if (button(ctx, "Defaults", cx + cw - bw, by, bw, 20, true)) {
            s.blocks.clear();
            Targets.rebuild();
            dirty = true;
        }
        if (button(ctx, "All off", cx + cw - bw * 2 - 6, by, bw, 20, false)) {
            for (Targets.Entry e : Targets.ALL) s.blocks.put(e.label, false);
            Targets.rebuild();
            dirty = true;
        }
    }

    private int cellYm(int i) {
        return cy + 46 + (i / 2) * 28;
    }

    private boolean smallBtn(DrawContext c, String label, int x, int y, int w) {
        boolean hv = hov(x, y, w, 16);
        if (mand) Ui.bevel(c, x, y, w, 16, hv ? T.btnH : T.btn, T.btnLt, T.dark, T.border);
        else Ui.rrect(c, x, y, w, 16, 4, hv ? SURF_H : OFF);
        text(c, label, x + 5, y + 4, cText);
        return clk(x, y, w, 16);
    }

    /** One waypoint row: icon, name, coordinates, Edit and delete buttons. 0 = nothing, 1 = edit, 2 = delete. */
    private int markRow(DrawContext c, int x, int y, int w, Data.Mark m, boolean death) {
        card(c, x, y, w, 22, false);
        c.drawItem(Icons.stack(m, death), x + 4, y + 3);
        String edit = "Edit", del = "x";
        int bw1 = tw(edit) + 10, bw2 = tw(del) + 10;
        int bx2 = x + w - bw2 - 3, bx1 = bx2 - bw1 - 3;
        String coords = m.x + " " + m.y + " " + m.z;
        int cwid = tw(coords);
        int nameMax = bx1 - (x + 26) - cwid - 12;
        text(c, fit(m.name, Math.max(20, nameMax)), x + 26, y + 7, death ? 0xFFFF7A7A : cText);
        text(c, coords, bx1 - cwid - 6, y + 7, cMuted);
        int act = 0;
        if (smallBtn(c, edit, bx1, y + 3, bw1)) act = 1;
        if (smallBtn(c, del, bx2, y + 3, bw2)) act = 2;
        return act;
    }

    private void drawMarksTab(DrawContext ctx, Settings s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (editMark != null) {
            drawMarkEditor(ctx);
            return;
        }
        if (nameField != null) nameField.visible = false;

        int half = (cw - 4) / 2;
        if (button(ctx, "My waypoints", cx, cy + 18, half, 20, marksView == 0)) marksView = 0;
        if (button(ctx, "Hologram settings", cx + half + 4, cy + 18, half, 20, marksView == 1)) marksView = 1;

        Data d = Data.get();
        if (marksView == 1) {
            int i = 0;
            s.marksDeath = toggle(ctx, "Death hologram", s.marksDeath, cellX(i), cellYm(i), colW, 0);
            i++;
            s.marksWp = toggle(ctx, "Waypoint holograms", s.marksWp, cellX(i), cellYm(i), colW, 0);
            i++;
            int rng = Math.round(slider(ctx, "mrange", "Show within",
                    s.marksRange >= 5000 ? "any distance" : s.marksRange + " blocks", s.marksRange, 100, 5000,
                    cellX(i), cellYm(i), colW) / 100f) * 100;
            s.marksRange = Math.max(100, Math.min(5000, rng));
            i++;
            s.marksSize = Math.round(slider(ctx, "msize", "Hologram size", String.valueOf(s.marksSize), s.marksSize, 1, 3,
                    cellX(i), cellYm(i), colW));
            i++;
            s.marksAnim = toggle(ctx, "Animation", s.marksAnim, cellX(i), cellYm(i), colW, 0);
            i++;
            s.marksAsk = toggle(ctx, "Name it when I press B", s.marksAsk, cellX(i), cellYm(i), colW, 0);
            text(ctx, "Holograms show through walls, with the icon and name you pick.", cx, cellYm(6) + 2, cMuted);
            return;
        }

        String server = mc.world != null ? Marks.server(mc) : "local";
        List<Data.Mark> refs = new ArrayList<>();
        if (d.death != null && d.death.server.equals(server)) refs.add(d.death);
        for (Data.Mark m : d.marks) if (m.server.equals(server)) refs.add(m);

        int listTop = cy + 46;
        int fit = Math.max(1, (cy + ch - 28 - listTop) / 24);
        int pageCount = Math.max(1, (refs.size() + fit - 1) / fit);
        pages[tab] = Math.max(0, Math.min(pages[tab], pageCount - 1));

        Data.Mark editReq = null, delReq = null;
        for (int k = 0; k < fit; k++) {
            int idx = pages[tab] * fit + k;
            if (idx >= refs.size()) break;
            Data.Mark m = refs.get(idx);
            int act = markRow(ctx, cx, listTop + k * 24, cw, m, m == d.death);
            if (act == 1) editReq = m;
            if (act == 2) delReq = m;
        }
        if (refs.isEmpty()) {
            text(ctx, "No waypoints yet. Press B in game, or use the button below.", cx, listTop + 6, cMuted);
        }

        int by = cy + ch - 22;
        pages[tab] = pager(ctx, pages[tab], pageCount, cx, by);
        if (button(ctx, "+ Add here", cx + cw - 90, by, 90, 20, true)) {
            Data.Mark nm = Marks.addWaypoint(mc);
            if (nm != null) editReq = nm;
        }

        if (delReq != null) {
            if (delReq == d.death) d.death = null;
            else d.marks.remove(delReq);
            Data.save();
        }
        if (editReq != null) startEdit(editReq);
    }

    private void drawMarkEditor(DrawContext ctx) {
        Data.Mark m = editMark;
        Data d = Data.get();
        boolean death = m == d.death;

        text(ctx, "Name", cx, cy + 18, cMuted);
        int fy = cy + 28;
        card(ctx, cx, fy, cw, 22, false);
        nameField.setPosition(cx + 8, fy + 7);
        nameField.setWidth(cw - 16);
        nameField.setEditableColor(cText);
        nameField.visible = true;
        nameField.render(ctx, mx, my, 0f);
        editBuffer = nameField.getText();

        // quick names (handy when there is no keyboard)
        String[] presets = {"Base", "Home", "Farm", "Mine", "Portal", "Stash", "Spawn", "Shop"};
        int py2 = fy + 28;
        int bx = cx;
        for (String p : presets) {
            int bw = tw(p) + 12;
            if (bx + bw > cx + cw) {
                bx = cx;
                py2 += 22;
            }
            if (button(ctx, p, bx, py2, bw, 18, false)) nameField.setText(p);
            bx += bw + 4;
        }

        // icon picker
        int iy = py2 + 26;
        text(ctx, "Icon", cx, iy, cMuted);
        int gy = iy + 11;
        int perRow = Math.max(4, cw / 22);
        String cur = Icons.idOf(m, death);
        for (int k = 0; k < Icons.ALL.size(); k++) {
            int ix = cx + (k % perRow) * 22, iyy = gy + (k / perRow) * 22;
            Icons.Icon ic = Icons.ALL.get(k);
            boolean sel = ic.id.equals(cur);
            boolean hv = hov(ix, iyy, 20, 20);
            if (sel && !mand) Ui.rrect(ctx, ix - 1, iyy - 1, 22, 22, 5, accent);
            card(ctx, ix, iyy, 20, 20, hv);
            if (sel && mand) Ui.studFrame(ctx, ix, iyy, 20, 20, accent);
            ctx.drawItem(ic.stack, ix + 2, iyy + 2);
            if (clk(ix, iyy, 20, 20)) {
                m.icon = ic.id;
                Data.save();
            }
        }

        int by = cy + ch - 22;
        if (button(ctx, "OK", cx, by, 70, 20, true)) {
            endEdit(true);
            return;
        }
        if (button(ctx, "Cancel", cx + 76, by, 70, 20, false)) {
            endEdit(false);
            return;
        }
        if (button(ctx, "Delete", cx + cw - 70, by, 70, 20, false)) {
            if (death) d.death = null;
            else d.marks.remove(m);
            Data.save();
            endEdit(false);
        }
    }

    private void drawChatTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.chatFilter = toggle(ctx, "Chat filter", s.chatFilter, cellX(i), cellY(i), colW, 0);
        i++;
        s.chatAds = toggle(ctx, "Block ad words", s.chatAds, cellX(i), cellY(i), colW, 0);
        i++;
        if (button(ctx, chatMode == 0 ? "Showing: recent" : "Showing: blocked", cellX(i), cellY(i), colW, 24, true)) {
            chatMode = 1 - chatMode;
            pages[tab] = 0;
        }
        i++;
        card(ctx, cellX(i), cellY(i), colW, 24, false);
        text(ctx, "Hidden so far: " + ChatFilter.hidden, cellX(i) + 8, cellY(i) + 8, cText);
        if (button(ctx, "Clear blocked list", cellX(4), cellY(4), colW, 24, false)) {
            s.chatCustom.clear();
            dirty = true;
        }

        List<String> list = chatMode == 0 ? new ArrayList<>(ChatFilter.recent) : new ArrayList<>(s.chatCustom);
        int listTop = cellY(6);
        int fit = listRows(listTop);
        int pageCount = Math.max(1, (list.size() + fit - 1) / fit);
        pages[tab] = Math.max(0, Math.min(pages[tab], pageCount - 1));

        String act = null;
        for (int k = 0; k < fit; k++) {
            int idx = pages[tab] * fit + k;
            if (idx >= list.size()) break;
            String msg = list.get(idx);
            if (listRow(ctx, cx, listTop + k * 22, cw, msg, chatMode == 0 ? "+ block" : "x")) act = msg;
        }
        if (act != null) {
            if (chatMode == 0) {
                String key = ChatFilter.keyFor(act);
                if (!s.chatCustom.contains(key)) s.chatCustom.add(key);
            } else {
                s.chatCustom.remove(act);
            }
            dirty = true;
        }
        if (list.isEmpty()) {
            text(ctx, chatMode == 0 ? "No messages yet. Server messages show up here." : "Nothing blocked yet.",
                    cx, listTop + 6, cMuted);
        }
        pages[tab] = pager(ctx, pages[tab], pageCount, cx, cy + ch - 22);
    }

    private void drawHistoryTab(DrawContext ctx, Settings s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Data d = Data.get();
        String server = mc.world != null ? Marks.server(mc) : "local";
        s.history = toggle(ctx, "Save history", s.history, cellX(0), cellY(0), colW, 0);
        if (button(ctx, "Clear history", cellX(1), cellY(1), colW, 24, false)) {
            d.history.removeIf(h -> h.server.equals(server));
            Data.save();
        }

        List<Data.Hist> refs = new ArrayList<>();
        for (Data.Hist h : d.history) if (h.server.equals(server)) refs.add(h);

        int listTop = cellY(2);
        int fit = listRows(listTop);
        int pageCount = Math.max(1, (refs.size() + fit - 1) / fit);
        pages[tab] = Math.max(0, Math.min(pages[tab], pageCount - 1));

        Data.Hist del = null;
        for (int k = 0; k < fit; k++) {
            int idx = pages[tab] * fit + k;
            if (idx >= refs.size()) break;
            Data.Hist h = refs.get(idx);
            String label = h.x + " " + h.y + " " + h.z + "  " + h.summary;
            if (listRow(ctx, cx, listTop + k * 22, cw, label, "x")) del = h;
        }
        if (del != null) {
            d.history.remove(del);
            Data.save();
        }
        if (refs.isEmpty()) text(ctx, "Nothing saved yet. Scans that find blocks appear here.", cx, listTop + 6, cMuted);
        pages[tab] = pager(ctx, pages[tab], pageCount, cx, cy + ch - 22);
    }

    private void drawInfoTab(DrawContext ctx, Settings s) {
        int i = 0;
        s.info = toggle(ctx, "Show my info", s.info, cellX(i), cellY(i), colW, 0);
        i++;
        s.infoCoords = toggle(ctx, "Coordinates", s.infoCoords, cellX(i), cellY(i), colW, 0);
        i++;
        s.infoFacing = toggle(ctx, "Facing", s.infoFacing, cellX(i), cellY(i), colW, 0);
        i++;
        s.infoBiome = toggle(ctx, "Biome", s.infoBiome, cellX(i), cellY(i), colW, 0);
        i++;
        s.infoLight = toggle(ctx, "Light level", s.infoLight, cellX(i), cellY(i), colW, 0);
        text(ctx, "Light 7 or lower is shown in red (mobs can spawn).", cx, cellY(6) + 2, cMuted);
    }

    private void drawKeysTab(DrawContext ctx) {
        String[][] rows = {
                {"G", "Scan once (target is set in the Scan tab)"},
                {"K", "Clear all borders and the scan result"},
                {"Y", "Open / close this menu"},
                {"B", "Save a waypoint where you stand, then name it"}
        };
        int y = cy + 22;
        for (String[] r : rows) {
            if (mand) Ui.bevel(ctx, cx, y, 22, 18, T.slot, T.slotDk, T.slotLt, T.border);
            else Ui.rrect(ctx, cx, y, 22, 18, 4, Ui.alpha(accent, 0x40));
            text(ctx, r[0], cx + 11 - tw(r[0]) / 2, y + 5, valColor());
            text(ctx, r[1], cx + 32, y + 5, cText);
            y += 24;
        }
        text(ctx, "Rebind keys in Options > Controls > Key Binds.", cx, y + 4, cMuted);
        text(ctx, "Settings: config/chunkinfo.json. Saved marks: chunkinfo-data.json.", cx, y + 16, cMuted);
    }
}
