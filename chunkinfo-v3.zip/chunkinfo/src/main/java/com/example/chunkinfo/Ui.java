package com.example.chunkinfo;

import net.minecraft.client.gui.DrawContext;

public final class Ui {
    private Ui() {}

    public static int alpha(int color, int a) {
        return ((a & 0xFF) << 24) | (color & 0xFFFFFF);
    }

    /** Add (or subtract, if negative) a value to every colour channel. */
    public static int shade(int color, int d) {
        int a = (color >> 24) & 0xFF;
        int r = Math.max(0, Math.min(255, ((color >> 16) & 0xFF) + d));
        int g = Math.max(0, Math.min(255, ((color >> 8) & 0xFF) + d));
        int b = Math.max(0, Math.min(255, (color & 0xFF) + d));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    public static void outlined(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(c, x - 1, y - 1, w + 2, h + 2, r + 1, border);
        rrect(c, x, y, w, h, r, fill);
    }

    public static void hfade(DrawContext c, int x, int y, int w, int h, int color, int aFrom, int aTo) {
        int seg = 3;
        for (int i = 0; i < w; i += seg) {
            float f = (float) i / Math.max(1, w);
            int a = (int) (aFrom + (aTo - aFrom) * f);
            c.fill(x + i, y, Math.min(x + w, x + i + seg), y + h, alpha(color, a));
        }
    }

    /** Vanilla-GUI style box: 1px dark border, light/dark bevel. Swap tl/br for an inset slot. */
    public static void bevel(DrawContext c, int x, int y, int w, int h, int fill, int tl, int br, int border) {
        c.fill(x, y, x + w, y + h, border);
        c.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
        c.fill(x + 1, y + 1, x + w - 1, y + 2, tl);
        c.fill(x + 1, y + 1, x + 2, y + h - 1, tl);
        c.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, br);
        c.fill(x + w - 2, y + 1, x + w - 1, y + h - 1, br);
    }

    /** Copper-style frame with corner studs (like the highlighted furnace output slot). */
    public static void studFrame(DrawContext c, int x, int y, int w, int h, int col) {
        int stud = shade(col, 45);
        c.fill(x, y, x + w, y + 2, col);
        c.fill(x, y + h - 2, x + w, y + h, col);
        c.fill(x, y, x + 2, y + h, col);
        c.fill(x + w - 2, y, x + w, y + h, col);
        c.fill(x - 1, y - 1, x + 3, y + 3, stud);
        c.fill(x + w - 3, y - 1, x + w + 1, y + 3, stud);
        c.fill(x - 1, y + h - 3, x + 3, y + h + 1, stud);
        c.fill(x + w - 3, y + h - 3, x + w + 1, y + h + 1, stud);
    }
}
