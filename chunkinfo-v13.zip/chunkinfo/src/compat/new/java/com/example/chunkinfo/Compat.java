package com.example.chunkinfo;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.Identifier;

/** Parts of the game API that differ between Minecraft versions. This is the 1.21.9 - 1.21.11 flavour. */
public final class Compat {
    private Compat() {}

    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("chunkinfo", "main"));

    public static KeyBinding key(String name, int code) {
        return new KeyBinding(name, InputUtil.Type.KEYSYM, code, CATEGORY);
    }

    public static void particle(ClientWorld w, ParticleEffect e, double x, double y, double z) {
        w.addImportantParticleClient(e, x, y, z, 0, 0, 0);
    }

    public static ParticleEffect dust(int rgb, float scale) {
        return new DustParticleEffect(rgb, scale);
    }
}
