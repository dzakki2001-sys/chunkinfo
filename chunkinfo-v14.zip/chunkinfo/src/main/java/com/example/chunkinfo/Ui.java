package com.example.chunkinfo;

import net.minecraft.client.gui.DrawContext;

public final class Ui {
    private Ui() {}

    public static int alpha(int color, int a) {
        return ((a & 0xFF) << 24) | (color & 0xFFFFFF);
    }

    /** Add (or subtract, if negative) a value to every colour channel. */
    public static int shade(int color, int d) {
        int a = (color >> 24) & 0xFF;
        int r = Math.max(0, Math.min(255, ((color >> 16) & 0xFF) + d));
        int g = Math.max(0, Math.min(255, ((color >> 8) & 0xFF) + d));
        int b = Math.max(0, Math.min(255, (color & 0xFF) + d));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    public static void outlined(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(c, x - 1, y - 1, w + 2, h + 2, r + 1, border);
        rrect(c, x, y, w, h, r, fill);
    }

    public static void hfade(DrawContext c, int x, int y, int w, int h, int color, int aFrom, int aTo) {
        int seg = 3;
        for (int i = 0; i < w; i += seg) {
            float f = (float) i / Math.max(1, w);
            int a = (int) (aFrom + (aTo - aFrom) * f);
            c.fill(x + i, y, Math.min(x + w, x + i + seg), y + h, alpha(color, a));
        }
    }

    public static int opaque(int color) {
        return 0xFF000000 | (color & 0xFFFFFF);
    }

    /** Vanilla-GUI style box: 1px border, light/dark bevel. Swap tl/br for an inset slot. */
    public static void bevel(DrawContext c, int x, int y, int w, int h, int fill, int tl, int br, int border) {
        c.fill(x, y, x + w, y + 1, border);
        c.fill(x, y + h - 1, x + w, y + h, border);
        c.fill(x, y + 1, x + 1, y + h - 1, border);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, border);
        c.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
        c.fill(x + 1, y + 1, x + w - 1, y + 2, tl);
        c.fill(x + 1, y + 2, x + 2, y + h - 2, tl);
        c.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, br);
        c.fill(x + w - 2, y + 2, x + w - 1, y + h - 2, br);
    }

    private static void box(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2), color);
    }

    /** Pixel corner flourish. dx / dy = +1 or -1 = which way the corner points into the panel. */
    public static void corner(DrawContext c, int x, int y, int dx, int dy, int col, int len) {
        int a = alpha(col, 0xD0);
        int b = alpha(col, 0x70);
        box(c, x, y, x + dx * len, y + dy, a);
        box(c, x, y, x + dx, y + dy * len, a);
        box(c, x + dx * 2, y + dy * 2, x + dx * (len - 1), y + dy * 3, b);
        box(c, x + dx * 2, y + dy * 2, x + dx * 3, y + dy * (len - 1), b);
        box(c, x + dx * 3, y + dy * 3, x + dx * 4, y + dy * 4, alpha(col, 0xFF));
    }

    /** Tiny 5px diamond. */
    public static void diamondDot(DrawContext c, int x, int y, int col) {
        c.fill(x - 2, y, x + 3, y + 1, alpha(col, 0xE0));
        c.fill(x - 1, y - 1, x + 2, y, alpha(col, 0xB0));
        c.fill(x - 1, y + 1, x + 2, y + 2, alpha(col, 0xB0));
        c.fill(x, y - 2, x + 1, y - 1, alpha(col, 0x80));
        c.fill(x, y + 2, x + 1, y + 3, alpha(col, 0x80));
    }

    /** Minimal logo: rounded square with a glowing diamond. Size = 3*cell + 6 (same as before). */
    public static void logo(DrawContext c, int x, int y, int cell, int accent) {
        int s = 3 * cell + 6;
        outlined(c, x, y, s, s, Math.max(2, s / 6), 0xFF0D1017, alpha(accent, 0xB0));
        int cx = x + s / 2, cy = y + s / 2;
        int R = Math.max(2, s / 2 - 4);

        // soft glow + diamond outline
        for (int dy = -R; dy <= R; dy++) {
            int half = R - Math.abs(dy);
            if (half > 1) c.fill(cx - half + 1, cy + dy, cx + half, cy + dy + 1, alpha(accent, 0x2A));
            c.fill(cx - half, cy + dy, cx - half + 1, cy + dy + 1, alpha(accent, 0xE0));
            c.fill(cx + half, cy + dy, cx + half + 1, cy + dy + 1, alpha(accent, 0xE0));
        }
        // solid centre diamond
        int r2 = Math.max(1, R / 2);
        for (int dy = -r2; dy <= r2; dy++) {
            int half = r2 - Math.abs(dy);
            c.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, shade(accent, 25));
        }
        // tiny sparkle in the corner
        if (s >= 18) {
            int sx = x + s - 6, sy = y + 5;
            int w = alpha(0xFFFFFFFF, 0xE0);
            c.fill(sx, sy, sx + 1, sy + 1, w);
            c.fill(sx - 1, sy, sx, sy + 1, alpha(0xFFFFFFFF, 0x80));
            c.fill(sx + 1, sy, sx + 2, sy + 1, alpha(0xFFFFFFFF, 0x80));
            c.fill(sx, sy - 1, sx + 1, sy, alpha(0xFFFFFFFF, 0x80));
            c.fill(sx, sy + 1, sx + 1, sy + 2, alpha(0xFFFFFFFF, 0x80));
        }
    }

    /** Copper-style frame with corner studs (like the highlighted furnace output slot). */
    public static void studFrame(DrawContext c, int x, int y, int w, int h, int col) {
        int stud = shade(col, 45);
        c.fill(x, y, x + w, y + 2, col);
        c.fill(x, y + h - 2, x + w, y + h, col);
        c.fill(x, y, x + 2, y + h, col);
        c.fill(x + w - 2, y, x + w, y + h, col);
        c.fill(x - 1, y - 1, x + 3, y + 3, stud);
        c.fill(x + w - 3, y - 1, x + w + 1, y + 3, stud);
        c.fill(x - 1, y + h - 3, x + 3, y + h + 1, stud);
        c.fill(x + w - 3, y + h - 3, x + w + 1, y + h + 1, stud);
    }
}
