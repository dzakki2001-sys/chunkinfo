package com.example.chunkinfo;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** One HUD panel with sections: info, chunk scan, marks, items and nearby players. */
public class HudPanel {
    private static final int W = 204;

    private static int TEXT, MUTED, GREEN, RED, ACC, ACC_T;

    private static class Row {
        final boolean header;
        final String left, right;
        final int lc, rc;

        Row(boolean header, String left, String right, int lc, int rc) {
            this.header = header;
            this.left = left;
            this.right = right;
            this.lc = lc;
            this.rc = rc;
        }

        int height() {
            return header ? 18 : 13;
        }
    }

    private static class Hit {
        String name;
        int x, y, z;
        float dist;
    }

    public static void render(DrawContext c, MinecraftClient mc) {
        Settings s = Settings.get();
        if (!(s.panel || s.radar || s.info)) return;
        if (mc.world == null || mc.player == null || mc.options.hudHidden) return;

        Theme T = Theme.of(s.uiStyle);
        boolean mand = s.uiStyle != 1;
        TEXT = mand ? T.text : 0xFFEDEDF5;
        MUTED = mand ? T.muted : 0xFF8B8BA3;
        GREEN = 0xFF4ADE80;
        RED = 0xFFF0605A;
        ACC = s.accentColor();
        ACC_T = mand ? Ui.shade(ACC, 40) : ACC;
        TextRenderer tr = mc.textRenderer;

        List<Row> rows = new ArrayList<>();
        if (s.info) addInfo(rows, mc, s);
        if (s.panel) addScan(rows, s);
        if (s.radar) addPlayers(rows, mc, s);

        int h = 32 + 8;
        for (Row r : rows) h += r.height();

        int sw = mc.getWindow().getScaledWidth();
        int x = s.panelPos == 0 ? sw - W - 8 : 8;
        int y = 8;

        String name = "Daz Client";
        if (mand) {
            Ui.bevel(c, x, y, W, h, Ui.alpha(T.panel, 0xE8), T.light, T.dark, T.border);
            Fx.draw(c, T.fx, x + 2, y + 2, W - 4, h - 4, System.currentTimeMillis() / 1000.0, ACC);
            c.drawTextWithShadow(tr, name, x + (W - tr.getWidth(name)) / 2, y + 9, T.title);
            c.fill(x + 8, y + 22, x + W - 8, y + 23, T.dark);
            c.fill(x + 8, y + 23, x + W - 8, y + 24, T.light);
            Ui.logo(c, x + 8, y + 5, 2, ACC);
            Ui.corner(c, x + W - 3, y + 3, -1, 1, ACC, 5);
            Ui.corner(c, x + 3, y + h - 4, 1, -1, ACC, 5);
            Ui.corner(c, x + W - 3, y + h - 4, -1, -1, ACC, 5);
        } else {
            Ui.outlined(c, x, y, W, h, 5, 0xE60C0C13, 0xFF2B2B3F);
            Ui.hfade(c, x + 6, y + 1, W - 12, 1, ACC, 220, 0);
            Ui.logo(c, x + 8, y + 5, 2, ACC);
            c.drawTextWithShadow(tr, name, x + 26, y + 9, 0xFFEDEDF5);
        }

        int ry = y + 30;
        for (Row row : rows) {
            if (row.header) {
                c.drawTextWithShadow(tr, row.left, x + 10, ry + 3, ACC_T);
                if (mand) {
                    c.fill(x + 10, ry + 14, x + W - 10, ry + 15, T.dark);
                    c.fill(x + 10, ry + 15, x + W - 10, ry + 16, T.light);
                } else {
                    Ui.hfade(c, x + 10, ry + 14, W - 20, 1, ACC, 160, 0);
                }
            } else {
                int rw = row.right.isEmpty() ? 0 : tr.getWidth(row.right) + 6;
                c.drawTextWithShadow(tr, fit(tr, row.left, W - 20 - rw), x + 10, ry + 1, row.lc);
                if (!row.right.isEmpty()) {
                    c.drawTextWithShadow(tr, row.right, x + W - 10 - tr.getWidth(row.right), ry + 1, row.rc);
                }
            }
            ry += row.height();
        }
    }

    private static void addInfo(List<Row> rows, MinecraftClient mc, Settings s) {
        rows.add(new Row(true, "INFO", "", 0, 0));
        PlayerEntity p = mc.player;
        if (s.infoCoords) {
            rows.add(new Row(false, "XYZ", p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ(), MUTED, TEXT));
        }
        if (s.infoFacing) {
            rows.add(new Row(false, "Facing", p.getHorizontalFacing().asString(), MUTED, TEXT));
        }
        if (s.infoBiome) {
            String biome = mc.world.getBiome(p.getBlockPos()).getKey().map(k -> k.getValue().getPath()).orElse("?");
            rows.add(new Row(false, "Biome", biome.replace('_', ' '), MUTED, TEXT));
        }
        if (s.infoLight) {
            int light = mc.world.getLightLevel(p.getBlockPos());
            rows.add(new Row(false, "Light", String.valueOf(light), MUTED, light <= 7 ? RED : GREEN));
        }
    }

    private static void addScan(List<Row> rows, Settings s) {
        ScanResult r = ChunkInfoClient.last;
        rows.add(new Row(true, "CHUNK SCAN", "", 0, 0));
        if (r == null) {
            String msg = ChunkInfoClient.status != null ? ChunkInfoClient.status : "Press G to scan a chunk";
            rows.add(new Row(false, msg, "", MUTED, 0));
            return;
        }
        rows.add(new Row(false, "Chunk " + r.pos.x + ", " + r.pos.z, "", MUTED, 0));
        if (r.total == 0) {
            rows.add(new Row(false, "Clean - nothing found", "", GREEN, 0));
            return;
        }
        rows.add(new Row(false, r.total + (r.total == 1 ? " crafted block" : " crafted blocks"), "", ACC_T, 0));
        List<Map.Entry<Block, Integer>> list = new ArrayList<>(r.counts.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        int shown = 0;
        for (Map.Entry<Block, Integer> e : list) {
            if (shown++ >= 6) break;
            rows.add(new Row(false, e.getKey().getName().getString(), "x" + e.getValue(), TEXT, ACC_T));
        }
        if (list.size() > 6) rows.add(new Row(false, "+" + (list.size() - 6) + " more types", "", MUTED, 0));
        if (s.showCoords && !r.samples.isEmpty()) {
            rows.add(new Row(false, "Found at", "", MUTED, 0));
            for (BlockPos p : r.samples) {
                rows.add(new Row(false, p.getX() + " " + p.getY() + " " + p.getZ(), "", TEXT, 0));
            }
        }
    }

    private static void addPlayers(List<Row> rows, MinecraftClient mc, Settings s) {
        double range = s.radarChunks * 16.0;
        List<Hit> hits = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isInvisible()) continue;
            float d = mc.player.distanceTo(p);
            if (d > range) continue;
            Hit h = new Hit();
            h.name = p.getName().getString();
            h.x = p.getBlockX();
            h.y = p.getBlockY();
            h.z = p.getBlockZ();
            h.dist = d;
            hits.add(h);
        }
        hits.sort((a, b) -> Float.compare(a.dist, b.dist));

        rows.add(new Row(true, "PLAYERS (" + hits.size() + ")", "", 0, 0));
        if (hits.isEmpty()) {
            rows.add(new Row(false, "None within " + s.radarChunks + " chunks", "", MUTED, 0));
            return;
        }
        int shown = Math.min(hits.size(), Math.max(1, s.radarMax));
        for (int i = 0; i < shown; i++) {
            Hit hit = hits.get(i);
            rows.add(new Row(false, hit.name, Math.round(hit.dist) + "m", TEXT, ACC_T));
            rows.add(new Row(false, hit.x + "  " + hit.y + "  " + hit.z, "", MUTED, 0));
        }
        if (hits.size() > shown) rows.add(new Row(false, "+" + (hits.size() - shown) + " more", "", MUTED, 0));
    }

    private static String fit(TextRenderer tr, String s, int max) {
        if (tr.getWidth(s) <= max) return s;
        while (s.length() > 1 && tr.getWidth(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
