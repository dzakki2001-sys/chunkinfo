package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.ParticlesMode;

/** Performance presets, vanilla option helpers and zoom. Everything here is a normal client setting. */
public final class Perf {
    private Perf() {}

    private static boolean zooming = false;
    private static Integer savedFov = null;
    private static Double savedSens = null;

    public static int getInt(MinecraftClient mc, String k) {
        GameOptions o = mc.options;
        switch (k) {
            case "view": return o.getViewDistance().getValue();
            case "sim": return o.getSimulationDistance().getValue();
            case "fps": return o.getMaxFps().getValue();
            case "entity": return (int) Math.round(o.getEntityDistanceScaling().getValue() * 100);
            case "fovfx": return (int) Math.round(o.getFovEffectScale().getValue() * 100);
            case "blend": return o.getBiomeBlendRadius().getValue();
            case "clouds": {
                CloudRenderMode m = o.getCloudRenderMode().getValue();
                return m == CloudRenderMode.OFF ? 0 : (m == CloudRenderMode.FAST ? 1 : 2);
            }
            case "particles": {
                ParticlesMode m = o.getParticles().getValue();
                return m == ParticlesMode.ALL ? 0 : (m == ParticlesMode.DECREASED ? 1 : 2);
            }
            default: return 0;
        }
    }

    public static void setInt(MinecraftClient mc, String k, int v) {
        GameOptions o = mc.options;
        try {
            switch (k) {
                case "view": o.getViewDistance().setValue(v); break;
                case "sim": o.getSimulationDistance().setValue(v); break;
                case "fps": o.getMaxFps().setValue(v); break;
                case "entity": o.getEntityDistanceScaling().setValue(v / 100.0); break;
                case "fovfx": o.getFovEffectScale().setValue(v / 100.0); break;
                case "blend": o.getBiomeBlendRadius().setValue(v); break;
                case "clouds":
                    o.getCloudRenderMode().setValue(v == 0 ? CloudRenderMode.OFF
                            : (v == 1 ? CloudRenderMode.FAST : CloudRenderMode.FANCY));
                    break;
                case "particles":
                    o.getParticles().setValue(v == 0 ? ParticlesMode.ALL
                            : (v == 1 ? ParticlesMode.DECREASED : ParticlesMode.MINIMAL));
                    break;
                default:
            }
        } catch (Throwable ignored) {
        }
    }

    public static boolean getBool(MinecraftClient mc, String k) {
        GameOptions o = mc.options;
        switch (k) {
            case "bob": return o.getBobView().getValue();
            case "shadows": return o.getEntityShadows().getValue();
            case "sprint": return o.getSprintToggled().getValue();
            case "sneak": return o.getSneakToggled().getValue();
            default: return false;
        }
    }

    public static void setBool(MinecraftClient mc, String k, boolean v) {
        GameOptions o = mc.options;
        try {
            switch (k) {
                case "bob": o.getBobView().setValue(v); break;
                case "shadows": o.getEntityShadows().setValue(v); break;
                case "sprint": o.getSprintToggled().setValue(v); break;
                case "sneak": o.getSneakToggled().setValue(v); break;
                default:
            }
        } catch (Throwable ignored) {
        }
    }

    /** 0 = Fast (PvP), 1 = Balanced, 2 = Quality. */
    public static void preset(MinecraftClient mc, int p) {
        if (p == 0) {
            setInt(mc, "view", 8);
            setInt(mc, "sim", 5);
            setInt(mc, "fps", 260);
            setInt(mc, "entity", 75);
            setInt(mc, "blend", 1);
            setInt(mc, "clouds", 0);
            setInt(mc, "particles", 1);
            setBool(mc, "shadows", false);
        } else if (p == 1) {
            setInt(mc, "view", 12);
            setInt(mc, "sim", 8);
            setInt(mc, "fps", 144);
            setInt(mc, "entity", 100);
            setInt(mc, "blend", 3);
            setInt(mc, "clouds", 1);
            setInt(mc, "particles", 1);
            setBool(mc, "shadows", true);
        } else {
            setInt(mc, "view", 16);
            setInt(mc, "sim", 12);
            setInt(mc, "fps", 120);
            setInt(mc, "entity", 150);
            setInt(mc, "blend", 5);
            setInt(mc, "clouds", 2);
            setInt(mc, "particles", 0);
            setBool(mc, "shadows", true);
        }
        save();
    }

    public static void save() {
        try {
            MinecraftClient.getInstance().options.write();
        } catch (Throwable ignored) {
        }
    }

    private static int boostTicks = 0;
    private static boolean boostWasOn = false;
    private static Integer savedMaxFps = null;

    /**
     * FPS Boost: every two seconds it compares your FPS with the target. If FPS is too low it lowers the
     * render distance by one chunk (down to your chosen minimum); if FPS is comfortably high it raises it
     * again (up to the value you had when you turned Boost on). Also caps FPS while the window is unfocused.
     */
    public static void boostTick(MinecraftClient mc) {
        Settings s = Settings.get();
        try {
            boolean unfocused = s.unfocusedLimit && !mc.isWindowFocused();
            if (unfocused && savedMaxFps == null) {
                savedMaxFps = mc.options.getMaxFps().getValue();
                mc.options.getMaxFps().setValue(Math.min(30, savedMaxFps));
            } else if (!unfocused && savedMaxFps != null) {
                mc.options.getMaxFps().setValue(savedMaxFps);
                savedMaxFps = null;
            }
        } catch (Throwable ignored) {
        }
        if (mc.world == null || mc.player == null) return;

        if (s.fpsBoost) {
            int cur = getInt(mc, "view");
            if (!boostWasOn) {
                boostWasOn = true;
                s.boostBase = cur;
                Settings.save();
            }
            if (++boostTicks >= 40) {
                boostTicks = 0;
                if (mc.currentScreen == null && mc.isWindowFocused()) {
                    int fps = mc.getCurrentFps();
                    int minV = Math.max(2, s.boostMinView);
                    int maxV = Math.max(minV, s.boostBase);
                    if (fps < s.fpsTarget * 0.9 && cur > minV) setInt(mc, "view", cur - 1);
                    else if (fps > s.fpsTarget * 1.35 && cur < maxV) setInt(mc, "view", cur + 1);
                }
            }
        } else if (boostWasOn) {
            boostWasOn = false;
            if (s.boostBase > 0) setInt(mc, "view", s.boostBase);
        }
    }

    /** Hold the zoom key: lowers FOV and mouse speed, then restores both. */
    public static void tick(MinecraftClient mc, KeyBinding zoomKey) {
        Settings s = Settings.get();
        boolean want = s.zoom && mc.player != null && mc.currentScreen == null && zoomKey.isPressed();
        try {
            if (want && !zooming) {
                zooming = true;
                savedFov = mc.options.getFov().getValue();
                savedSens = mc.options.getMouseSensitivity().getValue();
                mc.options.getFov().setValue(Math.max(30, Math.min(110, s.zoomFov)));
                mc.options.getMouseSensitivity().setValue(savedSens * 0.4);
            } else if (!want && zooming) {
                zooming = false;
                if (savedFov != null) mc.options.getFov().setValue(savedFov);
                if (savedSens != null) mc.options.getMouseSensitivity().setValue(savedSens);
                savedFov = null;
                savedSens = null;
            }
        } catch (Throwable ignored) {
        }
    }
}
