package com.example.chunkinfo;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.DownloadingTerrainScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.client.gui.screen.ProgressScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;

/** Branded loading screens (game start, joining a world or server) that follow your UI style. */
public final class LoadingScreen {
    private LoadingScreen() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            addMenuButton(client, screen);
            if (screen instanceof ConnectScreen || screen instanceof DownloadingTerrainScreen
                    || screen instanceof ProgressScreen) {
                String status = screen instanceof ConnectScreen ? "Connecting..."
                        : (screen instanceof DownloadingTerrainScreen ? "Loading terrain..." : "Loading...");
                ScreenEvents.afterRender(screen).register((scr, ctx, mx, my, delta) -> {
                    if (Settings.get().loadingScreen) draw(ctx, status);
                });
            } else if (screen instanceof TitleScreen) {
                ScreenEvents.afterRender(screen).register((scr, ctx, mx, my, delta) ->
                        ClientHud.drawWatermark(ctx, MinecraftClient.getInstance(), true));
            }
        });
    }

    /** A small "Daz Client" button on the title, pause and options screens, so the menu is one tap away. */
    private static void addMenuButton(MinecraftClient client, Screen screen) {
        if (!Settings.get().menuButton) return;
        if (!(screen instanceof TitleScreen || screen instanceof GameMenuScreen || screen instanceof OptionsScreen)) return;
        ButtonWidget b = ButtonWidget.builder(Text.literal("Daz Client"), btn -> client.setScreen(new SettingsScreen()))
                .dimensions(6, 26, 80, 20).build();
        Screens.getButtons(screen).add(b);
    }

    /** Called from the splash overlay mixin while the game starts. No text, so it is safe before fonts load. */
    public static void drawSplash(DrawContext c) {
        if (!Settings.get().splashScreen) return;
        draw(c, null);
    }

    private static void draw(DrawContext c, String status) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Settings s = Settings.get();
        Theme T = Theme.of(s.uiStyle);
        boolean neon = s.uiStyle == 1;
        int acc = s.accentColor();
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double t = System.currentTimeMillis() / 1000.0;

        c.fill(0, 0, w, h, neon ? 0xFF0B0B12 : Ui.shade(T.dark, 4));
        Fx.draw(c, neon ? 1 : (T.fx != 0 ? T.fx : 1), 0, 0, w, h, t, acc);
        c.fillGradient(0, 0, w, h / 3, 0x66000000, 0x00000000);
        c.fillGradient(0, h * 2 / 3, w, h, 0x00000000, 0x66000000);

        int cx = w / 2, cy = h / 2;
        int cell = Math.max(5, Math.min(12, h / 28));
        int ls = 3 * cell + 6;
        Ui.logo(c, cx - ls / 2, cy - ls - 12, cell, acc);

        int sc = Math.max(2, Math.min(4, h / 90));
        PixelFont.drawCentered(c, "DAZ CLIENT", cx, cy - 4, sc, acc);

        int bw = Math.min(180, w - 40), bh = 5;
        int bx = cx - bw / 2, by = cy + 5 * sc + 6;
        c.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xCC000000);
        c.fill(bx, by, bx + bw, by + bh, 0xFF10131A);
        int seg = bw / 3;
        int sx = bx + (int) ((bw - seg) * (0.5 + 0.5 * Math.sin(t * 2.4)));
        c.fill(sx, by, sx + seg, by + bh, acc);
        c.fill(sx, by, sx + seg, by + 1, Ui.shade(acc, 70));
        Ui.diamondDot(c, bx - 8, by + 2, acc);
        Ui.diamondDot(c, bx + bw + 8, by + 2, acc);

        if (status != null) {
            TextRenderer tr = mc.textRenderer;
            c.drawTextWithShadow(tr, status, cx - tr.getWidth(status) / 2, by + 12, 0xFFB0B8C8);
        }
    }
}
