package com.example.chunkinfo;

import net.minecraft.client.gui.DrawContext;

/** Animated pixel backgrounds, drawn inside a rectangle. t = time in seconds. */
public final class Fx {
    private Fx() {}

    private static int hash(int i, int salt) {
        long v = i * 374761393L + salt * 668265263L;
        v = (v ^ (v >>> 13)) * 1274126177L;
        return (int) ((v ^ (v >>> 16)) & 0x7fffffff);
    }

    private static float rnd(int i, int salt) {
        return (hash(i, salt) % 10000) / 10000f;
    }

    private static void px(DrawContext c, int x0, int y0, int w, int h, int x, int y, int sz, int color) {
        if (x < x0 || y < y0 || x + sz > x0 + w || y + sz > y0 + h) return;
        c.fill(x, y, x + sz, y + sz, color);
    }

    public static void draw(DrawContext c, int fx, int x, int y, int w, int h, double t, int accent) {
        if (w < 8 || h < 8) return;
        switch (fx) {
            case 1:
                stars(c, x, y, w, h, t);
                break;
            case 2:
                matrix(c, x, y, w, h, t);
                break;
            case 3:
                embers(c, x, y, w, h, t);
                break;
            case 4:
                synth(c, x, y, w, h, t);
                break;
            case 5:
                sakura(c, x, y, w, h, t);
                break;
            default:
        }
    }

    // twinkling stars, soft nebula bands, an occasional shooting star
    private static void stars(DrawContext c, int x, int y, int w, int h, double t) {
        int b1 = y + h / 5 + (int) (5 * Math.sin(t * 0.35));
        c.fillGradient(x, b1, x + w, b1 + h / 4, 0x00000000, 0x2A6B4BC8);
        c.fillGradient(x, b1 + h / 4, x + w, b1 + h / 2, 0x2A3B6BD8, 0x00000000);

        int n = Math.max(14, w * h / 420);
        for (int i = 0; i < n; i++) {
            int sx = x + (int) (rnd(i, 1) * (w - 2));
            int sy = y + (int) (rnd(i, 2) * (h - 2));
            double tw = 0.5 + 0.5 * Math.sin(t * (1.0 + rnd(i, 3) * 2.5) + rnd(i, 4) * 6.28);
            int a = (int) (40 + 190 * tw);
            int col = rnd(i, 5) > 0.7 ? 0xFFB8C8FF : 0xFFFFFFFF;
            c.fill(sx, sy, sx + 1, sy + 1, Ui.alpha(col, a));
            if (rnd(i, 6) > 0.85 && tw > 0.8) {
                int ac = a / 2;
                px(c, x, y, w, h, sx - 1, sy, 1, Ui.alpha(col, ac));
                px(c, x, y, w, h, sx + 1, sy, 1, Ui.alpha(col, ac));
                px(c, x, y, w, h, sx, sy - 1, 1, Ui.alpha(col, ac));
                px(c, x, y, w, h, sx, sy + 1, 1, Ui.alpha(col, ac));
            }
        }

        double ph = (t % 7.0) / 7.0;
        if (ph < 0.14) {
            double p = ph / 0.14;
            int hx = x + (int) (w * (0.15 + 0.7 * p));
            int hy = y + (int) (h * (0.05 + 0.4 * p));
            for (int k = 0; k < 9; k++) {
                px(c, x, y, w, h, hx - k, hy - k / 2, 1, Ui.alpha(0xFFFFFFFF, 230 - k * 25));
            }
        }
    }

    // falling green code columns
    private static void matrix(DrawContext c, int x, int y, int w, int h, double t) {
        int cols = w / 6;
        for (int col = 0; col < cols; col++) {
            double speed = 14 + rnd(col, 1) * 30;
            int len = 6 + (int) (rnd(col, 3) * 10);
            double head = ((t * speed + rnd(col, 2) * (h + 40)) % (h + len * 2)) - len;
            int cx = x + col * 6 + 2;
            for (int k = 0; k < len; k++) {
                int yy = y + (int) (head - k * 2);
                if (yy < y || yy >= y + h) continue;
                int a = (int) (200 * (1.0 - k / (double) len));
                int color = k == 0 ? 0xFFC8FFD9 : 0xFF2ECC71;
                c.fill(cx, yy, cx + 1, yy + 1, Ui.alpha(color, k == 0 ? 230 : a));
            }
        }
    }

    // rising embers with a warm glow at the bottom
    private static void embers(DrawContext c, int x, int y, int w, int h, double t) {
        c.fillGradient(x, y + h * 7 / 10, x + w, y + h, 0x00FF5A1A, 0x44FF5A1A);
        int n = Math.max(14, w * h / 650);
        for (int i = 0; i < n; i++) {
            double sp = 6 + rnd(i, 1) * 14;
            double yy = h - ((t * sp + rnd(i, 2) * h) % h);
            double sway = Math.sin(t * 1.3 + rnd(i, 3) * 6.28) * 4;
            int ex = x + (int) (rnd(i, 4) * (w - 3) + sway);
            int ey = y + (int) yy;
            double frac = yy / h; // 1 = bottom
            int a = (int) (50 + 170 * frac * (0.7 + 0.3 * Math.sin(t * 9 + i)));
            int col = frac > 0.5 ? 0xFFFF8A2A : 0xFFD0361A;
            int sz = rnd(i, 5) > 0.8 ? 2 : 1;
            px(c, x, y, w, h, ex, ey, sz, Ui.alpha(col, a));
        }
    }

    // sunset sun with stripes, moving neon grid
    private static void synth(DrawContext c, int x, int y, int w, int h, double t) {
        int hz = y + h * 58 / 100;
        int cx = x + w / 2;
        int r = Math.max(8, Math.min(w, h) / 4);
        for (int dy = 0; dy < r; dy++) {
            if (dy < r * 0.55 && (dy % 5) == 3) continue;
            int hw = (int) Math.sqrt((double) r * r - (double) dy * dy);
            float f = dy / (float) r;
            int col = f > 0.5f ? 0xFFFF4FA8 : 0xFFFFD25A;
            c.fill(cx - hw, hz - dy - 1, cx + hw, hz - dy, Ui.alpha(col, 90));
        }
        double frac = (t * 0.5) % 1.0;
        int span = y + h - hz;
        for (int i = 0; i < 9; i++) {
            double p = (i + frac) / 9.0;
            int yy = hz + (int) (p * p * span);
            if (yy >= y + h) continue;
            c.fill(x, yy, x + w, yy + 1, Ui.alpha(0xFFFF4FD8, 70));
        }
        for (int k = -6; k <= 6; k++) {
            for (int row = hz; row < y + h; row += 2) {
                double rr = (row - hz) / (double) Math.max(1, span);
                int xx = cx + (int) (k * (4 + rr * (w / 7.0)));
                if (xx < x || xx >= x + w) continue;
                c.fill(xx, row, xx + 1, row + 1, Ui.alpha(0xFF7A5CFF, 55));
            }
        }
        c.fill(x, hz, x + w, hz + 1, Ui.alpha(0xFFFF8AE0, 120));
    }

    // drifting cherry-blossom petals
    private static void sakura(DrawContext c, int x, int y, int w, int h, double t) {
        int n = Math.max(10, w * h / 800);
        for (int i = 0; i < n; i++) {
            double sp = 8 + rnd(i, 1) * 12;
            double yy = ((t * sp + rnd(i, 2) * (h + 12)) % (h + 12)) - 6;
            double sway = Math.sin(t * 0.9 + rnd(i, 3) * 6.28) * 6;
            int ex = x + (int) (rnd(i, 4) * (w - 4) + sway);
            int ey = y + (int) yy;
            px(c, x, y, w, h, ex, ey, 2, Ui.alpha(0xFFFFB7D5, 190));
            px(c, x, y, w, h, ex, ey, 1, Ui.alpha(0xFFFFE3EF, 230));
            if (((int) (t * 2 + i) & 1) == 0) px(c, x, y, w, h, ex + 2, ey + 1, 1, Ui.alpha(0xFFFFB7D5, 120));
        }
    }
}
