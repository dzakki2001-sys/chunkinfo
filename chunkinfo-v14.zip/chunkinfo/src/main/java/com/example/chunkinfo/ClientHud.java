package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Watermark, FPS/CPS/ping/coords widgets, keystrokes and the custom crosshair. */
public final class ClientHud {
    private ClientHud() {}

    private static final List<Long> LEFT = new ArrayList<>(), RIGHT = new ArrayList<>();
    private static boolean lPrev, rPrev;

    public static void render(DrawContext c, MinecraftClient mc) {
        if (mc.world == null || mc.player == null || mc.options.hudHidden) return;
        Settings s = Settings.get();
        pollClicks(mc);
        if (s.watermark) drawWatermark(c, mc, false);
        widgets(c, mc, s);
        if (mc.currentScreen == null) crosshair(c, mc, s);
    }

    private static void pollClicks(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        long h = mc.getWindow().getHandle();
        boolean l = mc.currentScreen == null && GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = mc.currentScreen == null && GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !lPrev) LEFT.add(now);
        if (r && !rPrev) RIGHT.add(now);
        lPrev = l;
        rPrev = r;
        LEFT.removeIf(t -> now - t > 1000);
        RIGHT.removeIf(t -> now - t > 1000);
    }

    // ---------- watermark ----------

    /** Small logo + name in a corner. Kept faint so it never gets in the way. */
    public static void drawWatermark(DrawContext c, MinecraftClient mc, boolean title) {
        Settings s = Settings.get();
        if (!s.watermark) return;
        TextRenderer tr = mc.textRenderer;
        String name = "Daz Client";
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int logo = 3 * 1 + 6;
        int w = logo + 5 + tr.getWidth(name);
        int pos = Math.floorMod(s.watermarkPos, 4);
        int x = (pos == 1 || pos == 3) ? sw - w - 4 : 4;
        int y = (pos >= 2) ? sh - logo - 4 : 4;
        int a = Math.max(20, Math.min(100, s.watermarkAlpha)) * 255 / 100;
        Ui.logo(c, x, y, 1, s.accentColor());
        c.drawTextWithShadow(tr, name, x + logo + 5, y + 1, Ui.alpha(0xFFFFFFFF, a));
    }

    // ---------- widgets ----------

    private static void box(DrawContext c, int x, int y, int w, int h, Theme T, boolean neon) {
        if (neon) Ui.outlined(c, x, y, w, h, 3, 0xCC0C0C13, 0xFF2B2B3F);
        else Ui.bevel(c, x, y, w, h, Ui.alpha(T.panel, 0xC8), T.light, T.dark, T.border);
    }

    private static void widgets(DrawContext c, MinecraftClient mc, Settings s) {
        if (!(s.wFps || s.wCps || s.wPing || s.wCoords || s.wKeys)) return;
        Theme T = Theme.of(s.uiStyle);
        boolean neon = s.uiStyle == 1;
        TextRenderer tr = mc.textRenderer;
        int acc = s.accentColor();
        int text = neon ? 0xFFEDEDF5 : T.text, muted = neon ? 0xFF8B8BA3 : T.muted;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int pos = Math.floorMod(s.wPos, 4);
        boolean right = pos == 1 || pos == 3, bottom = pos >= 2;

        List<String[]> rows = new ArrayList<>();
        if (s.wFps) rows.add(new String[]{"FPS", String.valueOf(mc.getCurrentFps())});
        if (s.wCps) rows.add(new String[]{"CPS", LEFT.size() + " | " + RIGHT.size()});
        if (s.wPing) {
            PlayerListEntry e = mc.getNetworkHandler() == null ? null
                    : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            rows.add(new String[]{"PING", e == null ? "-" : e.getLatency() + "ms"});
        }
        if (s.wCoords) {
            rows.add(new String[]{"XYZ", mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ()});
        }

        int keysH = s.wKeys ? 66 : 0;
        int total = rows.size() * 16 + (rows.isEmpty() || !s.wKeys ? 0 : 4) + keysH;
        int y = bottom ? sh - 6 - total : 18;
        for (String[] r : rows) {
            int w = tr.getWidth(r[0]) + tr.getWidth(r[1]) + 16;
            int x = right ? sw - w - 4 : 4;
            box(c, x, y, w, 14, T, neon);
            c.drawTextWithShadow(tr, r[0], x + 5, y + 3, muted);
            c.drawTextWithShadow(tr, r[1], x + w - 5 - tr.getWidth(r[1]), y + 3, text);
            y += 16;
        }
        if (s.wKeys) {
            if (!rows.isEmpty()) y += 4;
            int kx = right ? sw - 60 - 4 : 4;
            keystrokes(c, mc, tr, kx, y, T, neon, acc, text);
        }
    }

    private static void key(DrawContext c, TextRenderer tr, int x, int y, int w, int h, String label,
                            boolean down, Theme T, boolean neon, int acc, int text) {
        if (down) {
            c.fill(x, y, x + w, y + h, Ui.alpha(acc, 0xC8));
            c.fill(x, y, x + w, y + 1, Ui.alpha(0xFFFFFFFF, 0x60));
        } else {
            box(c, x, y, w, h, T, neon);
        }
        if (!label.isEmpty()) {
            c.drawTextWithShadow(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1,
                    down ? 0xFFFFFFFF : text);
        }
    }

    private static void keystrokes(DrawContext c, MinecraftClient mc, TextRenderer tr, int x, int y,
                                   Theme T, boolean neon, int acc, int text) {
        var o = mc.options;
        key(c, tr, x + 20, y, 18, 18, "W", o.forwardKey.isPressed(), T, neon, acc, text);
        key(c, tr, x, y + 20, 18, 18, "A", o.leftKey.isPressed(), T, neon, acc, text);
        key(c, tr, x + 20, y + 20, 18, 18, "S", o.backKey.isPressed(), T, neon, acc, text);
        key(c, tr, x + 40, y + 20, 18, 18, "D", o.rightKey.isPressed(), T, neon, acc, text);
        key(c, tr, x, y + 40, 28, 14, "L " + LEFT.size(), o.attackKey.isPressed(), T, neon, acc, text);
        key(c, tr, x + 30, y + 40, 28, 14, "R " + RIGHT.size(), o.useKey.isPressed(), T, neon, acc, text);
        key(c, tr, x, y + 56, 58, 8, "", o.jumpKey.isPressed(), T, neon, acc, text);
    }

    // ---------- crosshair ----------

    private static void crosshair(DrawContext c, MinecraftClient mc, Settings s) {
        if (!s.crosshair) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int extra = 0;
        if (s.chDynamic) {
            Vec3d v = mc.player.getVelocity();
            if (v.x * v.x + v.z * v.z > 0.0025) extra += 1;
            if (mc.player.isSprinting()) extra += 2;
        }
        drawCrosshairAt(c, sw / 2, sh / 2, extra);
    }

    public static void drawCrosshairAt(DrawContext c, int cx, int cy, int extraGap) {
        drawCrosshairAt(c, cx, cy, extraGap, 0);
    }

    /** cap > 0 limits the size, used for the small preview in the menu. */
    public static void drawCrosshairAt(DrawContext c, int cx, int cy, int extraGap, int cap) {
        Settings s = Settings.get();
        double t = System.currentTimeMillis() / 1000.0;
        int base;
        if (s.chColorMode == 1) base = 0xFF000000 | MathHelper.hsvToRgb(s.chHue / 360f, 1f, 1f);
        else if (s.chColorMode == 2) base = 0xFF000000 | MathHelper.hsvToRgb((float) ((t * 0.2) % 1.0), 0.8f, 1f);
        else base = s.accentColor();
        int a = Math.max(20, Math.min(100, s.chOpacity)) * 255 / 100;
        int color = Ui.alpha(base, a);
        int line = Ui.alpha(0xFF000000, a * 200 / 255);

        int size = Math.max(2, s.chSize), gap = Math.max(0, s.chGap) + extraGap, th = Math.max(1, s.chThick);
        if (cap > 0) {
            size = Math.min(size, cap);
            gap = Math.min(gap, cap / 2);
        }
        int lo = -(th / 2), hi = lo + th;
        List<int[]> r = new ArrayList<>();

        switch (Math.floorMod(s.chStyle, 6)) {
            case 1: // plus, no gap
                r.add(new int[]{cx - size, cy + lo, cx + size + 1, cy + hi});
                r.add(new int[]{cx + lo, cy - size, cx + hi, cy + size + 1});
                break;
            case 2: { // dot
                int d = Math.max(1, size / 3);
                r.add(new int[]{cx - d, cy - d, cx + d + 1, cy + d + 1});
                break;
            }
            case 3: { // circle
                int pts = Math.max(16, size * 6);
                for (int i = 0; i < pts; i++) {
                    double ang = i * Math.PI * 2 / pts;
                    int px = cx + (int) Math.round(Math.cos(ang) * (size + gap));
                    int py = cy + (int) Math.round(Math.sin(ang) * (size + gap));
                    r.add(new int[]{px + lo, py + lo, px + lo + th, py + lo + th});
                }
                break;
            }
            case 4: // T shape: left, right, down
                r.add(new int[]{cx - gap - size, cy + lo, cx - gap, cy + hi});
                r.add(new int[]{cx + gap + 1, cy + lo, cx + gap + 1 + size, cy + hi});
                r.add(new int[]{cx + lo, cy + gap + 1, cx + hi, cy + gap + 1 + size});
                break;
            case 5: { // diamond outline
                int rad = size + gap;
                for (int dy = -rad; dy <= rad; dy++) {
                    int half = rad - Math.abs(dy);
                    r.add(new int[]{cx - half, cy + dy, cx - half + th, cy + dy + 1});
                    if (half > 0) r.add(new int[]{cx + half - th + 1, cy + dy, cx + half + 1, cy + dy + 1});
                }
                break;
            }
            default: // cross with a gap
                r.add(new int[]{cx - gap - size, cy + lo, cx - gap, cy + hi});
                r.add(new int[]{cx + gap + 1, cy + lo, cx + gap + 1 + size, cy + hi});
                r.add(new int[]{cx + lo, cy - gap - size, cx + hi, cy - gap});
                r.add(new int[]{cx + lo, cy + gap + 1, cx + hi, cy + gap + 1 + size});
        }
        if (s.chDot && s.chStyle != 2) r.add(new int[]{cx, cy, cx + 1, cy + 1});

        if (s.chOutline) {
            for (int[] q : r) c.fill(q[0] - 1, q[1] - 1, q[2] + 1, q[3] + 1, line);
        }
        for (int[] q : r) c.fill(q[0], q[1], q[2], q[3], color);
    }
}
