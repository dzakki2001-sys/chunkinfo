package com.example.chunkinfo;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.GameOptionsScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.pack.PackScreen;

/** Draws the client theme behind the vanilla options, controls, pause and resource pack screens. */
public final class VanillaStyle {
    private VanillaStyle() {}

    public static boolean applies(Screen s) {
        return s instanceof GameOptionsScreen || s instanceof OptionsScreen || s instanceof GameMenuScreen
                || s instanceof PackScreen;
    }

    public static void draw(DrawContext c, Screen screen) {
        Settings s = Settings.get();
        if (!s.styleVanilla || !applies(screen)) return;
        Theme T = Theme.of(s.uiStyle);
        boolean neon = s.uiStyle == 1;
        int acc = s.accentColor();
        int w = screen.width, h = screen.height;
        double t = System.currentTimeMillis() / 1000.0;

        c.fill(0, 0, w, h, Ui.alpha(neon ? 0xFF0B0B12 : T.dark, 0xD2));
        Fx.draw(c, neon ? 1 : (T.fx != 0 ? T.fx : 1), 0, 0, w, h, t, acc);
        c.fillGradient(0, 0, w, h / 4, 0x55000000, 0x00000000);
        c.fillGradient(0, h * 3 / 4, w, h, 0x00000000, 0x55000000);
        c.fill(0, 0, w, 2, Ui.alpha(acc, 0xB0));
        c.fill(0, h - 2, w, h, Ui.alpha(acc, 0x60));
        Ui.corner(c, 5, 5, 1, 1, acc, 9);
        Ui.corner(c, w - 5, 5, -1, 1, acc, 9);
        Ui.corner(c, 5, h - 6, 1, -1, acc, 9);
        Ui.corner(c, w - 5, h - 6, -1, -1, acc, 9);
    }
}
