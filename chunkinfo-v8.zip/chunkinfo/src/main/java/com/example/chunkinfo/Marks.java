package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

/** Death point tracking and waypoints. */
public class Marks {
    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};

    private static boolean wasAlive = true;
    private static double lx, ly, lz;
    private static String ldim = "";

    public static String dim(MinecraftClient mc) {
        return mc.world.getRegistryKey().getValue().toString();
    }

    public static String server(MinecraftClient mc) {
        ServerInfo si = mc.getCurrentServerEntry();
        return si == null ? "local" : si.address;
    }

    public static String dimShort(String dim) {
        if (dim.endsWith("overworld")) return "OW";
        if (dim.endsWith("the_nether")) return "Nether";
        if (dim.endsWith("the_end")) return "End";
        int i = dim.indexOf(':');
        return i >= 0 ? dim.substring(i + 1) : dim;
    }

    public static void tick(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            wasAlive = true;
            return;
        }
        if (p.getHealth() > 0) {
            wasAlive = true;
            lx = p.getX();
            ly = p.getY();
            lz = p.getZ();
            ldim = dim(mc);
        } else if (wasAlive) {
            wasAlive = false;
            Data.get().death = new Data.Mark("Death", (int) Math.floor(lx), (int) Math.floor(ly),
                    (int) Math.floor(lz), ldim, server(mc));
            Data.save();
        }
    }

    public static void addWaypoint(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        String server = server(mc);
        int n = 1;
        for (Data.Mark m : Data.get().marks) if (m.server.equals(server)) n++;
        Data.get().marks.add(new Data.Mark("Waypoint " + n, mc.player.getBlockX(), mc.player.getBlockY(),
                mc.player.getBlockZ(), dim(mc), server));
        Data.save();
        mc.player.sendMessage(Text.literal("Waypoint " + n + " saved"), true);
    }

    public static double distance(MinecraftClient mc, Data.Mark m) {
        double dx = m.x + 0.5 - mc.player.getX();
        double dz = m.z + 0.5 - mc.player.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** Arrow showing where a point is relative to where you are looking. */
    public static String arrow(MinecraftClient mc, int tx, int tz) {
        double dx = tx + 0.5 - mc.player.getX();
        double dz = tz + 0.5 - mc.player.getZ();
        double target = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double rel = target - mc.player.getYaw();
        rel = ((rel % 360) + 540) % 360 - 180;
        int idx = Math.floorMod(Math.round((float) (rel / 45.0)), 8);
        return ARROWS[idx];
    }
}
