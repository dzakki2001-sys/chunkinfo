package com.example.chunkinfo;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Counts chosen items in your inventory for the HUD panel. */
public class ItemTracker {
    public static class Entry {
        public final String label;
        public final boolean defaultOn;
        public final Item item;

        Entry(String label, boolean defaultOn, Item item) {
            this.label = label;
            this.defaultOn = defaultOn;
            this.item = item;
        }
    }

    public static final List<Entry> ALL = new ArrayList<>();

    static {
        ALL.add(new Entry("Totem", true, Items.TOTEM_OF_UNDYING));
        ALL.add(new Entry("Ench. Gapple", true, Items.ENCHANTED_GOLDEN_APPLE));
        ALL.add(new Entry("Golden Apple", true, Items.GOLDEN_APPLE));
        ALL.add(new Entry("Ender Pearl", true, Items.ENDER_PEARL));
        ALL.add(new Entry("XP Bottle", false, Items.EXPERIENCE_BOTTLE));
        ALL.add(new Entry("Arrow", false, Items.ARROW));
        ALL.add(new Entry("Firework", false, Items.FIREWORK_ROCKET));
        ALL.add(new Entry("End Crystal", false, Items.END_CRYSTAL));
    }

    public static boolean isOn(Entry e) {
        return Settings.get().itemSel.getOrDefault(e.label, e.defaultOn);
    }

    public static int count(PlayerEntity p, Item item) {
        int n = 0;
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isOf(item)) n += st.getCount();
        }
        return n;
    }
}
