package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

/** Armor showcase: four framed slots with durability bars and a red "!!!" low-durability badge. */
public class ArmorHud {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    // faint outlines shown in empty slots (helmet, chestplate, leggings, boots)
    private static final String[][] MASKS = {
            {"", "", "",
                    "....########....",
                    "...#........#...",
                    "..#..........#..",
                    "..#..........#..",
                    "..#..........#..",
                    "..#..........#..",
                    "..####....####..",
                    "..#..#....#..#..",
                    "..####....####.."},
            {"", "",
                    "..###......###..",
                    ".#...#....#...#.",
                    ".#....####....#.",
                    ".#.#........#.#.",
                    ".###........###.",
                    "...#........#...",
                    "...#........#...",
                    "...#........#...",
                    "...#........#...",
                    "...#........#...",
                    "...##########..."},
            {"", "",
                    "..############..",
                    "..#..........#..",
                    "..#..........#..",
                    "..#....##....#..",
                    "..#...#..#...#..",
                    "..#...#..#...#..",
                    "..#...#..#...#..",
                    "..#...#..#...#..",
                    "..#...#..#...#..",
                    "..#####..#####.."},
            {"", "", "", "", "",
                    "..####....####..",
                    "..#..#....#..#..",
                    "..#..#....#..#..",
                    "..#..#....#..#..",
                    "..#..#....#..#..",
                    ".##..#....#..##.",
                    ".#...#....#...#.",
                    ".#############.."}
    };

    private static final int FRAME_W = 111, FRAME_H = 30;

    public static void render(DrawContext c, MinecraftClient mc) {
        Settings s = Settings.get();
        if (!s.armor || mc.player == null || mc.world == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int x, y;
        switch (Math.floorMod(s.armorPos, 5)) {
            case 1:
                x = (sw - FRAME_W) / 2;
                y = sh - 90;
                break;
            case 2:
                x = 6;
                y = (sh - FRAME_H) / 2;
                break;
            case 3:
                x = sw - FRAME_W - 6;
                y = (sh - FRAME_H) / 2;
                break;
            case 4:
                x = sw - FRAME_W - 6;
                y = sh - FRAME_H - 6;
                break;
            default:
                x = (sw - FRAME_W) / 2;
                y = 26;
        }

        // black outer frame
        c.fill(x, y, x + FRAME_W, y + FRAME_H, 0xFF000000);

        boolean warn = false;
        for (int i = 0; i < 4; i++) {
            ItemStack st = mc.player.getEquippedStack(SLOTS[i]);
            int sx = x + 2 + i * 27, sy = y + 2;
            slotBg(c, sx, sy);

            if (st.isEmpty()) {
                if (s.armorOutline) outline(c, MASKS[i], sx + 5, sy + 3);
                continue;
            }

            c.drawItem(st, sx + 5, sy + 3);

            if (st.isDamageable()) {
                int max = Math.max(1, st.getMaxDamage());
                float f = Math.max(0f, Math.min(1f, (max - st.getDamage()) / (float) max));
                int color = 0xFF000000 | MathHelper.hsvToRgb(f * 0.27f, 1f, 1f);
                c.fill(sx + 3, sy + 20, sx + 23, sy + 23, 0xFF000000);
                int fw = Math.max(1, Math.round(20 * f));
                c.fill(sx + 3, sy + 20, sx + 3 + fw, sy + 22, color);
                if (f * 100f <= s.armorWarnPct) warn = true;
                if (s.armorPercent) {
                    String pct = Math.round(f * 100) + "%";
                    c.drawTextWithShadow(tr, pct, sx + 13 - tr.getWidth(pct) / 2, y + FRAME_H + 2, color);
                }
            }
        }

        if (warn && s.armorWarn) badge(c, tr, x + 9, y - 14);
    }

    private static void slotBg(DrawContext c, int x, int y) {
        c.fill(x, y, x + 26, y + 26, 0xFF9A9A9A);          // light gray border
        c.fill(x, y, x + 26, y + 1, 0xFFC4C4C4);           // top highlight
        c.fill(x, y, x + 1, y + 26, 0xFFC4C4C4);           // left highlight
        c.fill(x + 1, y + 1, x + 25, y + 25, 0xFF4E4E4E);  // darker inner line
        c.fill(x + 2, y + 2, x + 24, y + 24, 0xE023250F);  // dark olive inside
    }

    private static void outline(DrawContext c, String[] mask, int x, int y) {
        for (int r = 0; r < mask.length; r++) {
            String row = mask[r];
            for (int k = 0; k < row.length(); k++) {
                if (row.charAt(k) == '#') c.fill(x + k, y + r, x + k + 1, y + r + 1, 0x66B4B48C);
            }
        }
    }

    // red badge with "!!!"
    private static void badge(DrawContext c, TextRenderer tr, int x, int y) {
        Ui.rrect(c, x - 1, y - 1, 16, 13, 5, 0xFF7A1010);
        Ui.rrect(c, x, y, 14, 11, 5, 0xFFE02B2B);
        c.fill(x + 3, y + 1, x + 11, y + 2, 0xFFFF6B6B);
        Text t = Text.literal("!!!").formatted(Formatting.BOLD);
        int w = tr.getWidth(t);
        c.drawTextWithShadow(tr, t, x + (14 - w) / 2, y + 2, 0xFFFFFFFF);
    }
}
