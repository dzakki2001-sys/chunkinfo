package com.example.chunkinfo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Settings {
    public static final int[] ACCENTS = {0xFF38BDF8, 0xFFD08A3E, 0xFFFF3B5C, 0xFFA855F7, 0xFF84CC16};
    public static final String[] ACCENT_NAMES = {"Ice", "Copper", "Crimson", "Violet", "Lime"};
    public static final String[] UI_STYLES = {"Mandala", "Neon"};
    public static final String[] STYLES = {"Flame", "Soul fire", "End rod", "Red dust"};
    public static final String[] POSITIONS = {"Top right", "Top left"};
    public static final String[] RADAR_POS = {"Right", "Left"};
    public static final String[] SCAN_TARGETS = {"Looking at", "Standing in"};
    public static final String[] ARMOR_POS = {"Top center", "Bottom center", "Left middle", "Right middle", "Bottom right"};

    public boolean borders = true;
    public boolean rings = true;
    public boolean panel = true;
    public boolean showCoords = true;
    public boolean showClean = true;
    public boolean autoScan = false;
    public int scanTarget = 0;
    public int autoTicks = 10;

    // armor showcase
    public boolean armor = true;
    public int armorPos = 0;
    public boolean armorWarn = true;
    public int armorWarnPct = 15;
    public boolean armorOutline = true;
    public boolean armorPercent = false;

    // info section
    public boolean info = false;
    public boolean infoCoords = true;
    public boolean infoFacing = true;
    public boolean infoBiome = true;
    public boolean infoLight = true;

    // death point + waypoints
    public boolean marksDeath = true;
    public boolean marksWp = true;
    public int marksMax = 3;

    // chat filter
    public boolean chatFilter = false;
    public boolean chatAds = true;
    public java.util.List<String> chatCustom = new java.util.ArrayList<>();

    // item counter
    public boolean items = false;
    public Map<String, Boolean> itemSel = new HashMap<>();

    // scan history
    public boolean history = true;
    public boolean radar = true;
    public int radarChunks = 8;
    public int radarMax = 6;
    public int radarPos = 1;
    public int style = 0;
    public int pulseTicks = 5;
    public int heightRange = 32;
    public int maxChunks = 8;
    public int ringEvery = 16;
    public int accent = 0;
    public int panelPos = 0;
    public int uiStyle = 0;
    public float gap = 0.5f;
    public float dustSize = 3.0f;
    public Map<String, Boolean> blocks = new HashMap<>();

    private static Settings instance = new Settings();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Settings get() {
        return instance;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("chunkinfo.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Settings s = GSON.fromJson(Files.readString(f), Settings.class);
                if (s != null) instance = s;
            }
        } catch (Exception ignored) {
        }
        if (instance.blocks == null) instance.blocks = new HashMap<>();
        if (instance.itemSel == null) instance.itemSel = new HashMap<>();
        if (instance.chatCustom == null) instance.chatCustom = new java.util.ArrayList<>();
        Targets.rebuild();
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(instance));
        } catch (Exception ignored) {
        }
    }

    public int accentColor() {
        return ACCENTS[Math.floorMod(accent, ACCENTS.length)];
    }
}
