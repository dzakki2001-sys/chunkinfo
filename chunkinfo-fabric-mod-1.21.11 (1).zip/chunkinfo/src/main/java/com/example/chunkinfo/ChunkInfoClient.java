package com.example.chunkinfo;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.StringJoiner;

public class ChunkInfoClient implements ClientModInitializer {
    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("chunkinfo", "main"));

    // Chunks that were scanned and contain non-natural blocks (drawn with a red border).
    private static final Map<Long, ScanResult> flagged = new HashMap<>();
    private static int tickCounter = 0;

    private KeyBinding scanKey, clearKey;

    @Override
    public void onInitializeClient() {
        scanKey = reg("key.chunkinfo.scan", GLFW.GLFW_KEY_G);
        clearKey = reg("key.chunkinfo.clear", GLFW.GLFW_KEY_K);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.world == null || mc.player == null) {
                flagged.clear();
                return;
            }
            while (clearKey.wasPressed()) {
                flagged.clear();
                say(mc, "Cleared chunk borders.");
            }
            while (scanKey.wasPressed()) scanLookedChunk(mc);
            drawBorders(mc);
        });
    }

    private static KeyBinding reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyBinding(name, InputUtil.Type.KEYSYM, key, CATEGORY));
    }

    private static void say(MinecraftClient mc, String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(msg), false);
    }

    private static void scanLookedChunk(MinecraftClient mc) {
        if (mc.getCameraEntity() == null) return;

        double dist = mc.options.getViewDistance().getValue() * 16.0;
        HitResult hit = mc.getCameraEntity().raycast(dist, 1.0f, false);
        BlockPos bp = (hit instanceof BlockHitResult b && hit.getType() == HitResult.Type.BLOCK)
                ? b.getBlockPos()
                : BlockPos.ofFloored(hit.getPos());

        ChunkPos cp = new ChunkPos(bp);
        WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z);
        if (chunk == null) {
            say(mc, "Chunk " + cp.x + ", " + cp.z + " is not loaded.");
            return;
        }

        ScanResult r = ChunkScanner.scan(chunk);
        if (r.total == 0) {
            flagged.remove(cp.toLong());
            say(mc, "Chunk " + cp.x + ", " + cp.z + ": no non-natural blocks.");
            return;
        }

        flagged.put(cp.toLong(), r);
        StringJoiner list = new StringJoiner(", ");
        r.counts.forEach((block, n) -> list.add(block.getName().getString() + " x" + n));
        StringJoiner where = new StringJoiner(" | ");
        for (BlockPos p : r.samples) where.add(p.getX() + " " + p.getY() + " " + p.getZ());

        say(mc, "Chunk " + cp.x + ", " + cp.z + ": " + r.total + " non-natural block(s)");
        say(mc, list.toString());
        say(mc, "At: " + where);
    }

    // Red border made of red dust particles around the flagged chunk edges.
    private static void drawBorders(MinecraftClient mc) {
        if (flagged.isEmpty() || ++tickCounter % 10 != 0) return;

        ParticleEffect red = new DustParticleEffect(0xFF0000, 1.5f);
        ChunkPos pc = mc.player.getChunkPos();
        int py = (int) mc.player.getY();
        int yLow = Math.max(mc.world.getBottomY(), py - 24);
        int yHigh = Math.min(mc.world.getBottomY() + mc.world.getHeight(), py + 24);

        for (ScanResult r : flagged.values()) {
            if (Math.abs(r.pos.x - pc.x) > 8 || Math.abs(r.pos.z - pc.z) > 8) continue;

            double x0 = r.pos.getStartX(), z0 = r.pos.getStartZ();
            double x1 = x0 + 16, z1 = z0 + 16;

            // four vertical corner lines
            for (int y = yLow; y <= yHigh; y += 2) {
                mc.world.addImportantParticleClient(red, x0, y, z0, 0, 0, 0);
                mc.world.addImportantParticleClient(red, x1, y, z0, 0, 0, 0);
                mc.world.addImportantParticleClient(red, x0, y, z1, 0, 0, 0);
                mc.world.addImportantParticleClient(red, x1, y, z1, 0, 0, 0);
            }

            // horizontal rings every 16 blocks
            for (int y = Math.floorDiv(yLow + 15, 16) * 16; y <= yHigh; y += 16) {
                for (int t = 0; t <= 16; t += 2) {
                    mc.world.addImportantParticleClient(red, x0 + t, y, z0, 0, 0, 0);
                    mc.world.addImportantParticleClient(red, x0 + t, y, z1, 0, 0, 0);
                    mc.world.addImportantParticleClient(red, x0, y, z0 + t, 0, 0, 0);
                    mc.world.addImportantParticleClient(red, x1, y, z0 + t, 0, 0, 0);
                }
            }
        }
    }
}
