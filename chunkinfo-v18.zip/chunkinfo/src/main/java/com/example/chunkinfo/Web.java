package com.example.chunkinfo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;

/** Small HTTP helper (plain HttpURLConnection, works on every launcher). */
public final class Web {
    private Web() {}

    public static final String UA = "dzakki2001-sys/daz-client/1.0 (Minecraft client mod)";

    private static HttpURLConnection open(String url, String method) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", UA);
        c.setInstanceFollowRedirects(true);
        return c;
    }

    private static byte[] readAll(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n, total = 0;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > max) throw new IOException("File is too large");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    public static byte[] get(String url, int max) throws IOException {
        HttpURLConnection c = open(url, "GET");
        int code = c.getResponseCode();
        if (code != 200) throw new IOException("HTTP " + code);
        try (InputStream in = c.getInputStream()) {
            return readAll(in, max);
        }
    }

    public static String getString(String url) throws IOException {
        return new String(get(url, 4_000_000), StandardCharsets.UTF_8);
    }

    /** JSON request (GET, PUT, DELETE...) with a bearer token. Returns the HTTP status code. */
    public static int json(String method, String url, String bearer, String body, StringBuilder response) throws IOException {
        HttpURLConnection c = open(url, method);
        c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            try (OutputStream o = c.getOutputStream()) {
                o.write(body.getBytes(StandardCharsets.UTF_8));
            }
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in != null) {
            try (InputStream i = in) {
                response.append(new String(readAll(i, 200000), StandardCharsets.UTF_8));
            }
        }
        return code;
    }

    /** Multipart POST with one PNG file. Returns the HTTP status code. */
    public static int postMultipart(String url, String bearer, Map<String, String> fields, String fileField,
                                    String fileName, byte[] file, StringBuilder response) throws IOException {
        String boundary = "----daz" + UUID.randomUUID();
        HttpURLConnection c = open(url, "POST");
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + bearer);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (OutputStream out = c.getOutputStream()) {
            for (Map.Entry<String, String> e : fields.entrySet()) {
                out.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + e.getKey()
                        + "\"\r\n\r\n" + e.getValue() + "\r\n").getBytes(StandardCharsets.UTF_8));
            }
            out.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + fileField
                    + "\"; filename=\"" + fileName + "\"\r\nContent-Type: image/png\r\n\r\n")
                    .getBytes(StandardCharsets.UTF_8));
            out.write(file);
            out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in != null) {
            try (InputStream i = in) {
                response.append(new String(readAll(i, 200000), StandardCharsets.UTF_8));
            }
        }
        return code;
    }
}
