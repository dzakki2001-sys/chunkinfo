package com.example.chunkinfo;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

/**
 * Installs and removes mods and resource packs. Downloads only come from Modrinth's official CDN and
 * are checked against the SHA-512 hash that Modrinth publishes before anything is written to disk.
 */
public final class ModManager {
    private ModManager() {}

    public static class Result {
        public String id = "", title = "", author = "", desc = "";
        public int downloads;
    }

    public static class Entry {
        public String kind = "", name = "";
        public Path path;
        public long size;
        public boolean locked;
    }

    private static final String FABRIC_API_ID = "P7dR8mSH";
    public static volatile String status = "";
    public static volatile boolean busy = false;

    public static void async(Runnable r) {
        Thread t = new Thread(() -> {
            try {
                r.run();
            } catch (Throwable e) {
                status = "Error: " + e.getMessage();
                busy = false;
            }
        }, "daz-net");
        t.setDaemon(true);
        t.start();
    }

    private static Path gameDir() {
        return FabricLoader.getInstance().getGameDir();
    }

    public static String gameVersion() {
        return FabricLoader.getInstance().getModContainer("minecraft")
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("1.21.11");
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    // ---------- search ----------

    public static List<Result> search(String query, String type) throws IOException {
        String mc = gameVersion();
        String facets = type.equals("mod")
                ? "[[\"project_type:mod\"],[\"versions:" + mc + "\"],[\"categories:fabric\"]]"
                : "[[\"project_type:resourcepack\"],[\"versions:" + mc + "\"]]";
        String q = query == null ? "" : query.trim();
        String url = "https://api.modrinth.com/v2/search?query=" + enc(q) + "&limit=12&index="
                + (q.isEmpty() ? "downloads" : "relevance") + "&facets=" + enc(facets);
        JsonObject o = JsonParser.parseString(Web.getString(url)).getAsJsonObject();
        List<Result> out = new ArrayList<>();
        for (JsonElement e : o.getAsJsonArray("hits")) {
            JsonObject h = e.getAsJsonObject();
            Result r = new Result();
            r.id = h.get("project_id").getAsString();
            r.title = h.get("title").getAsString();
            r.author = h.has("author") ? h.get("author").getAsString() : "";
            r.desc = h.has("description") ? h.get("description").getAsString() : "";
            r.downloads = h.has("downloads") ? h.get("downloads").getAsInt() : 0;
            out.add(r);
        }
        return out;
    }

    // ---------- install ----------

    public static void install(String projectId, String title, String type) {
        busy = true;
        status = "Installing " + title + "...";
        try {
            status = title + ": " + installInner(projectId, type, 0);
        } catch (Exception e) {
            status = "Failed: " + e.getMessage();
        } finally {
            busy = false;
        }
    }

    private static boolean hasFabricApi() {
        Path mods = gameDir().resolve("mods");
        if (!Files.isDirectory(mods)) return false;
        try (Stream<Path> s = Files.list(mods)) {
            return s.anyMatch(p -> p.getFileName().toString().toLowerCase().startsWith("fabric-api"));
        } catch (IOException e) {
            return false;
        }
    }

    private static String installInner(String projectId, String type, int depth) throws Exception {
        String mc = gameVersion();
        String url = "https://api.modrinth.com/v2/project/" + projectId + "/version?game_versions="
                + enc("[\"" + mc + "\"]") + (type.equals("mod") ? "&loaders=" + enc("[\"fabric\"]") : "");
        JsonArray versions = JsonParser.parseString(Web.getString(url)).getAsJsonArray();
        if (versions.size() == 0) return "no version for Minecraft " + mc;
        JsonObject v = versions.get(0).getAsJsonObject();

        JsonArray files = v.getAsJsonArray("files");
        JsonObject f = files.get(0).getAsJsonObject();
        for (JsonElement fe : files) {
            JsonObject fo = fe.getAsJsonObject();
            if (fo.has("primary") && fo.get("primary").getAsBoolean()) {
                f = fo;
                break;
            }
        }
        String fileUrl = f.get("url").getAsString();
        String filename = f.get("filename").getAsString();
        String sha512 = f.getAsJsonObject("hashes").get("sha512").getAsString();

        if (!fileUrl.startsWith("https://cdn.modrinth.com/")) throw new IOException("unexpected download host");
        if (!filename.matches("[A-Za-z0-9._+ ()-]+")) throw new IOException("unsafe file name");
        String lower = filename.toLowerCase();
        if (!(lower.endsWith(".jar") || lower.endsWith(".zip"))) throw new IOException("unexpected file type");

        Path dir = gameDir().resolve(type.equals("mod") ? "mods" : "resourcepacks");
        Files.createDirectories(dir);
        Path target = dir.resolve(filename).normalize();
        if (!target.startsWith(dir)) throw new IOException("bad path");

        String result;
        if (Files.exists(target)) {
            result = "already installed";
        } else {
            byte[] data = Web.get(fileUrl, 80_000_000);
            String got = hex(MessageDigest.getInstance("SHA-512").digest(data));
            if (!got.equalsIgnoreCase(sha512)) throw new IOException("hash mismatch, nothing was saved");
            Path tmp = dir.resolve(filename + ".part");
            Files.write(tmp, data);
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            result = type.equals("mod") ? "installed. Restart the game to load it."
                    : "installed. Enable it in Options > Resource Packs.";
        }

        // required dependencies (mods only, two levels deep at most)
        if (type.equals("mod") && depth < 2 && v.has("dependencies")) {
            for (JsonElement de : v.getAsJsonArray("dependencies")) {
                JsonObject d = de.getAsJsonObject();
                if (!d.has("dependency_type") || !d.get("dependency_type").getAsString().equals("required")) continue;
                if (!d.has("project_id") || d.get("project_id").isJsonNull()) continue;
                String depId = d.get("project_id").getAsString();
                if (depId.equals(FABRIC_API_ID) && hasFabricApi()) continue;
                String r = installInner(depId, type, depth + 1);
                result += " (+ dependency: " + r + ")";
            }
        }
        return result;
    }

    /** One click: installs well-known FPS mods from Modrinth (each one is hash-checked like any install). */
    public static void installPerformancePack() {
        String[][] pack = {{"sodium", "Sodium"}, {"lithium", "Lithium"}, {"ferrite-core", "FerriteCore"},
                {"immediatelyfast", "ImmediatelyFast"}, {"entityculling", "Entity Culling"}};
        busy = true;
        int ok = 0;
        for (String[] p : pack) {
            status = "Installing " + p[1] + "...";
            try {
                String r = installInner(p[0], "mod", 0);
                if (!r.startsWith("no version")) ok++;
            } catch (Exception ignored) {
            }
        }
        busy = false;
        status = ok + "/" + pack.length + " FPS mods ready. Restart the game to load them.";
    }

    // ---------- installed files ----------

    public static List<Entry> listInstalled() {
        List<Entry> out = new ArrayList<>();
        Path mods = gameDir().resolve("mods");
        Path packs = gameDir().resolve("resourcepacks");
        try {
            if (Files.isDirectory(mods)) {
                try (Stream<Path> s = Files.list(mods)) {
                    s.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".jar")).sorted().forEach(p -> {
                        Entry e = new Entry();
                        e.kind = "mod";
                        e.name = p.getFileName().toString();
                        e.path = p;
                        e.size = size(p);
                        String n = e.name.toLowerCase();
                        e.locked = n.startsWith("chunkinfo-") || n.startsWith("dazclient-");
                        out.add(e);
                    });
                }
            }
            if (Files.isDirectory(packs)) {
                try (Stream<Path> s = Files.list(packs)) {
                    s.filter(p -> Files.isDirectory(p) || p.getFileName().toString().toLowerCase().endsWith(".zip"))
                            .sorted().forEach(p -> {
                                Entry e = new Entry();
                                e.kind = "pack";
                                e.name = p.getFileName().toString();
                                e.path = p;
                                e.size = size(p);
                                out.add(e);
                            });
                }
            }
        } catch (IOException ignored) {
        }
        return out;
    }

    private static long size(Path p) {
        try {
            return Files.isRegularFile(p) ? Files.size(p) : 0;
        } catch (IOException e) {
            return 0;
        }
    }

    public static void delete(Entry e) {
        try {
            Path root = gameDir().resolve(e.kind.equals("mod") ? "mods" : "resourcepacks").normalize();
            Path p = e.path.normalize();
            if (!p.startsWith(root) || p.equals(root)) throw new IOException("bad path");
            if (Files.isDirectory(p)) {
                try (Stream<Path> w = Files.walk(p)) {
                    w.sorted(Comparator.reverseOrder()).forEach(x -> {
                        try {
                            Files.deleteIfExists(x);
                        } catch (IOException ignored) {
                        }
                    });
                }
            } else {
                Files.deleteIfExists(p);
            }
            status = "Deleted " + e.name + (e.kind.equals("mod") ? " (takes effect after restart)" : "");
        } catch (Exception ex) {
            status = "Could not delete: " + ex.getMessage();
        }
    }
}
