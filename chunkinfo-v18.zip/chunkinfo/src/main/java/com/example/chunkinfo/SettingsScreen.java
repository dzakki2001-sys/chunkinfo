package com.example.chunkinfo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class SettingsScreen extends Screen {
    // Neon style colours
    private static final int BG = 0xF2101018, SIDE = 0xFF0C0C13, SURF = 0xFF171722, SURF_H = 0xFF20202F,
            LINE = 0xFF2B2B3F, OFF = 0xFF34344A, GREEN = 0xFF4ADE80, AMBER = 0xFFFBBF24;
    private Theme T = Theme.of(0);

    private static final String PACK = "Daz Client";
    private static final String[] GROUPS = {"Scan", "Panel", "Marks", "Chat", "Client", "Manage", "More"};
    private static final String[][] SUBS = {
            {"Chunk", "Border", "Blocks", "History"},
            {"Layout", "Players", "Info"},
            {"Waypoints", "Hologram"},
            {"Settings", "History"},
            {"Boost", "HUD", "Crosshair", "Swap", "Perf", "Extras"},
            {"Installed", "Mods", "Packs", "Skin", "Capes"},
            {"Keys", "About"}};
    /** Group index of the Marks section (used when B opens the name editor). */
    public static final int MARKS_TAB = 2;

    private interface Ctl {
        void draw(DrawContext c, int x, int y, int w);
    }

    private int group = 0, accent, chatMode = 0;
    private final int[] sub = new int[GROUPS.length];
    private final int[] pages = new int[GROUPS.length * 8];
    private boolean prevY, leftDown, clicked, dirty, pendingClick, mand;
    private int cText, cMuted;
    private double pendingX, pendingY, clickX, clickY;
    private int mx, my;
    private String dragId = null;
    private Screen parent = null;

    private TextFieldWidget nameField;
    private Data.Mark editMark = null, pendingEdit = null;
    private String editBuffer = "";

    // client / manage state
    private TextFieldWidget searchField;
    private String lastKey = "";
    private long pageT = 0;
    private boolean perfDirty = false, skinSlim = false;
    private String lastBrowse = "", confirmName = "";
    private long confirmUntil = 0, instAt = 0, skinAt = 0;
    private volatile List<ModManager.Result> results = new ArrayList<>();
    private volatile String browseNote = "";
    private List<ModManager.Entry> instCache = new ArrayList<>();
    private List<java.nio.file.Path> skinCache = new ArrayList<>();

    // content area
    private int cx, cy, cw, ch, colW;

    // easter egg state
    private long lastMs = 0, boostUntil = 0, rainbowUntil = 0, popStart = 0;
    private double ornPhase = 0;
    private int eggOrb = 0, eggLogo = 0;
    private String popText = "";
    private final List<double[]> sparks = new ArrayList<>();
    private int orCx, orCy, orR, logoX, logoY;

    public SettingsScreen() {
        super(Text.literal(PACK));
    }

    /** Open on a group, optionally straight into the waypoint editor. */
    public SettingsScreen(int startGroup, Data.Mark edit) {
        super(Text.literal(PACK));
        this.group = Math.max(0, Math.min(GROUPS.length - 1, startGroup));
        this.pendingEdit = edit;
        if (edit != null) this.sub[this.group] = 0;
    }

    public SettingsScreen(int startGroup, int startSub, Screen parent) {
        super(Text.literal(PACK));
        this.group = Math.max(0, Math.min(GROUPS.length - 1, startGroup));
        this.sub[this.group] = Math.max(0, Math.min(SUBS[this.group].length - 1, startSub));
        this.parent = parent;
    }

    public static SettingsScreen at(String g, String sb, Screen parent) {
        int gi = 0, si = 0;
        for (int i = 0; i < GROUPS.length; i++) if (GROUPS[i].equals(g)) gi = i;
        for (int i = 0; i < SUBS[gi].length; i++) if (SUBS[gi][i].equals(sb)) si = i;
        return new SettingsScreen(gi, si, parent);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }

    @Override
    protected void init() {
        // Name field first, so it gets clicks before the full-screen catcher below.
        nameField = new TextFieldWidget(this.textRenderer, 0, 0, 100, 12, Text.empty());
        nameField.setMaxLength(24);
        nameField.setDrawsBackground(false);
        nameField.visible = false;
        this.addDrawableChild(nameField);

        searchField = new TextFieldWidget(this.textRenderer, 0, 0, 100, 12, Text.empty());
        searchField.setMaxLength(40);
        searchField.setDrawsBackground(false);
        searchField.visible = false;
        this.addDrawableChild(searchField);

        // Invisible full-screen button: the game's own click handling feeds us clicks and taps.
        ButtonWidget catcher = ButtonWidget.builder(Text.empty(), b -> onCatch())
                .dimensions(0, 0, this.width, this.height).build();
        catcher.setAlpha(0f);
        this.addDrawableChild(catcher);
        prevY = keyDown(GLFW.GLFW_KEY_Y);

        if (pendingEdit != null) {
            startEdit(pendingEdit);
            pendingEdit = null;
        } else if (editMark != null) {
            startEdit(editMark);
            nameField.setText(editBuffer);
        }
    }

    private void onCatch() {
        MinecraftClient mc = MinecraftClient.getInstance();
        pendingX = mc.mouse.getX() * mc.getWindow().getScaledWidth() / (double) mc.getWindow().getWidth();
        pendingY = mc.mouse.getY() * mc.getWindow().getScaledHeight() / (double) mc.getWindow().getHeight();
        pendingClick = true;
    }

    private boolean keyDown(int key) {
        return GLFW.glfwGetKey(MinecraftClient.getInstance().getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
    }

    private boolean mouseDown() {
        return GLFW.glfwGetMouseButton(MinecraftClient.getInstance().getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private boolean typing() {
        return (editMark != null && nameField != null && nameField.visible && nameField.isFocused())
                || (searchField != null && searchField.visible && searchField.isFocused());
    }

    private void startEdit(Data.Mark m) {
        editMark = m;
        editBuffer = m.name;
        if (nameField != null) {
            nameField.setText(m.name);
            nameField.visible = true;
            nameField.setFocused(true);
            this.setFocused(nameField);
        }
    }

    private void endEdit(boolean save) {
        if (editMark != null && save && nameField != null) {
            String n = nameField.getText().trim();
            if (!n.isEmpty()) editMark.name = n;
            Data.save();
        }
        editMark = null;
        if (nameField != null) {
            nameField.visible = false;
            nameField.setFocused(false);
        }
        this.setFocused(null);
    }

    public boolean shouldPause() {
        return false;
    }

    public void removed() {
        Settings.save();
        Data.save();
    }

    private int pageIdx() {
        return group * 8 + sub[group];
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        pages[pageIdx()] += verticalAmount < 0 ? 1 : -1;
        return true;
    }

    // ---------- helpers ----------

    private static boolean hit(double px, double py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private boolean hov(int x, int y, int w, int h) {
        return hit(mx, my, x, y, w, h);
    }

    private boolean clk(int x, int y, int w, int h) {
        return clicked && hit(clickX, clickY, x, y, w, h);
    }

    private void text(DrawContext c, String s, int x, int y, int color) {
        c.drawTextWithShadow(this.textRenderer, s, x, y, color);
    }

    private int tw(String s) {
        return this.textRenderer.getWidth(s);
    }

    private String fit(String s, int max) {
        if (tw(s) <= max) return s;
        while (s.length() > 1 && tw(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private int cellX(int i) {
        return cx + (i % 2) * (colW + 8);
    }

    private int cellY(int i) {
        return cy + 42 + (i / 2) * 28;
    }

    private static float snap(float v, float step) {
        return Math.round(v / step) * step;
    }

    private int valColor() {
        return mand ? Ui.shade(accent, 25) : accent;
    }

    /** Background of a control row. Bevel styles: inset slot. Neon: rounded card. */
    private void card(DrawContext c, int x, int y, int w, int h, boolean hv) {
        if (mand) Ui.bevel(c, x, y, w, h, hv ? T.slotH : T.slot, T.slotDk, T.slotLt, T.border);
        else Ui.rrect(c, x, y, w, h, 5, hv ? SURF_H : SURF);
    }

    // ---------- controls ----------

    private boolean toggle(DrawContext c, String label, boolean v, int x, int y, int w, int dot) {
        boolean h = hov(x, y, w, 24);
        card(c, x, y, w, 24, h);
        int tx = x + 8;
        if (dot != 0) {
            Ui.rrect(c, x + 8, y + 10, 4, 4, 2, dot);
            tx = x + 17;
        }
        text(c, fit(label, w - 34 - (tx - x)), tx, y + 8, cText);
        if (mand) {
            int bx = x + w - 22, by = y + 5;
            Ui.bevel(c, bx, by, 14, 14, T.well, T.dark, T.slotLt, T.border);
            if (v) {
                c.fill(bx + 3, by + 3, bx + 11, by + 11, accent);
                c.fill(bx + 3, by + 3, bx + 11, by + 4, Ui.shade(accent, 60));
                c.fill(bx + 3, by + 10, bx + 11, by + 11, Ui.shade(accent, -50));
            }
        } else {
            int sx = x + w - 30, sy = y + 7;
            Ui.rrect(c, sx, sy, 22, 10, 5, v ? accent : OFF);
            Ui.rrect(c, sx + (v ? 12 : 0), sy, 10, 10, 5, 0xFFFFFFFF);
        }
        if (clk(x, y, w, 24)) {
            dirty = true;
            return !v;
        }
        return v;
    }

    private float slider(DrawContext c, String id, String label, String val, float v, float min, float max, int x, int y, int w) {
        boolean h = hov(x, y, w, 24) || id.equals(dragId);
        card(c, x, y, w, 24, h);
        text(c, label, x + 8, y + 4, cText);
        text(c, val, x + w - 8 - tw(val), y + 4, valColor());
        int tx = x + 8, tw = w - 16, ty = y + 17;
        float f = Math.max(0f, Math.min(1f, (v - min) / (max - min)));
        if (mand) {
            Ui.bevel(c, tx, ty - 1, tw, 5, T.well, T.dark, T.slotLt, T.border);
            int fw = (int) ((tw - 2) * f);
            if (fw > 0) c.fill(tx + 1, ty, tx + 1 + fw, ty + 3, accent);
            Ui.bevel(c, tx + (int) ((tw - 7) * f), ty - 4, 7, 10, Ui.shade(T.btnLt, 20), Ui.shade(T.btnLt, 70), T.slotLt, T.border);
        } else {
            Ui.rrect(c, tx, ty, tw, 3, 1, OFF);
            Ui.rrect(c, tx, ty, Math.max(2, (int) (tw * f)), 3, 1, accent);
            Ui.rrect(c, tx + (int) (tw * f) - 3, ty - 2, 6, 7, 3, 0xFFFFFFFF);
        }

        if (clk(x, y, w, 24)) {
            dragId = id;
            dirty = true;
            return min + Math.max(0f, Math.min(1f, (float) (clickX - tx) / tw)) * (max - min);
        }
        if (leftDown && id.equals(dragId)) {
            dirty = true;
            return min + Math.max(0f, Math.min(1f, (float) (mx - tx) / tw)) * (max - min);
        }
        return v;
    }

    private int cycle(DrawContext c, String label, String[] opts, int cur, int x, int y, int w) {
        boolean h = hov(x, y, w, 24);
        card(c, x, y, w, 24, h);
        text(c, label, x + 8, y + 8, cText);
        String val = "< " + opts[Math.floorMod(cur, opts.length)] + " >";
        text(c, val, x + w - 8 - tw(val), y + 8, valColor());
        if (clk(x, y, w, 24)) {
            dirty = true;
            return (cur + 1) % opts.length;
        }
        return cur;
    }

    private boolean button(DrawContext c, String label, int x, int y, int w, int h, boolean primary) {
        boolean hv = hov(x, y, w, h);
        if (mand) {
            int fill = primary ? Ui.shade(accent, hv ? -20 : -45) : (hv ? T.btnH : T.btn);
            Ui.bevel(c, x, y, w, h, fill, primary ? Ui.shade(accent, 60) : T.btnLt,
                    primary ? Ui.shade(accent, -90) : T.dark, T.border);
        } else {
            int bg = primary ? Ui.alpha(accent, hv ? 0xFF : 0xCC) : (hv ? SURF_H : SURF);
            Ui.rrect(c, x, y, w, h, 5, bg);
        }
        String lb = fit(label, Math.max(8, w - 6));
        text(c, lb, x + (w - tw(lb)) / 2, y + (h - 8) / 2, primary ? 0xFFFFFFFF : cText);
        return clk(x, y, w, h);
    }

    private boolean smallBtn(DrawContext c, String label, int x, int y, int w) {
        boolean hv = hov(x, y, w, 16);
        if (mand) Ui.bevel(c, x, y, w, 16, hv ? T.btnH : T.btn, T.btnLt, T.dark, T.border);
        else Ui.rrect(c, x, y, w, 16, 4, hv ? SURF_H : OFF);
        text(c, label, x + 5, y + 4, cText);
        return clk(x, y, w, 16);
    }

    /** One list row with a small button on the right. Returns true if that button was clicked. */
    private boolean listRow(DrawContext c, int x, int y, int w, String label, String btn) {
        card(c, x, y, w, 20, false);
        int bw = tw(btn) + 10;
        text(c, fit(label, w - bw - 18), x + 8, y + 6, cText);
        return smallBtn(c, btn, x + w - bw - 3, y + 2, bw);
    }

    private int pager(DrawContext c, int page, int pageCount, int x, int y) {
        int n = Math.max(1, pageCount);
        if (button(c, "<", x, y, 20, 20, false)) page--;
        String pg = (Math.max(0, Math.min(page, n - 1)) + 1) + "/" + n;
        text(c, pg, x + 26, y + 6, cMuted);
        if (button(c, ">", x + 28 + tw(pg), y, 20, 20, false)) page++;
        return Math.max(0, Math.min(page, n - 1));
    }

    private int listRows(int listTop) {
        return Math.max(1, (cy + ch - 26 - listTop) / 22);
    }

    /** Lays controls out two per row. If they do not fit, they are split over pages automatically. */
    private void drawControls(DrawContext ctx, List<Ctl> ctls, String... notes) {
        int top = cy + 42;
        int rowsAll = (ctls.size() + 1) / 2;
        int rowsFit = Math.max(1, (cy + ch - top) / 28);
        boolean paged = rowsAll > rowsFit;
        if (paged) rowsFit = Math.max(1, (cy + ch - top - 26) / 28);
        int per = rowsFit * 2;
        int pageCount = paged ? (ctls.size() + per - 1) / per : 1;
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));

        int start = paged ? pages[pi] * per : 0;
        int end = paged ? Math.min(ctls.size(), start + per) : ctls.size();
        for (int k = start; k < end; k++) {
            int slot = k - start;
            ctls.get(k).draw(ctx, cx + (slot % 2) * (colW + 8), top + (slot / 2) * 28, colW);
        }
        if (paged) {
            pages[pi] = pager(ctx, pages[pi], pageCount, cx, cy + ch - 22);
        } else {
            int ny = top + ((end - start + 1) / 2) * 28 + 2;
            for (String n : notes) {
                if (ny + 10 < cy + ch) text(ctx, fit(n, cw), cx, ny, cMuted);
                ny += 11;
            }
        }
    }

    /** Rotating flower ornament. R is chosen from the free space, so it never gets covered. */
    private void ornament(DrawContext c, int mcx, int mcy, int R, double t, int col) {
        double rotA = t * 0.25, rotB = -t * 0.4, rotC = t * 0.7;

        int nA = Math.max(16, R);
        for (int i = 0; i < nA; i++) {
            double a = rotA + i * Math.PI * 2 / nA;
            int x = mcx + (int) Math.round(Math.cos(a) * R * 0.95);
            int y = mcy + (int) Math.round(Math.sin(a) * R * 0.95);
            boolean big = i % 4 == 0;
            c.fill(x, y, x + (big ? 2 : 1), y + (big ? 2 : 1), Ui.alpha(col, big ? 0xB0 : 0x55));
        }

        if (R >= 16) {
            for (int p = 0; p < 8; p++) {
                double a = rotB + p * Math.PI / 4;
                double ca = Math.cos(a), sa = Math.sin(a);
                for (int k = 0; k < 5; k++) {
                    double rr = R * (0.38 + 0.1 * k);
                    int x = mcx + (int) Math.round(ca * rr);
                    int y = mcy + (int) Math.round(sa * rr);
                    c.fill(x, y, x + 1, y + 1, Ui.alpha(col, 0x70 + k * 0x18));
                    if (k == 1 || k == 2 || k == 3) {
                        double off = k == 2 ? 2.5 : 1.5;
                        int x1 = mcx + (int) Math.round(ca * rr - sa * off);
                        int y1 = mcy + (int) Math.round(sa * rr + ca * off);
                        int x2 = mcx + (int) Math.round(ca * rr + sa * off);
                        int y2 = mcy + (int) Math.round(sa * rr - ca * off);
                        c.fill(x1, y1, x1 + 1, y1 + 1, Ui.alpha(col, 0x60));
                        c.fill(x2, y2, x2 + 1, y2 + 1, Ui.alpha(col, 0x60));
                    }
                }
            }
            for (int q = 0; q < 12; q++) {
                double a = rotC + q * Math.PI / 6;
                int x = mcx + (int) Math.round(Math.cos(a) * R * 0.27);
                int y = mcy + (int) Math.round(Math.sin(a) * R * 0.27);
                c.fill(x, y, x + 1, y + 1, Ui.alpha(col, 0x90));
            }
        }

        double pulse = 0.5 + 0.5 * Math.sin(t * 2.2);
        Ui.diamondDot(c, mcx, mcy, Ui.shade(col, (int) (40 * pulse)));
        c.fill(mcx, mcy, mcx + 1, mcy + 1, Ui.alpha(0xFFFFFFFF, 0x90 + (int) (100 * pulse)));
    }

    // ---------- easter egg ----------

    private void burst(double x, double y, int n, boolean confetti, long now) {
        for (int i = 0; i < n && sparks.size() < 160; i++) {
            double a = Math.random() * Math.PI * 2;
            double sp = confetti ? 30 + Math.random() * 70 : 20 + Math.random() * 60;
            int col = confetti
                    ? 0xFF000000 | MathHelper.hsvToRgb((float) Math.random(), 0.7f, 1f)
                    : Ui.alpha(accent, 255);
            sparks.add(new double[]{x, y, Math.cos(a) * sp, Math.sin(a) * sp - (confetti ? 40 : 0),
                    0.9 + Math.random() * 0.8, col});
        }
    }

    private void pop(String s, long now) {
        popText = s;
        popStart = now;
    }

    private void eggUpdateDraw(DrawContext ctx, double dt, long now) {
        for (int i = sparks.size() - 1; i >= 0; i--) {
            double[] p = sparks.get(i);
            p[4] -= dt;
            if (p[4] <= 0) {
                sparks.remove(i);
                continue;
            }
            p[0] += p[2] * dt;
            p[1] += p[3] * dt;
            p[3] += 90 * dt;
            int a = (int) Math.min(255, p[4] * 255);
            int x = (int) p[0], y = (int) p[1];
            ctx.fill(x, y, x + 2, y + 2, Ui.alpha((int) p[5], a));
        }
        if (popStart > 0) {
            double age = (now - popStart) / 1000.0;
            if (age > 2.6) {
                popStart = 0;
            } else {
                int a = (int) (255 * Math.min(1.0, Math.min(age * 4, (2.6 - age) * 2)));
                int tx = (orR > 0 ? orCx : this.width / 2) - tw(popText) / 2;
                int ty = (orR > 0 ? orCy - orR - 12 : this.height / 2) - (int) (age * 8);
                text(ctx, popText, tx, ty, Ui.alpha(0xFFFFFFFF, Math.max(8, a)));
            }
        }
    }

    // ---------- render ----------

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Settings s = Settings.get();
        mx = mouseX;
        my = mouseY;
        long now = System.currentTimeMillis();
        double dt = lastMs == 0 ? 0.016 : Math.min(0.1, (now - lastMs) / 1000.0);
        lastMs = now;
        double t = now / 1000.0;

        boolean down = mouseDown();
        leftDown = down;
        boolean yd = keyDown(GLFW.GLFW_KEY_Y);
        if (yd && !prevY && !typing()) {
            this.close();
            return;
        }
        prevY = yd;

        clicked = pendingClick;
        clickX = pendingX;
        clickY = pendingY;
        pendingClick = false;
        if (!down && !clicked) {
            dragId = null;
            if (dirty) {
                Settings.save();
                dirty = false;
            }
            if (perfDirty) {
                Perf.save();
                perfDirty = false;
            }
        }

        accent = s.accentColor();
        if (now < rainbowUntil) {
            accent = 0xFF000000 | MathHelper.hsvToRgb((now % 3000) / 3000f, 0.55f, 1f);
        }
        mand = s.uiStyle != 1;
        T = Theme.of(s.uiStyle);
        cText = mand ? T.text : 0xFFEDEDF5;
        cMuted = mand ? T.muted : 0xFF8B8BA3;

        ctx.fill(0, 0, this.width, this.height, mand ? 0x99000000 : 0xB0000000);

        int pw = Math.min(520, this.width - 16);
        int ph = Math.min(300, this.height - 16);
        int px = (this.width - pw) / 2;
        int py = (this.height - ph) / 2;
        int sw = 112;
        int top = mand ? 20 : 6;

        if (mand) {
            Ui.bevel(ctx, px, py, pw, ph, T.panel, T.light, T.dark, T.border);
            Fx.draw(ctx, T.fx, px + 2, py + 2, pw - 4, ph - 4, t, accent);
            if (s.decor) Ui.corner(ctx, px + 3, py + 3, 1, 1, accent, 8);
            if (s.decor) Ui.corner(ctx, px + pw - 3, py + 3, -1, 1, accent, 8);
            if (s.decor) Ui.corner(ctx, px + 3, py + ph - 4, 1, -1, accent, 8);
            if (s.decor) Ui.corner(ctx, px + pw - 3, py + ph - 4, -1, -1, accent, 8);
            text(ctx, PACK, px + (pw - tw(PACK)) / 2, py + 8, T.title);
            // close button
            int bx = px + pw - 26, by = py + 5;
            boolean hv = hov(bx, by, 16, 14);
            Ui.bevel(ctx, bx, by, 16, 14, hv ? T.btnH : T.btn, T.btnLt, T.dark, T.border);
            text(ctx, "x", bx + 8 - tw("x") / 2, by + 3, cText);
            if (clk(bx, by, 16, 14)) {
                this.close();
                return;
            }
            // sidebar well
            Ui.bevel(ctx, px + 6, py + top, sw, ph - top - 6, T.side, T.sideDk, T.sideLt, T.border);
        } else {
            Ui.rrect(ctx, px - 2, py - 2, pw + 4, ph + 4, 9, Ui.alpha(accent, 0x55));
            Ui.outlined(ctx, px, py, pw, ph, 7, BG, LINE);
            if (s.decor) Ui.corner(ctx, px + 3, py + 3, 1, 1, accent, 8);
            if (s.decor) Ui.corner(ctx, px + pw - 3, py + 3, -1, 1, accent, 8);
            if (s.decor) Ui.corner(ctx, px + 3, py + ph - 4, 1, -1, accent, 8);
            if (s.decor) Ui.corner(ctx, px + pw - 3, py + ph - 4, -1, -1, accent, 8);
            Ui.rrect(ctx, px + 6, py + 6, sw, ph - 12, 6, SIDE);
        }

        // logo + name
        logoX = px + 12;
        logoY = py + top + 5;
        Ui.logo(ctx, logoX, logoY, 6, accent);
        text(ctx, "Daz", logoX + 30, logoY + 3, valColor());
        text(ctx, "Client", logoX + 30, logoY + 14, cText);

        // groups
        int gTop = py + top + 38;
        for (int i = 0; i < GROUPS.length; i++) {
            int gx = px + 10, gy = gTop + i * 22, gw = sw - 8;
            boolean act = group == i;
            boolean hv = hov(gx, gy, gw, 20);
            if (mand) {
                Ui.bevel(ctx, gx, gy, gw, 20,
                        act ? T.slot : (hv ? T.tabH : T.tab),
                        act ? T.slotDk : T.tabLt,
                        act ? T.slotLt : T.tabDk, T.border);
                if (act) Ui.studFrame(ctx, gx, gy, gw, 20, accent);
                text(ctx, GROUPS[i], gx + 18, gy + 6, act ? 0xFFFFFFFF : T.title);
            } else {
                if (act) Ui.rrect(ctx, gx, gy, gw, 20, 5, Ui.alpha(accent, 0x30));
                else if (hv) Ui.rrect(ctx, gx, gy, gw, 20, 5, 0xFF16161F);
                text(ctx, GROUPS[i], gx + 18, gy + 6, act ? cText : cMuted);
            }
            Ui.icon(ctx, i, gx + 5, gy + 6, act ? accent : Ui.alpha(accent, 0x99));
            if (clk(gx, gy, gw, 20)) group = i;
        }

        // spinning ornament, sized to the free space under the groups
        int groupsBottom = gTop + (GROUPS.length - 1) * 22 + 20;
        int freeTop = groupsBottom + 6;
        int freeBottom = py + ph - 6 - 6;
        int freeH = freeBottom - freeTop;
        orR = Math.min(freeH / 2, (sw - 10) / 2);
        double boost = Math.max(0, (boostUntil - now) / 1800.0);
        ornPhase += dt * (1 + 4 * boost);
        if (orR >= 12 && s.decor) {
            orCx = px + 6 + sw / 2;
            orCy = freeTop + freeH / 2;
            ornament(ctx, orCx, orCy, orR, ornPhase, accent);
        } else {
            orR = 0;
        }

        // content area
        cx = px + sw + 20;
        cy = py + top + (mand ? 4 : 8);
        cw = pw - sw - 32;
        ch = ph - (cy - py) - 14;
        colW = (cw - 8) / 2;

        text(ctx, GROUPS[group].toUpperCase(), cx, cy, mand ? T.title : cText);
        if (mand) {
            ctx.fill(cx, cy + 11, cx + cw, cy + 12, T.dark);
            ctx.fill(cx, cy + 12, cx + cw, cy + 13, T.light);
        } else {
            Ui.hfade(ctx, cx, cy + 11, cw, 1, accent, 255, 0);
        }
        if (s.decor) Ui.diamondDot(ctx, cx + cw - 5, cy + 11, accent);

        boolean editorShown = group == MARKS_TAB && sub[group] == 0 && editMark != null;
        if (!editorShown && nameField != null) nameField.visible = false;

        // sub-page bar
        if (!editorShown) {
            String[] names = SUBS[group];
            int n = names.length;
            int bw = (cw - (n - 1) * 4) / n;
            for (int i = 0; i < n; i++) {
                if (button(ctx, names[i], cx + i * (bw + 4), cy + 17, bw, 18, sub[group] == i)) sub[group] = i;
            }
        }

        String key = GROUPS[group] + "/" + SUBS[group][sub[group]];
        if (searchField != null) searchField.visible = false;
        switch (key) {
            case "Scan/Chunk": pageChunk(ctx, s); break;
            case "Scan/Border": pageBorder(ctx, s); break;
            case "Scan/Blocks": pageBlocks(ctx, s); break;
            case "Scan/History": pageScanHistory(ctx, s); break;
            case "Panel/Layout": pageLayout(ctx, s); break;
            case "Panel/Players": pagePlayers(ctx, s); break;
            case "Panel/Info": pageInfo(ctx, s); break;
            case "Marks/Waypoints": pageWaypoints(ctx, s); break;
            case "Marks/Hologram": pageHologram(ctx, s); break;
            case "Chat/Settings": pageChatSettings(ctx, s); break;
            case "Chat/History": pageChatHistory(ctx, s); break;
            case "More/Keys": pageKeys(ctx); break;
            case "Client/Boost": pageBoost(ctx, s); break;
            case "Client/Swap": pageSwap(ctx, s); break;
            case "Client/HUD": pageHud(ctx, s); break;
            case "Client/Crosshair": pageCrosshair(ctx, s); break;
            case "Client/Perf": pagePerf(ctx, s); break;
            case "Client/Extras": pageExtras(ctx, s); break;
            case "Manage/Installed": pageInstalled(ctx); break;
            case "Manage/Mods": pageBrowse(ctx, "mod"); break;
            case "Manage/Packs": pageBrowse(ctx, "pack"); break;
            case "Manage/Skin": pageSkin(ctx); break;
            case "Manage/Capes": pageCapes(ctx); break;
            default: pageAbout(ctx); break;
        }

        if (!key.equals(lastKey)) {
            lastKey = key;
            pageT = now;
        }
        double pa = Math.max(0, 1 - (now - pageT) / 220.0);
        if (pa > 0) {
            ctx.fill(cx - 6, cy + 14, cx + cw + 6, cy + ch + 2, Ui.alpha(mand ? T.panel : 0xFF101018, (int) (235 * pa)));
        }

        String foot = "Y / Esc to close";
        text(ctx, foot, px + pw - 10 - tw(foot), py + ph - 13, cMuted);

        // easter egg: tap the flower or the logo
        if (clicked) {
            if (orR > 0 && Math.hypot(clickX - orCx, clickY - orCy) <= orR + 3) {
                eggOrb++;
                boostUntil = now + 1800;
                burst(orCx, orCy, 16, false, now);
                if (eggOrb % 7 == 0) {
                    rainbowUntil = now + 8000;
                    pop("Daz was here!", now);
                    burst(orCx, orCy, 40, true, now);
                }
            } else if (hit(clickX, clickY, logoX, logoY, 24, 24)) {
                eggLogo++;
                burst(logoX + 12, logoY + 12, 30, true, now);
                if (eggLogo % 5 == 0) pop("Thanks for playing!", now);
            }
        }
        eggUpdateDraw(ctx, dt, now);
    }

    // ---------- pages ----------

    private void pageChunk(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.autoScan = toggle(c, "Auto scan", s.autoScan, x, y, w, 0));
        l.add((c, x, y, w) -> s.scanTarget = cycle(c, "Scan target", Settings.SCAN_TARGETS, s.scanTarget, x, y, w));
        l.add((c, x, y, w) -> s.autoTicks = Math.round(slider(c, "autoticks", "Auto scan rate", s.autoTicks + " ticks",
                s.autoTicks, 5, 60, x, y, w)));
        drawControls(ctx, l,
                "Auto scan checks one chunk and updates the panel for you.",
                "Looking at = chunk under your crosshair. Standing in = your chunk.",
                "G scans once with the same target. K clears everything.");
    }

    private void pageBorder(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.borders = toggle(c, "Show border", s.borders, x, y, w, 0));
        l.add((c, x, y, w) -> s.style = cycle(c, "Style", Settings.STYLES, s.style, x, y, w));
        l.add((c, x, y, w) -> s.gap = snap(slider(c, "gap", "Particle gap", String.format("%.2f", s.gap), s.gap,
                0.2f, 2.0f, x, y, w), 0.05f));
        l.add((c, x, y, w) -> s.pulseTicks = Math.round(slider(c, "pulse", "Update rate", s.pulseTicks + " ticks",
                s.pulseTicks, 2, 20, x, y, w)));
        l.add((c, x, y, w) -> s.heightRange = Math.round(slider(c, "height", "Height range", "+-" + s.heightRange,
                s.heightRange, 16, 128, x, y, w) / 4f) * 4);
        l.add((c, x, y, w) -> s.maxChunks = Math.round(slider(c, "dist", "Max distance", s.maxChunks + " chunks",
                s.maxChunks, 2, 16, x, y, w)));
        l.add((c, x, y, w) -> s.rings = toggle(c, "Ring lines", s.rings, x, y, w, 0));
        l.add((c, x, y, w) -> s.ringEvery = Math.round(slider(c, "ring", "Ring spacing", s.ringEvery + " blocks",
                s.ringEvery, 4, 32, x, y, w) / 2f) * 2);
        l.add((c, x, y, w) -> s.dustSize = snap(slider(c, "dust", "Dust size", String.format("%.1f", s.dustSize),
                s.dustSize, 1f, 4f, x, y, w), 0.5f));
        l.add((c, x, y, w) -> s.showClean = toggle(c, "Clean chunk border", s.showClean, x, y, w, 0));
        drawControls(ctx, l);
    }

    private void pageBlocks(DrawContext ctx, Settings s) {
        // legend
        int lx = cx + cw;
        String l2 = "in structures";
        String l1 = "never natural";
        lx -= tw(l2);
        text(ctx, l2, lx, cy + 2, cMuted);
        lx -= 10;
        Ui.rrect(ctx, lx, cy + 5, 4, 4, 2, AMBER);
        lx -= tw(l1) + 6;
        text(ctx, l1, lx, cy + 2, cMuted);
        lx -= 10;
        Ui.rrect(ctx, lx, cy + 5, 4, 4, 2, GREEN);

        int rows = Math.max(1, (ch - 42 - 28) / 28);
        int per = rows * 2;
        int total = Targets.ALL.size();
        int pageCount = (total + per - 1) / per;
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));

        for (int k = 0; k < per; k++) {
            int idx = pages[pi] * per + k;
            if (idx >= total) break;
            Targets.Entry e = Targets.ALL.get(idx);
            boolean on = Targets.isOn(e);
            boolean nv = toggle(ctx, e.label, on, cellX(k), cellY(k), colW, e.defaultOn ? GREEN : AMBER);
            if (nv != on) {
                s.blocks.put(e.label, nv);
                Targets.rebuild();
            }
        }

        int by = cy + ch - 22;
        pages[pi] = pager(ctx, pages[pi], pageCount, cx, by);

        int bw = 70;
        if (button(ctx, "Defaults", cx + cw - bw, by, bw, 20, true)) {
            s.blocks.clear();
            Targets.rebuild();
            dirty = true;
        }
        if (button(ctx, "All off", cx + cw - bw * 2 - 6, by, bw, 20, false)) {
            for (Targets.Entry e : Targets.ALL) s.blocks.put(e.label, false);
            Targets.rebuild();
            dirty = true;
        }
    }

    private void pageScanHistory(DrawContext ctx, Settings s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Data d = Data.get();
        String server = mc.world != null ? Marks.server(mc) : "local";
        s.history = toggle(ctx, "Save history", s.history, cellX(0), cellY(0), colW, 0);
        if (button(ctx, "Clear history", cellX(1), cellY(1), colW, 24, false)) {
            d.history.removeIf(h -> h.server.equals(server));
            Data.save();
        }

        List<Data.Hist> refs = new ArrayList<>();
        for (Data.Hist h : d.history) if (h.server.equals(server)) refs.add(h);

        int listTop = cellY(2);
        int fit = listRows(listTop);
        int pageCount = Math.max(1, (refs.size() + fit - 1) / fit);
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));

        Data.Hist del = null;
        for (int k = 0; k < fit; k++) {
            int idx = pages[pi] * fit + k;
            if (idx >= refs.size()) break;
            Data.Hist h = refs.get(idx);
            String label = h.x + " " + h.y + " " + h.z + "  " + h.summary;
            if (listRow(ctx, cx, listTop + k * 22, cw, label, "x")) del = h;
        }
        if (del != null) {
            d.history.remove(del);
            Data.save();
        }
        if (refs.isEmpty()) text(ctx, "Nothing saved yet. Scans that find blocks appear here.", cx, listTop + 6, cMuted);
        pages[pi] = pager(ctx, pages[pi], pageCount, cx, cy + ch - 22);
    }

    private void pageLayout(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.panel = toggle(c, "Show scan results", s.panel, x, y, w, 0));
        l.add((c, x, y, w) -> s.showCoords = toggle(c, "Show coordinates", s.showCoords, x, y, w, 0));
        l.add((c, x, y, w) -> s.panelPos = cycle(c, "Panel position", Settings.POSITIONS, s.panelPos, x, y, w));
        l.add((c, x, y, w) -> s.accent = cycle(c, "Accent color", Settings.ACCENT_NAMES, s.accent, x, y, w));
        l.add((c, x, y, w) -> s.uiStyle = cycle(c, "UI style", Settings.UI_STYLES, s.uiStyle, x, y, w));
        l.add((c, x, y, w) -> s.decor = toggle(c, "Decorations", s.decor, x, y, w, 0));
        drawControls(ctx, l,
                "One panel holds scan, info and players.",
                "Pick a UI style with animated art: Cosmos, Matrix, Ember, Synth, Sakura.");
    }

    private void pagePlayers(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.radar = toggle(c, "Show players", s.radar, x, y, w, 0));
        l.add((c, x, y, w) -> s.radarChunks = Math.round(slider(c, "rchunks", "Range", s.radarChunks + " chunks",
                s.radarChunks, 2, 16, x, y, w)));
        l.add((c, x, y, w) -> s.radarMax = Math.round(slider(c, "rmax", "Max players", String.valueOf(s.radarMax),
                s.radarMax, 3, 10, x, y, w)));
        drawControls(ctx, l,
                "Lists players your game has loaded, with coordinates.",
                "Invisible players are not shown.");
    }

    private void pageInfo(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.info = toggle(c, "Show my info", s.info, x, y, w, 0));
        l.add((c, x, y, w) -> s.infoCoords = toggle(c, "Coordinates", s.infoCoords, x, y, w, 0));
        l.add((c, x, y, w) -> s.infoFacing = toggle(c, "Facing", s.infoFacing, x, y, w, 0));
        l.add((c, x, y, w) -> s.infoBiome = toggle(c, "Biome", s.infoBiome, x, y, w, 0));
        l.add((c, x, y, w) -> s.infoLight = toggle(c, "Light level", s.infoLight, x, y, w, 0));
        drawControls(ctx, l, "Light 7 or lower is shown in red (mobs can spawn).");
    }

    private void pageHologram(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.marksDeath = toggle(c, "Death hologram", s.marksDeath, x, y, w, 0));
        l.add((c, x, y, w) -> s.marksWp = toggle(c, "Waypoint holograms", s.marksWp, x, y, w, 0));
        l.add((c, x, y, w) -> {
            int rng = Math.round(slider(c, "mrange", "Show within",
                    s.marksRange >= 5000 ? "any distance" : s.marksRange + " blocks", s.marksRange, 100, 5000,
                    x, y, w) / 100f) * 100;
            s.marksRange = Math.max(100, Math.min(5000, rng));
        });
        l.add((c, x, y, w) -> s.marksSize = Math.round(slider(c, "msize", "Hologram size",
                String.valueOf(s.marksSize), s.marksSize, 1, 3, x, y, w)));
        l.add((c, x, y, w) -> s.marksAnim = toggle(c, "Animation", s.marksAnim, x, y, w, 0));
        l.add((c, x, y, w) -> s.marksSmart = toggle(c, "Names only when near", s.marksSmart, x, y, w, 0));
        l.add((c, x, y, w) -> s.marksAsk = toggle(c, "Name it when I press B", s.marksAsk, x, y, w, 0));
        drawControls(ctx, l, "Holograms show through walls, with the icon and name you pick.");
    }

    /** One waypoint row: icon, name, coordinates, Edit and delete buttons. 0 = nothing, 1 = edit, 2 = delete. */
    private int markRow(DrawContext c, int x, int y, int w, Data.Mark m, boolean death) {
        card(c, x, y, w, 22, false);
        c.drawItem(Icons.stack(m, death), x + 4, y + 3);
        String edit = "Edit", del = "x";
        int bw1 = tw(edit) + 10, bw2 = tw(del) + 10;
        int bx2 = x + w - bw2 - 3, bx1 = bx2 - bw1 - 3;
        String coords = m.x + " " + m.y + " " + m.z;
        int cwid = tw(coords);
        int nameMax = bx1 - (x + 26) - cwid - 12;
        text(c, fit(m.name, Math.max(20, nameMax)), x + 26, y + 7, death ? 0xFFFF7A7A : cText);
        text(c, coords, bx1 - cwid - 6, y + 7, cMuted);
        int act = 0;
        if (smallBtn(c, edit, bx1, y + 3, bw1)) act = 1;
        if (smallBtn(c, del, bx2, y + 3, bw2)) act = 2;
        return act;
    }

    private void pageWaypoints(DrawContext ctx, Settings s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (editMark != null) {
            drawMarkEditor(ctx);
            return;
        }
        Data d = Data.get();
        String server = mc.world != null ? Marks.server(mc) : "local";
        List<Data.Mark> refs = new ArrayList<>();
        if (d.death != null && d.death.server.equals(server)) refs.add(d.death);
        for (Data.Mark m : d.marks) if (m.server.equals(server)) refs.add(m);

        int listTop = cy + 42;
        int fit = Math.max(1, (cy + ch - 28 - listTop) / 24);
        int pageCount = Math.max(1, (refs.size() + fit - 1) / fit);
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));

        Data.Mark editReq = null, delReq = null;
        for (int k = 0; k < fit; k++) {
            int idx = pages[pi] * fit + k;
            if (idx >= refs.size()) break;
            Data.Mark m = refs.get(idx);
            int act = markRow(ctx, cx, listTop + k * 24, cw, m, m == d.death);
            if (act == 1) editReq = m;
            if (act == 2) delReq = m;
        }
        if (refs.isEmpty()) {
            text(ctx, "No waypoints yet. Press B in game, or use the button below.", cx, listTop + 6, cMuted);
        }

        int by = cy + ch - 22;
        pages[pi] = pager(ctx, pages[pi], pageCount, cx, by);
        if (button(ctx, "+ Add here", cx + cw - 90, by, 90, 20, true)) {
            Data.Mark nm = Marks.addWaypoint(mc);
            if (nm != null) editReq = nm;
        }

        if (delReq != null) {
            if (delReq == d.death) d.death = null;
            else d.marks.remove(delReq);
            Data.save();
        }
        if (editReq != null) startEdit(editReq);
    }

    private void drawMarkEditor(DrawContext ctx) {
        Data.Mark m = editMark;
        Data d = Data.get();
        boolean death = m == d.death;

        text(ctx, "Name", cx, cy + 18, cMuted);
        int fy = cy + 28;
        card(ctx, cx, fy, cw, 22, false);
        nameField.setPosition(cx + 8, fy + 7);
        nameField.setWidth(cw - 16);
        nameField.setEditableColor(cText);
        nameField.visible = true;
        nameField.render(ctx, mx, my, 0f);
        editBuffer = nameField.getText();

        // quick names (handy when there is no keyboard)
        String[] presets = {"Base", "Home", "Farm", "Mine", "Portal", "Stash", "Spawn", "Shop"};
        int py2 = fy + 28;
        int bx = cx;
        for (String p : presets) {
            int bw = tw(p) + 12;
            if (bx + bw > cx + cw) {
                bx = cx;
                py2 += 22;
            }
            if (button(ctx, p, bx, py2, bw, 18, false)) nameField.setText(p);
            bx += bw + 4;
        }

        // icon picker
        int iy = py2 + 26;
        text(ctx, "Icon", cx, iy, cMuted);
        int gy = iy + 11;
        int perRow = Math.max(4, cw / 22);
        String cur = Icons.idOf(m, death);
        for (int k = 0; k < Icons.ALL.size(); k++) {
            int ix = cx + (k % perRow) * 22, iyy = gy + (k / perRow) * 22;
            Icons.Icon ic = Icons.ALL.get(k);
            boolean sel = ic.id.equals(cur);
            boolean hv = hov(ix, iyy, 20, 20);
            if (sel && !mand) Ui.rrect(ctx, ix - 1, iyy - 1, 22, 22, 5, accent);
            card(ctx, ix, iyy, 20, 20, hv);
            if (sel && mand) Ui.studFrame(ctx, ix, iyy, 20, 20, accent);
            ctx.drawItem(ic.stack, ix + 2, iyy + 2);
            if (clk(ix, iyy, 20, 20)) {
                m.icon = ic.id;
                Data.save();
            }
        }

        int by = cy + ch - 22;
        if (button(ctx, "OK", cx, by, 70, 20, true)) {
            endEdit(true);
            return;
        }
        if (button(ctx, "Cancel", cx + 76, by, 70, 20, false)) {
            endEdit(false);
            return;
        }
        if (button(ctx, "Delete", cx + cw - 70, by, 70, 20, false)) {
            if (death) d.death = null;
            else d.marks.remove(m);
            Data.save();
            endEdit(false);
        }
    }

    private void pageChatSettings(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.chatFilter = toggle(c, "Chat filter", s.chatFilter, x, y, w, 0));
        l.add((c, x, y, w) -> s.chatAds = toggle(c, "Block ad words", s.chatAds, x, y, w, 0));
        l.add((c, x, y, w) -> {
            card(c, x, y, w, 24, false);
            text(c, "Hidden so far: " + ChatFilter.hidden, x + 8, y + 8, cText);
        });
        l.add((c, x, y, w) -> {
            if (button(c, "Clear blocked list", x, y, w, 24, false)) {
                s.chatCustom.clear();
                dirty = true;
            }
        });
        drawControls(ctx, l,
                "The filter hides spammy server messages (store, vote, ads).",
                "Block more from the History page: tap + block on a message.");
    }

    private void pageChatHistory(DrawContext ctx, Settings s) {
        if (button(ctx, chatMode == 0 ? "Showing: recent" : "Showing: blocked", cellX(0), cellY(0), colW, 24, true)) {
            chatMode = 1 - chatMode;
            pages[pageIdx()] = 0;
        }
        card(ctx, cellX(1), cellY(1), colW, 24, false);
        text(ctx, "Blocked words: " + s.chatCustom.size(), cellX(1) + 8, cellY(1) + 8, cText);

        List<String> list = chatMode == 0 ? new ArrayList<>(ChatFilter.recent) : new ArrayList<>(s.chatCustom);
        int listTop = cellY(2);
        int fit = listRows(listTop);
        int pageCount = Math.max(1, (list.size() + fit - 1) / fit);
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));

        String act = null;
        for (int k = 0; k < fit; k++) {
            int idx = pages[pi] * fit + k;
            if (idx >= list.size()) break;
            String msg = list.get(idx);
            if (listRow(ctx, cx, listTop + k * 22, cw, msg, chatMode == 0 ? "+ block" : "x")) act = msg;
        }
        if (act != null) {
            if (chatMode == 0) {
                String key = ChatFilter.keyFor(act);
                if (!s.chatCustom.contains(key)) s.chatCustom.add(key);
            } else {
                s.chatCustom.remove(act);
            }
            dirty = true;
        }
        if (list.isEmpty()) {
            text(ctx, chatMode == 0 ? "No messages yet. Server messages show up here." : "Nothing blocked yet.",
                    cx, listTop + 6, cMuted);
        }
        pages[pi] = pager(ctx, pages[pi], pageCount, cx, cy + ch - 22);
    }

    private void pageKeys(DrawContext ctx) {
        String[][] rows = {
                {"G", "Scan once (target is set in Scan > Chunk)"},
                {"K", "Clear all borders and the scan result"},
                {"Y", "Open / close this menu"},
                {"B", "Save a waypoint where you stand, then name it"},
                {"C", "Hold to zoom (Client > Extras)"}
        };
        int y = cy + 44;
        for (String[] r : rows) {
            if (mand) Ui.bevel(ctx, cx, y, 22, 18, T.slot, T.slotDk, T.slotLt, T.border);
            else Ui.rrect(ctx, cx, y, 22, 18, 4, Ui.alpha(accent, 0x40));
            text(ctx, r[0], cx + 11 - tw(r[0]) / 2, y + 5, valColor());
            text(ctx, r[1], cx + 32, y + 5, cText);
            y += 24;
        }
        text(ctx, "Rebind keys in Options > Controls > Key Binds.", cx, y + 4, cMuted);
        text(ctx, "Settings: config/chunkinfo.json. Saved marks: chunkinfo-data.json.", cx, y + 16, cMuted);
    }

    private void pageAbout(DrawContext ctx) {
        int y = cy + 46;
        Ui.logo(ctx, cx, y, 6, accent);
        text(ctx, PACK, cx + 32, y + 3, valColor());
        text(ctx, "Minecraft 1.21.11  |  Fabric", cx + 32, y + 15, cMuted);
        y += 38;
        String[] lines = {
                "HUD widgets, custom crosshair, zoom",
                "Performance presets for smooth PvP",
                "Hologram waypoints you can name",
                "Mod, resource pack and skin manager",
                "Chunk scanner, chat filter, animated themes"
        };
        for (String ln : lines) {
            Ui.diamondDot(ctx, cx + 3, y + 4, accent);
            text(ctx, ln, cx + 12, y, cText);
            y += 12;
        }
        text(ctx, "Made by Dzakki", cx, y + 8, cMuted);
        text(ctx, "Tip: tap the logo or the spinning flower.", cx, y + 20, cMuted);
    }

    // ---------- client pages ----------

    private void pageHud(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.wFps = toggle(c, "FPS counter", s.wFps, x, y, w, 0));
        l.add((c, x, y, w) -> s.wCps = toggle(c, "CPS counter", s.wCps, x, y, w, 0));
        l.add((c, x, y, w) -> s.wPing = toggle(c, "Ping", s.wPing, x, y, w, 0));
        l.add((c, x, y, w) -> s.wCoords = toggle(c, "Coordinates", s.wCoords, x, y, w, 0));
        l.add((c, x, y, w) -> s.wKeys = toggle(c, "Keystrokes", s.wKeys, x, y, w, 0));
        l.add((c, x, y, w) -> s.wClock = toggle(c, "Clock", s.wClock, x, y, w, 0));
        l.add((c, x, y, w) -> s.wSpeed = toggle(c, "Speed (blocks/s)", s.wSpeed, x, y, w, 0));
        l.add((c, x, y, w) -> s.wFpsGraph = toggle(c, "FPS graph", s.wFpsGraph, x, y, w, 0));
        l.add((c, x, y, w) -> s.widgetAlpha = Math.round(slider(c, "walpha", "Widget opacity",
                s.widgetAlpha + "%", s.widgetAlpha, 20, 100, x, y, w) / 5f) * 5);
        l.add((c, x, y, w) -> s.wPos = cycle(c, "Widget corner", Settings.CORNERS, s.wPos, x, y, w));
        l.add((c, x, y, w) -> s.watermark = toggle(c, "Watermark", s.watermark, x, y, w, 0));
        l.add((c, x, y, w) -> s.watermarkPos = cycle(c, "Watermark corner", Settings.CORNERS, s.watermarkPos, x, y, w));
        l.add((c, x, y, w) -> s.watermarkAlpha = Math.round(slider(c, "wmalpha", "Watermark opacity",
                s.watermarkAlpha + "%", s.watermarkAlpha, 20, 100, x, y, w) / 5f) * 5);
        drawControls(ctx, l, "Small boxes that follow your UI style and accent color.",
                "The watermark is a tiny logo and name. It stays faint on purpose.");
    }

    private void pageCrosshair(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.crosshair = toggle(c, "Custom crosshair", s.crosshair, x, y, w, 0));
        l.add((c, x, y, w) -> s.chStyle = cycle(c, "Style", Settings.CH_STYLES, s.chStyle, x, y, w));
        l.add((c, x, y, w) -> s.chSize = Math.round(slider(c, "chsize", "Size", String.valueOf(s.chSize),
                s.chSize, 2, 20, x, y, w)));
        l.add((c, x, y, w) -> s.chGap = Math.round(slider(c, "chgap", "Gap", String.valueOf(s.chGap),
                s.chGap, 0, 12, x, y, w)));
        l.add((c, x, y, w) -> s.chThick = Math.round(slider(c, "chthick", "Thickness", String.valueOf(s.chThick),
                s.chThick, 1, 4, x, y, w)));
        l.add((c, x, y, w) -> s.chOpacity = Math.round(slider(c, "chop", "Opacity", s.chOpacity + "%",
                s.chOpacity, 20, 100, x, y, w) / 5f) * 5);
        l.add((c, x, y, w) -> s.chColorMode = cycle(c, "Color", Settings.CH_COLORS, s.chColorMode, x, y, w));
        l.add((c, x, y, w) -> s.chHue = Math.round(slider(c, "chhue", "Custom hue", String.valueOf(s.chHue),
                s.chHue, 0, 360, x, y, w) / 5f) * 5);
        l.add((c, x, y, w) -> s.chOutline = toggle(c, "Outline", s.chOutline, x, y, w, 0));
        l.add((c, x, y, w) -> s.chDot = toggle(c, "Center dot", s.chDot, x, y, w, 0));
        l.add((c, x, y, w) -> s.chDynamic = toggle(c, "Widen when moving", s.chDynamic, x, y, w, 0));
        l.add((c, x, y, w) -> s.chCooldown = toggle(c, "Attack cooldown bar", s.chCooldown, x, y, w, 0));
        l.add((c, x, y, w) -> {
            card(c, x, y, w, 24, false);
            text(c, "Preview", x + 8, y + 8, cMuted);
            ClientHud.drawCrosshairAt(c, x + w - 24, y + 12, 0, 7);
        });
        drawControls(ctx, l);
    }

    private void pagePerf(DrawContext ctx, Settings s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> {
            if (button(c, "Preset: Fast (PvP)", x, y, w, 24, true)) {
                Perf.preset(mc, 0);
            }
        });
        l.add((c, x, y, w) -> {
            if (button(c, "Preset: Balanced", x, y, w, 24, false)) {
                Perf.preset(mc, 1);
            }
        });
        l.add((c, x, y, w) -> {
            if (button(c, "Preset: Quality", x, y, w, 24, false)) {
                Perf.preset(mc, 2);
            }
        });
        l.add((c, x, y, w) -> {
            if (button(c, "Preset: Potato", x, y, w, 24, false)) Perf.preset(mc, 3);
        });
        l.add((c, x, y, w) -> perfSlider(c, mc, "view", "Render distance", " chunks", 2, 32, x, y, w));
        l.add((c, x, y, w) -> perfSlider(c, mc, "sim", "Simulation distance", " chunks", 5, 32, x, y, w));
        l.add((c, x, y, w) -> perfSlider(c, mc, "fps", "Max FPS", "", 10, 260, x, y, w));
        l.add((c, x, y, w) -> perfSlider(c, mc, "entity", "Entity distance", "%", 50, 500, x, y, w));
        l.add((c, x, y, w) -> perfSlider(c, mc, "fovfx", "FOV effects", "%", 0, 100, x, y, w));
        l.add((c, x, y, w) -> perfSlider(c, mc, "blend", "Biome blend", "", 0, 7, x, y, w));
        l.add((c, x, y, w) -> perfCycle(c, mc, "clouds", "Clouds", new String[]{"Off", "Fast", "Fancy"}, x, y, w));
        l.add((c, x, y, w) -> perfCycle(c, mc, "particles", "Particles", new String[]{"All", "Decreased", "Minimal"}, x, y, w));
        l.add((c, x, y, w) -> perfToggle(c, mc, "shadows", "Entity shadows", x, y, w));
        l.add((c, x, y, w) -> perfToggle(c, mc, "bob", "View bobbing", x, y, w));
        l.add((c, x, y, w) -> perfToggle(c, mc, "sprint", "Toggle sprint", x, y, w));
        l.add((c, x, y, w) -> perfToggle(c, mc, "sneak", "Toggle sneak", x, y, w));
        drawControls(ctx, l, "These are normal game options. They are saved to options.txt.");
    }

    private void perfSlider(DrawContext c, MinecraftClient mc, String key, String label, String unit,
                            int min, int max, int x, int y, int w) {
        int v = Perf.getInt(mc, key);
        String shown = key.equals("fps") && v >= 260 ? "Unlimited" : v + unit;
        int nv = Math.round(slider(c, "p_" + key, label, shown, v, min, max, x, y, w));
        if (nv != v) {
            Perf.setInt(mc, key, nv);
            perfDirty = true;
        }
    }

    private void perfCycle(DrawContext c, MinecraftClient mc, String key, String label, String[] opts,
                           int x, int y, int w) {
        int v = Perf.getInt(mc, key);
        int nv = cycle(c, label, opts, v, x, y, w);
        if (nv != v) {
            Perf.setInt(mc, key, nv);
            perfDirty = true;
        }
    }

    private void perfToggle(DrawContext c, MinecraftClient mc, String key, String label, int x, int y, int w) {
        boolean v = Perf.getBool(mc, key);
        boolean nv = toggle(c, label, v, x, y, w, 0);
        if (nv != v) {
            Perf.setBool(mc, key, nv);
            perfDirty = true;
        }
    }

    private void pageExtras(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.zoom = toggle(c, "Zoom (hold C)", s.zoom, x, y, w, 0));
        l.add((c, x, y, w) -> s.zoomFov = Math.round(slider(c, "zoomfov", "Zoom FOV", String.valueOf(s.zoomFov),
                s.zoomFov, 30, 70, x, y, w)));
        l.add((c, x, y, w) -> s.loadingScreen = toggle(c, "Loading screen", s.loadingScreen, x, y, w, 0));
        l.add((c, x, y, w) -> s.splashScreen = toggle(c, "Game start screen", s.splashScreen, x, y, w, 0));
        l.add((c, x, y, w) -> s.styleVanilla = toggle(c, "Style option screens", s.styleVanilla, x, y, w, 0));
        l.add((c, x, y, w) -> s.menuButton = toggle(c, "Menu button", s.menuButton, x, y, w, 0));
        l.add((c, x, y, w) -> s.clientTitle = toggle(c, "Client main menu", s.clientTitle, x, y, w, 0));
        drawControls(ctx, l,
                "Zoom lowers FOV and mouse speed while you hold the key.",
                "Loading screens use your UI style and accent color.",
                "Style option screens themes Options, Controls, Pause and Resource Packs.",
                "Menu button adds a Daz Client button to the title, pause and options screens.");
    }

    // ---------- manage pages ----------

    private void pageInstalled(DrawContext ctx) {
        long now = System.currentTimeMillis();
        if (now - instAt > 2000) {
            instCache = ModManager.listInstalled();
            instAt = now;
        }
        List<ModManager.Entry> list = instCache;
        int listTop = cy + 42;
        int fit = Math.max(1, (cy + ch - 40 - listTop) / 24);
        int pageCount = Math.max(1, (list.size() + fit - 1) / fit);
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));

        for (int k = 0; k < fit; k++) {
            int idx = pages[pi] * fit + k;
            if (idx >= list.size()) break;
            ModManager.Entry e = list.get(idx);
            int y = listTop + k * 24;
            card(ctx, cx, y, cw, 22, false);
            text(ctx, e.kind.equals("mod") ? "MOD" : "PACK", cx + 6, y + 7, valColor());
            String sz = e.size > 0 ? (e.size / 1024) + " KB" : "";
            int bw = tw("Delete") + 10;
            int nameX = cx + 40;
            int right = cx + cw - bw - 8;
            if (e.locked) {
                text(ctx, "this client", cx + cw - 8 - tw("this client"), y + 7, cMuted);
                right = cx + cw - tw("this client") - 14;
            } else {
                boolean pending = confirmName.equals(e.path.toString()) && now < confirmUntil;
                if (smallBtn(ctx, pending ? "Sure?" : "Delete", cx + cw - bw - 3, y + 3, bw)) {
                    if (pending) {
                        ModManager.delete(e);
                        instAt = 0;
                        confirmName = "";
                    } else {
                        confirmName = e.path.toString();
                        confirmUntil = now + 3000;
                    }
                }
            }
            if (!sz.isEmpty()) {
                text(ctx, sz, right - tw(sz) - 4, y + 7, cMuted);
                right -= tw(sz) + 10;
            }
            text(ctx, fit(e.name, right - nameX), nameX, y + 7, cText);
        }
        if (list.isEmpty()) text(ctx, "No mods or resource packs found.", cx, listTop + 6, cMuted);
        String st = ModManager.status;
        if (!st.isEmpty()) text(ctx, fit(st, cw), cx, cy + ch - 34, cMuted);
        pages[pi] = pager(ctx, pages[pi], pageCount, cx, cy + ch - 22);
    }

    private void startSearch(String type) {
        String q = searchField.getText();
        browseNote = "Searching...";
        ModManager.async(() -> {
            try {
                List<ModManager.Result> r = ModManager.search(q, type);
                results = r;
                browseNote = r.isEmpty() ? "No results for this Minecraft version." : "";
            } catch (Exception e) {
                browseNote = "Search failed: " + e.getMessage();
            }
        });
    }

    private static String shortNum(int n) {
        if (n >= 1_000_000) return String.format("%.1fM", n / 1_000_000.0);
        if (n >= 1000) return (n / 1000) + "k";
        return String.valueOf(n);
    }

    private void searchBar(DrawContext ctx, int fy, int btnW, String hint) {
        card(ctx, cx, fy, cw - btnW - 6, 22, false);
        searchField.setPosition(cx + 8, fy + 7);
        searchField.setWidth(cw - btnW - 6 - 16);
        searchField.setEditableColor(cText);
        searchField.visible = true;
        searchField.render(ctx, mx, my, 0f);
        if (searchField.getText().isEmpty() && !searchField.isFocused()) text(ctx, hint, cx + 8, fy + 7, cMuted);
    }

    private void pageBrowse(DrawContext ctx, String type) {
        int fy = cy + 42, sbw = 70;
        searchBar(ctx, fy, sbw, type.equals("mod") ? "Search Modrinth mods..." : "Search resource packs...");
        if (button(ctx, "Search", cx + cw - sbw, fy, sbw, 22, true)) startSearch(type);
        if (!type.equals(lastBrowse)) {
            lastBrowse = type;
            startSearch(type);
        }

        List<ModManager.Result> list = results;
        int listTop = fy + 28;
        int fit = Math.max(1, (cy + ch - 34 - listTop) / 24);
        int pageCount = Math.max(1, (list.size() + fit - 1) / fit);
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));

        for (int k = 0; k < fit; k++) {
            int idx = pages[pi] * fit + k;
            if (idx >= list.size()) break;
            ModManager.Result r = list.get(idx);
            int y = listTop + k * 24;
            card(ctx, cx, y, cw, 22, false);
            String btn = ModManager.busy ? "..." : "Install";
            int bw = tw("Install") + 10;
            String dl = shortNum(r.downloads);
            int right = cx + cw - bw - 8;
            text(ctx, dl, right - tw(dl), y + 7, cMuted);
            text(ctx, fit(r.title + "  by " + r.author, right - tw(dl) - 14 - (cx + 8)), cx + 8, y + 7, cText);
            if (smallBtn(ctx, btn, cx + cw - bw - 3, y + 3, bw) && !ModManager.busy) {
                String id = r.id, title = r.title;
                ModManager.async(() -> ModManager.install(id, title, type));
            }
        }
        String note = !browseNote.isEmpty() ? browseNote : ModManager.status;
        if (!note.isEmpty()) text(ctx, fit(note, cw), cx, cy + ch - 34, cMuted);
        if (pageCount > 1 || !list.isEmpty()) pages[pi] = pager(ctx, pages[pi], pageCount, cx, cy + ch - 22);
    }

    private void pageSkin(DrawContext ctx) {
        long now = System.currentTimeMillis();
        int fy = cy + 42, sbw = 70;
        searchBar(ctx, fy, sbw, "Username to copy a skin from...");
        if (button(ctx, "Fetch", cx + cw - sbw, fy, sbw, 22, true)) {
            String n = searchField.getText().trim();
            ModManager.async(() -> SkinChanger.fetch(n));
            skinAt = 0;
        }
        skinSlim = toggle(ctx, "Slim arms (for files)", skinSlim, cx, fy + 28, colW, 0);
        text(ctx, "Folder: dazclient/skins", cx + colW + 14, fy + 36, cMuted);

        if (now - skinAt > 2000) {
            skinCache = SkinChanger.list();
            skinAt = now;
        }
        List<java.nio.file.Path> list = skinCache;
        int listTop = fy + 58;
        int fit = Math.max(1, (cy + ch - 46 - listTop) / 24);
        int pageCount = Math.max(1, (list.size() + fit - 1) / fit);
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));

        for (int k = 0; k < fit; k++) {
            int idx = pages[pi] * fit + k;
            if (idx >= list.size()) break;
            java.nio.file.Path p = list.get(idx);
            String name = p.getFileName().toString();
            int y = listTop + k * 24;
            card(ctx, cx, y, cw, 22, false);
            int bw = tw("Use") + 12;
            text(ctx, fit(name, cw - bw - 20), cx + 8, y + 7, cText);
            if (smallBtn(ctx, "Use", cx + cw - bw - 3, y + 3, bw)) {
                boolean slim = skinSlim || name.toLowerCase().endsWith("_slim.png");
                ModManager.async(() -> SkinChanger.apply(p, slim));
            }
        }
        if (list.isEmpty()) text(ctx, "No skins yet. Fetch one by username, or add PNG files.", cx, listTop + 6, cMuted);
        String st = SkinChanger.status;
        if (!st.isEmpty()) text(ctx, fit(st, cw), cx, cy + ch - 46, valColor());
        text(ctx, fit("Your login is sent only to Mojang's skin API when you press Use.", cw), cx, cy + ch - 34, cMuted);
        pages[pi] = pager(ctx, pages[pi], pageCount, cx, cy + ch - 22);
    }

    // ---------- boost + swap pages ----------

    private void pageBoost(DrawContext ctx, Settings s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.fpsBoost = toggle(c, "FPS Boost (auto)", s.fpsBoost, x, y, w, 0));
        l.add((c, x, y, w) -> s.fpsTarget = Math.round(slider(c, "fpst", "Target FPS", String.valueOf(s.fpsTarget),
                s.fpsTarget, 30, 240, x, y, w) / 5f) * 5);
        l.add((c, x, y, w) -> s.boostMinView = Math.round(slider(c, "bmin", "Lowest render distance",
                s.boostMinView + " chunks", s.boostMinView, 2, 16, x, y, w)));
        l.add((c, x, y, w) -> s.unfocusedLimit = toggle(c, "Limit FPS when unfocused", s.unfocusedLimit, x, y, w, 0));
        l.add((c, x, y, w) -> {
            if (button(c, "Boost now (Fast preset)", x, y, w, 24, true)) Perf.preset(mc, 0);
        });
        l.add((c, x, y, w) -> {
            String label = ModManager.busy ? "Installing..." : "Install FPS mods (Sodium...)";
            if (button(c, label, x, y, w, 24, false) && !ModManager.busy) ModManager.async(ModManager::installPerformancePack);
        });
        l.add((c, x, y, w) -> {
            card(c, x, y, w, 24, false);
            text(c, fit(ModManager.status.isEmpty() ? "FPS mods: one click, hash-checked" : ModManager.status, w - 16), x + 8, y + 8, cMuted);
        });
        l.add((c, x, y, w) -> {
            card(c, x, y, w, 24, false);
            text(c, fit("FPS " + mc.getCurrentFps() + " | Render " + Perf.getInt(mc, "view") + " | Level " + Perf.boostLevel() + "/5", w - 16),
                    x + 8, y + 8, cText);
        });
        drawControls(ctx, l,
                "Auto mode steps through 5 levels when FPS is under target: entities, particles, distance, clouds, shadows.",
                "It steps back up when FPS recovers, and restores your own settings when you turn it off.",
                "Boost now applies the Fast preset once (particles, clouds, shadows, distances).");
    }

    private void pageSwap(DrawContext ctx, Settings s) {
        List<Ctl> l = new ArrayList<>();
        l.add((c, x, y, w) -> s.swapMode = cycle(c, "Mode", new String[]{"Switch slot", "Swap items"}, s.swapMode, x, y, w));
        l.add((c, x, y, w) -> {
            card(c, x, y, w, 24, false);
            text(c, "Key A: V   |   Key B: set it in Controls", x + 8, y + 8, cMuted);
        });
        l.add((c, x, y, w) -> s.swapA1 = Math.round(slider(c, "swa1", "Swap A: first slot",
                String.valueOf(s.swapA1), s.swapA1, 1, 9, x, y, w)));
        l.add((c, x, y, w) -> s.swapA2 = Math.round(slider(c, "swa2", "Swap A: second slot",
                String.valueOf(s.swapA2), s.swapA2, 1, 9, x, y, w)));
        l.add((c, x, y, w) -> s.swapB1 = Math.round(slider(c, "swb1", "Swap B: first slot",
                String.valueOf(s.swapB1), s.swapB1, 1, 9, x, y, w)));
        l.add((c, x, y, w) -> s.swapB2 = Math.round(slider(c, "swb2", "Swap B: second slot",
                String.valueOf(s.swapB2), s.swapB2, 1, 9, x, y, w)));
        drawControls(ctx, l,
                "Switch slot: the key toggles which of the two hotbar slots you hold.",
                "Swap items: the key exchanges the two items between those slots.",
                "One key press does one action. Nothing runs automatically.");
    }

    private void pageCapes(DrawContext ctx) {
        int top = cy + 42;
        if (button(ctx, "Load my capes", cx, top, 120, 22, true)) ModManager.async(SkinChanger::loadCapes);
        if (button(ctx, "Hide cape", cx + 126, top, 90, 22, false)) ModManager.async(SkinChanger::hideCape);

        List<SkinChanger.Cape> list = SkinChanger.capes;
        int listTop = top + 28;
        int fit = Math.max(1, (cy + ch - 46 - listTop) / 24);
        int pageCount = Math.max(1, (list.size() + fit - 1) / fit);
        int pi = pageIdx();
        pages[pi] = Math.max(0, Math.min(pages[pi], pageCount - 1));
        for (int k = 0; k < fit; k++) {
            int idx = pages[pi] * fit + k;
            if (idx >= list.size()) break;
            SkinChanger.Cape cp = list.get(idx);
            int y = listTop + k * 24;
            card(ctx, cx, y, cw, 22, false);
            text(ctx, fit(cp.alias, cw - 90), cx + 8, y + 7, cText);
            if (cp.active) {
                text(ctx, "ACTIVE", cx + cw - 8 - tw("ACTIVE"), y + 7, valColor());
            } else {
                int bw = tw("Wear") + 12;
                if (smallBtn(ctx, "Wear", cx + cw - bw - 3, y + 3, bw)) {
                    String id = cp.id;
                    ModManager.async(() -> SkinChanger.wearCape(id));
                }
            }
        }
        if (list.isEmpty()) text(ctx, "Tap Load my capes. Only capes your account owns are listed.", cx, listTop + 6, cMuted);
        String st = SkinChanger.status;
        if (!st.isEmpty()) text(ctx, fit(st, cw), cx, cy + ch - 46, valColor());
        text(ctx, fit("Custom capes cannot be uploaded: Mojang does not allow it.", cw), cx, cy + ch - 34, cMuted);
        pages[pi] = pager(ctx, pages[pi], pageCount, cx, cy + ch - 22);
    }
}
