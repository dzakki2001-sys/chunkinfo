package id.unstable.smp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Zombie;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public final class BotManager {

    public static final String TAG = "unstable_bot";

    private record Bot(String name, LivingEntity entity) {}

    private final UnstableSMP pl;
    private final Random rnd = new Random();
    private final Map<String, Bot> bots = new LinkedHashMap<>();

    public BotManager(UnstableSMP pl) {
        this.pl = pl;
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (e.getScoreboardTags().contains(TAG)) e.remove();
            }
        }
    }

    public String randomName() {
        FileConfiguration c = pl.getConfig();
        List<String> pool = c.getStringList("bot.names");
        List<String> pre = c.getStringList("bot.prefixes");
        List<String> suf = c.getStringList("bot.suffixes");
        int poolChance = c.getInt("bot.pool-chance", 40);

        for (int tries = 0; tries < 50; tries++) {
            String n;
            if (!pool.isEmpty() && rnd.nextInt(100) < poolChance) {
                n = pool.get(rnd.nextInt(pool.size()));
            } else {
                String a = pre.isEmpty() ? "Player" : pre.get(rnd.nextInt(pre.size()));
                String b = suf.isEmpty() ? "" : suf.get(rnd.nextInt(suf.size()));
                n = a + b;
                if (rnd.nextBoolean()) n += rnd.nextInt(1000);
            }
            if (n.length() > 16) n = n.substring(0, 16);
            if (!bots.containsKey(n.toLowerCase())) return n;
        }
        return "Bot" + rnd.nextInt(100000);
    }

    public int spawn(Location loc, int count, String fixedName) {
        int ok = 0;
        double spread = pl.getConfig().getDouble("bot.spread", 3.0);
        boolean joinMsg = pl.getConfig().getBoolean("bot.fake-join-messages", true);

        for (int i = 0; i < count; i++) {
            String name;
            if (fixedName == null) {
                name = randomName();
            } else {
                name = count == 1 ? fixedName : fixedName + (i + 1);
                if (name.length() > 16) name = name.substring(0, 16);
                if (bots.containsKey(name.toLowerCase())) continue;
            }
            Location l = loc.clone().add((rnd.nextDouble() - 0.5) * 2 * spread, 0, (rnd.nextDouble() - 0.5) * 2 * spread);
            LivingEntity e = create(l, name);
            if (e == null) continue;
            bots.put(name.toLowerCase(), new Bot(name, e));
            ok++;
            if (joinMsg) Bukkit.broadcast(Component.text(name + " joined the game", NamedTextColor.YELLOW));
        }
        return ok;
    }

    private LivingEntity create(Location l, String name) {
        World w = l.getWorld();
        Entity ent = null;
        try {
            // Paper 1.21.9+ punya Mannequin (model pemain). Versi lama jatuh ke Zombie.
            ent = w.spawnEntity(l, EntityType.valueOf("MANNEQUIN"));
        } catch (IllegalArgumentException ignored) {
        }
        if (!(ent instanceof LivingEntity)) {
            if (ent != null) ent.remove();
            ent = w.spawnEntity(l, EntityType.ZOMBIE);
        }
        LivingEntity e = (LivingEntity) ent;

        try {
            Class<?> mc = Class.forName("org.bukkit.entity.Mannequin");
            if (mc.isInstance(ent)) {
                mc.getMethod("setDescription", Component.class).invoke(ent, (Object) null);
            }
        } catch (Throwable ignored) {
        }

        e.customName(Component.text(name));
        e.setCustomNameVisible(true);
        e.setRemoveWhenFarAway(false);
        e.setPersistent(false);
        e.addScoreboardTag(TAG);
        e.setAI(pl.getConfig().getBoolean("bot.ai", false));

        if (e instanceof Zombie z) {
            z.setBaby(false);
            z.setShouldBurnInDay(false);
            z.setSilent(true);
            e.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, PotionEffect.INFINITE_DURATION, 0, false, false));
        }
        return e;
    }

    public int clearAll(boolean announce) {
        int n = 0;
        boolean msg = announce && pl.getConfig().getBoolean("bot.fake-join-messages", true);
        for (Bot b : new ArrayList<>(bots.values())) {
            b.entity().remove();
            if (msg) Bukkit.broadcast(Component.text(b.name() + " left the game", NamedTextColor.YELLOW));
            n++;
        }
        bots.clear();
        return n;
    }

    public boolean rename(String oldName, String newName) {
        Bot b = bots.get(oldName.toLowerCase());
        if (b == null || bots.containsKey(newName.toLowerCase())) return false;
        if (newName.length() > 16) newName = newName.substring(0, 16);
        bots.remove(oldName.toLowerCase());
        b.entity().customName(Component.text(newName));
        bots.put(newName.toLowerCase(), new Bot(newName, b.entity()));
        return true;
    }

    public List<String> list() {
        List<String> out = new ArrayList<>();
        for (Bot b : bots.values()) out.add(b.name());
        return out;
    }

    public void forget(Entity e) {
        String key = null;
        String name = null;
        for (Map.Entry<String, Bot> en : bots.entrySet()) {
            if (en.getValue().entity().equals(e)) {
                key = en.getKey();
                name = en.getValue().name();
                break;
            }
        }
        if (key == null) return;
        bots.remove(key);
        if (pl.getConfig().getBoolean("bot.fake-join-messages", true)) {
            Bukkit.broadcast(Component.text(name + " left the game", NamedTextColor.YELLOW));
        }
    }
}
