package id.unstable.smp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class UnstableSMP extends JavaPlugin implements TabExecutor {

    private BotManager bots;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Items.init(this);
        bots = new BotManager(this);
        getServer().getPluginManager().registerEvents(new Listeners(this, bots), this);

        getCommand("osc").setExecutor(this);
        getCommand("osc").setTabCompleter(this);
        getCommand("nullbot").setExecutor(this);
        getCommand("nullbot").setTabCompleter(this);
        getLogger().info("UnstableSMP aktif.");
    }

    @Override
    public void onDisable() {
        if (bots != null) bots.clearAll(false);
    }

    private static void msg(CommandSender s, String text, NamedTextColor color) {
        s.sendMessage(Component.text(text, color));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("unstable.admin")) {
            msg(s, "Kamu tidak punya izin.", NamedTextColor.RED);
            return true;
        }
        if (c.getName().equalsIgnoreCase("osc")) return osc(s, a);
        return nullbot(s, a);
    }

    // ---------- /osc give <target> <item> [amount] [power] ----------

    private List<Player> resolve(CommandSender s, String sel) {
        List<Player> out = new ArrayList<>();
        if (sel.startsWith("@")) {
            try {
                for (Entity e : Bukkit.selectEntities(s, sel)) {
                    if (e instanceof Player p) out.add(p);
                }
            } catch (IllegalArgumentException ignored) {
            }
        } else {
            Player p = Bukkit.getPlayerExact(sel);
            if (p != null) out.add(p);
        }
        return out;
    }

    private boolean osc(CommandSender s, String[] a) {
        if (a.length < 3 || !a[0].equalsIgnoreCase("give")) {
            msg(s, "Pakai: /osc give <@a|nama> <item> [jumlah] [power]", NamedTextColor.YELLOW);
            msg(s, "Item: " + String.join(", ", Items.NAMES), NamedTextColor.GRAY);
            msg(s, "Power: nukeshot = radius kawah, stabshot = damage, arrowcannon = jumlah panah", NamedTextColor.GRAY);
            return true;
        }

        String type = a[2].toLowerCase(Locale.ROOT);
        if (!Items.NAMES.contains(type)) {
            msg(s, "Item tidak dikenal. Pilihan: " + String.join(", ", Items.NAMES), NamedTextColor.RED);
            return true;
        }

        int amount = 1;
        int power = Items.defaultPower(type);
        try {
            if (a.length > 3) amount = Math.max(1, Math.min(64, Integer.parseInt(a[3])));
            if (a.length > 4) power = Integer.parseInt(a[4]);
        } catch (NumberFormatException ex) {
            msg(s, "Jumlah dan power harus berupa angka.", NamedTextColor.RED);
            return true;
        }
        power = Items.clampPower(this, type, power);

        List<Player> targets = resolve(s, a[1]);
        if (targets.isEmpty()) {
            msg(s, "Target tidak ditemukan.", NamedTextColor.RED);
            return true;
        }

        for (Player t : targets) {
            for (int i = 0; i < amount; i++) {
                ItemStack it = Items.create(type, power);
                Map<Integer, ItemStack> left = t.getInventory().addItem(it);
                for (ItemStack rest : left.values()) {
                    t.getWorld().dropItemNaturally(t.getLocation(), rest);
                }
            }
        }
        msg(s, "Memberikan " + amount + "x " + type + " (power " + power + ") ke " + targets.size() + " pemain.",
                NamedTextColor.GREEN);
        return true;
    }

    // ---------- /nullbot ----------

    private boolean nullbot(CommandSender s, String[] a) {
        if (a.length == 0) {
            msg(s, "/nullbot spawn <jumlah> [nama]  - spawn bot (nama kosong = acak)", NamedTextColor.YELLOW);
            msg(s, "/nullbot clear                  - hapus semua bot", NamedTextColor.YELLOW);
            msg(s, "/nullbot list                   - daftar bot aktif", NamedTextColor.YELLOW);
            msg(s, "/nullbot rename <lama> <baru>   - ganti nama bot", NamedTextColor.YELLOW);
            msg(s, "/nullbot names <list|add|remove> [nama] - atur daftar nama acak", NamedTextColor.YELLOW);
            return true;
        }

        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "spawn" -> {
                if (!(s instanceof Player p)) {
                    msg(s, "Hanya pemain yang bisa spawn bot.", NamedTextColor.RED);
                    return true;
                }
                int n = 1;
                try {
                    if (a.length > 1) n = Math.max(1, Math.min(100, Integer.parseInt(a[1])));
                } catch (NumberFormatException ex) {
                    msg(s, "Jumlah harus angka.", NamedTextColor.RED);
                    return true;
                }
                String name = a.length > 2 ? a[2] : null;
                int made = bots.spawn(p.getLocation(), n, name);
                msg(s, made + " bot dibuat.", NamedTextColor.GREEN);
            }
            case "clear" -> msg(s, bots.clearAll(true) + " bot dihapus.", NamedTextColor.GREEN);
            case "list" -> {
                List<String> l = bots.list();
                msg(s, l.isEmpty() ? "Tidak ada bot aktif." : "Bot aktif (" + l.size() + "): " + String.join(", ", l),
                        NamedTextColor.AQUA);
            }
            case "rename" -> {
                if (a.length < 3) {
                    msg(s, "Pakai: /nullbot rename <lama> <baru>", NamedTextColor.YELLOW);
                    return true;
                }
                if (bots.rename(a[1], a[2])) msg(s, "Nama bot diganti.", NamedTextColor.GREEN);
                else msg(s, "Bot tidak ditemukan atau nama baru sudah dipakai.", NamedTextColor.RED);
            }
            case "names" -> {
                if (a.length < 2) {
                    msg(s, "Pakai: /nullbot names <list|add|remove> [nama]", NamedTextColor.YELLOW);
                    return true;
                }
                List<String> names = new ArrayList<>(getConfig().getStringList("bot.names"));
                switch (a[1].toLowerCase(Locale.ROOT)) {
                    case "list" -> msg(s, "Daftar nama: " + String.join(", ", names), NamedTextColor.AQUA);
                    case "add" -> {
                        if (a.length < 3) return true;
                        names.add(a[2]);
                        getConfig().set("bot.names", names);
                        saveConfig();
                        msg(s, "Nama '" + a[2] + "' ditambahkan.", NamedTextColor.GREEN);
                    }
                    case "remove" -> {
                        if (a.length < 3) return true;
                        boolean removed = names.removeIf(x -> x.equalsIgnoreCase(a[2]));
                        getConfig().set("bot.names", names);
                        saveConfig();
                        msg(s, removed ? "Nama dihapus." : "Nama tidak ada di daftar.",
                                removed ? NamedTextColor.GREEN : NamedTextColor.RED);
                    }
                    default -> msg(s, "Pakai: /nullbot names <list|add|remove> [nama]", NamedTextColor.YELLOW);
                }
            }
            default -> msg(s, "Subcommand tidak dikenal. Ketik /nullbot untuk bantuan.", NamedTextColor.RED);
        }
        return true;
    }

    // ---------- tab complete ----------

    private static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) if (o.toLowerCase(Locale.ROOT).startsWith(p)) out.add(o);
        return out;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        if (!s.hasPermission("unstable.admin")) return List.of();

        if (c.getName().equalsIgnoreCase("osc")) {
            if (a.length == 1) return filter(List.of("give"), a[0]);
            if (a.length == 2) {
                List<String> l = new ArrayList<>(List.of("@a", "@s", "@p"));
                for (Player p : Bukkit.getOnlinePlayers()) l.add(p.getName());
                return filter(l, a[1]);
            }
            if (a.length == 3) return filter(Items.NAMES, a[2]);
            if (a.length == 4) return filter(Arrays.asList("1", "5", "16", "64"), a[3]);
            if (a.length == 5) {
                String t = a[2].toLowerCase(Locale.ROOT);
                return List.of(String.valueOf(Items.defaultPower(t)));
            }
            return List.of();
        }

        if (a.length == 1) return filter(List.of("spawn", "clear", "list", "rename", "names"), a[0]);
        if (a.length == 2 && a[0].equalsIgnoreCase("names")) return filter(List.of("list", "add", "remove"), a[1]);
        if (a.length == 2 && a[0].equalsIgnoreCase("spawn")) return filter(List.of("1", "5", "10", "25"), a[1]);
        if (a.length == 2 && a[0].equalsIgnoreCase("rename")) return filter(bots.list(), a[1]);
        return List.of();
    }
}
