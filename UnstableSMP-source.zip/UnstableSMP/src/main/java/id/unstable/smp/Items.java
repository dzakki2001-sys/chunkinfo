package id.unstable.smp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class Items {

    public static NamespacedKey TYPE;
    public static NamespacedKey POWER;

    public static final List<String> NAMES = List.of("nukeshot", "stabshot", "arrowcannon", "pearlpull", "totem");
    public static final Set<String> CANNONS = Set.of("nukeshot", "stabshot", "arrowcannon");

    private Items() {}

    public static void init(JavaPlugin plugin) {
        TYPE = new NamespacedKey(plugin, "osc_type");
        POWER = new NamespacedKey(plugin, "osc_power");
    }

    public static int defaultPower(String type) {
        return switch (type) {
            case "nukeshot" -> 20;
            case "stabshot" -> 20;
            case "arrowcannon" -> 100;
            default -> 1;
        };
    }

    public static int clampPower(UnstableSMP pl, String type, int power) {
        return switch (type) {
            case "nukeshot" -> Math.max(5, Math.min(power, pl.getConfig().getInt("nuke.max-radius", 40)));
            case "stabshot" -> Math.max(1, Math.min(power, 1000));
            case "arrowcannon" -> Math.max(1, Math.min(power, pl.getConfig().getInt("arrow.max-arrows", 500)));
            default -> 1;
        };
    }

    private static Component text(String s, NamedTextColor color, boolean bold) {
        Component c = Component.text(s, color).decoration(TextDecoration.ITALIC, false);
        return bold ? c.decoration(TextDecoration.BOLD, true) : c;
    }

    public static ItemStack create(String type, int power) {
        boolean totem = type.equals("totem");
        Material mat = totem ? Material.TOTEM_OF_UNDYING : Material.FISHING_ROD;
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        Component name;
        List<Component> lore = new ArrayList<>();

        switch (type) {
            case "nukeshot" -> {
                name = text("Orbital Strike Cannon: Nuke Shot", NamedTextColor.RED, true);
                lore.add(text("Arahkan ke target lalu klik kanan.", NamedTextColor.GRAY, false));
                lore.add(text("Power (radius): " + power, NamedTextColor.YELLOW, false));
                lore.add(text("Sekali pakai (durability 1)", NamedTextColor.DARK_RED, false));
            }
            case "stabshot" -> {
                name = text("Stab Shot", NamedTextColor.DARK_PURPLE, true);
                lore.add(text("Tusukan lurus menembus semua target.", NamedTextColor.GRAY, false));
                lore.add(text("Power (damage): " + power, NamedTextColor.YELLOW, false));
                lore.add(text("Sekali pakai (durability 1)", NamedTextColor.DARK_RED, false));
            }
            case "arrowcannon" -> {
                name = text("Orbital Arrow Cannon", NamedTextColor.AQUA, true);
                lore.add(text("Hujan panah dari orbit ke titik target.", NamedTextColor.GRAY, false));
                lore.add(text("Power (jumlah panah): " + power, NamedTextColor.YELLOW, false));
                lore.add(text("Sekali pakai (durability 1)", NamedTextColor.DARK_RED, false));
            }
            case "pearlpull" -> {
                name = text("Pearl Pull Rod", NamedTextColor.GREEN, true);
                lore.add(text("Bidik ender pearl lalu klik kanan.", NamedTextColor.GRAY, false));
                lore.add(text("Pearl (dan pemiliknya) ditarik ke kamu.", NamedTextColor.GRAY, false));
            }
            default -> {
                name = text("Totem of Null", NamedTextColor.DARK_GRAY, true);
                lore.add(text("Pegang di tangan: kebal mati, tanpa batas.", NamedTextColor.GRAY, false));
            }
        }

        meta.displayName(name);
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(TYPE, PersistentDataType.STRING, type);
        pdc.set(POWER, PersistentDataType.INTEGER, power);

        if (CANNONS.contains(type) && meta instanceof Damageable d) {
            d.setMaxDamage(1);
            d.setDamage(0);
        }

        item.setItemMeta(meta);
        return item;
    }

    public static String type(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(TYPE, PersistentDataType.STRING);
    }

    public static int power(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return 1;
        Integer p = item.getItemMeta().getPersistentDataContainer().get(POWER, PersistentDataType.INTEGER);
        return p == null ? 1 : p;
    }
}
