package id.unstable.smp;

import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public final class Cannons {

    private static final Random RND = new Random();

    private Cannons() {}

    // ---------- helpers ----------

    private static void pf(World w, Particle p, double x, double y, double z, int n,
                           double ox, double oy, double oz, double extra) {
        w.spawnParticle(p, x, y, z, n, ox, oy, oz, extra, null, true);
    }

    private static void pd(World w, Particle p, double x, double y, double z, int n,
                           double ox, double oy, double oz, Particle.DustOptions data) {
        w.spawnParticle(p, x, y, z, n, ox, oy, oz, 0, data, true);
    }

    public static Location target(Player p, double range) {
        RayTraceResult r = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(),
                range, FluidCollisionMode.NEVER, true);
        if (r == null) return null;
        return r.getHitPosition().toLocation(p.getWorld());
    }

    // ---------- ORBITAL STRIKE CANNON: NUKE SHOT ----------

    public static void nuke(UnstableSMP pl, Player shooter, Location c, int power) {
        World w = c.getWorld();
        int radius = Math.max(5, Math.min(power, pl.getConfig().getInt("nuke.max-radius", 40)));
        int warn = Math.max(10, pl.getConfig().getInt("nuke.warning-ticks", 40));
        double topY = Math.min(w.getMaxHeight() - 1, c.getY() + 150);
        Particle.DustOptions red = new Particle.DustOptions(Color.RED, 4f);

        w.playSound(c, Sound.BLOCK_BEACON_ACTIVATE, SoundCategory.MASTER, 8f, 0.6f);

        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (t >= warn) {
                    cancel();
                    detonate(pl, shooter, c, radius);
                    return;
                }
                for (double y = c.getY(); y <= topY; y += 2) {
                    pd(w, Particle.DUST, c.getX(), y, c.getZ(), 1, 0.1, 0, 0.1, red);
                }
                double prog = (double) t / warn;
                double by = topY - (topY - c.getY()) * prog;
                pf(w, Particle.FLAME, c.getX(), by, c.getZ(), 30, 0.6, 0.6, 0.6, 0.02);
                pf(w, Particle.END_ROD, c.getX(), by, c.getZ(), 10, 0.3, 0.3, 0.3, 0.05);
                if (t % 8 == 0) {
                    w.playSound(c, Sound.BLOCK_BEACON_AMBIENT, SoundCategory.MASTER, 6f, 0.5f + (float) prog);
                }
                t++;
            }
        }.runTaskTimer(pl, 0L, 1L);
    }

    private static void detonate(UnstableSMP pl, Player shooter, Location c, int radius) {
        World w = c.getWorld();
        double cx = c.getX(), cy = c.getY(), cz = c.getZ();

        w.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.MASTER, 50f, 0.5f);
        w.playSound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.MASTER, 50f, 0.4f);
        w.playSound(c, Sound.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.MASTER, 50f, 0.5f);

        // flash + ledakan awal
        pf(w, Particle.END_ROD, cx, cy + 2, cz, 600, radius / 3.0, radius / 3.0, radius / 3.0, 0.6);
        for (int i = 0; i < 14; i++) {
            pf(w, Particle.EXPLOSION_EMITTER,
                    cx + (RND.nextDouble() - 0.5) * radius, cy + RND.nextDouble() * radius * 0.4,
                    cz + (RND.nextDouble() - 0.5) * radius, 1, 0, 0, 0, 0);
        }

        // damage entity
        double dmgR = radius * 1.8;
        boolean hurtShooter = pl.getConfig().getBoolean("nuke.hurt-shooter", true);
        for (Entity e : w.getNearbyEntities(c, dmgR, dmgR, dmgR)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (!hurtShooter && e.equals(shooter)) continue;
            double d = e.getLocation().distance(c);
            le.setNoDamageTicks(0);
            if (d <= radius * 1.2) {
                le.damage(10000, shooter);
            } else {
                le.damage(Math.max(1, 40 * (1 - d / dmgR)), shooter);
            }
            Vector kb = e.getLocation().toVector().subtract(c.toVector());
            if (kb.lengthSquared() < 0.01) kb = new Vector(0, 1, 0);
            kb.normalize().multiply(2.5).setY(0.9);
            e.setVelocity(kb);
        }

        // kawah (dihancurkan bertahap dari pusat keluar)
        int bx = c.getBlockX(), by = c.getBlockY(), bz = c.getBlockZ();
        List<Block> blocks = new ArrayList<>();
        int r2 = radius * radius;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x * x + y * y + z * z > r2) continue;
                    int wy = by + y;
                    if (wy < w.getMinHeight() || wy >= w.getMaxHeight()) continue;
                    Block b = w.getBlockAt(bx + x, wy, bz + z);
                    Material m = b.getType();
                    if (m.isAir() || m == Material.BEDROCK || m == Material.BARRIER) continue;
                    blocks.add(b);
                }
            }
        }
        blocks.sort(Comparator.comparingInt(b -> {
            int dx = b.getX() - bx, dy = b.getY() - by, dz = b.getZ() - bz;
            return dx * dx + dy * dy + dz * dz;
        }));

        int perTick = Math.max(100, pl.getConfig().getInt("nuke.blocks-per-tick", 4000));
        new BukkitRunnable() {
            int idx = 0;

            @Override
            public void run() {
                int end = Math.min(blocks.size(), idx + perTick);
                for (; idx < end; idx++) {
                    blocks.get(idx).setType(Material.AIR, false);
                }
                if (idx >= blocks.size()) cancel();
            }
        }.runTaskTimer(pl, 0L, 1L);

        // jamur nuke + gelombang kejut
        final double stemH = radius * 1.5;
        final double capR = radius * 0.8;
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (t > 70) {
                    cancel();
                    return;
                }
                double p = Math.min(1.0, t / 35.0);
                double groundY = cy;

                // gelombang kejut
                if (t <= 25) {
                    double rr = t * (radius * 2.2 / 25.0);
                    int pts = (int) Math.max(24, rr * 6);
                    for (int i = 0; i < pts; i++) {
                        double ang = 2 * Math.PI * i / pts;
                        pf(w, Particle.CLOUD, cx + Math.cos(ang) * rr, groundY + 1, cz + Math.sin(ang) * rr,
                                2, 0.3, 0.4, 0.3, 0.02);
                    }
                }

                // batang
                double stemTop = groundY + stemH * p;
                for (double y = groundY; y <= stemTop; y += 1.5) {
                    double width = radius * 0.18 * (1 + (1 - (y - groundY) / stemH) * 1.5);
                    pf(w, Particle.LARGE_SMOKE, cx, y, cz, 6, width, 0.6, width, 0.01);
                    if (y - groundY < stemH * 0.35) {
                        pf(w, Particle.FLAME, cx, y, cz, 3, width, 0.5, width, 0.02);
                    }
                }

                // tudung jamur (torus yang menggulung)
                if (p > 0.25) {
                    double q = (p - 0.25) / 0.75;
                    double a = capR * 0.65 * q;
                    double b = capR * 0.4 * q;
                    double cyCap = stemTop;
                    for (int i = 0; i < 160; i++) {
                        double th = RND.nextDouble() * 2 * Math.PI;
                        double ph = RND.nextDouble() * 2 * Math.PI;
                        double rr = a + b * Math.cos(ph);
                        double x = cx + rr * Math.cos(th);
                        double z = cz + rr * Math.sin(th);
                        double y = cyCap + b * 0.9 * Math.sin(ph);
                        if (i % 3 == 0) {
                            pf(w, Particle.FLAME, x, y, z, 1, 0, 0, 0, 0);
                        } else {
                            pf(w, Particle.LARGE_SMOKE, x, y, z, 1, 0, 0, 0, 0);
                        }
                    }
                    pf(w, Particle.FLAME, cx, cyCap, cz, 20, a * 0.5, b * 0.5, a * 0.5, 0.02);
                }
                t++;
            }
        }.runTaskTimer(pl, 0L, 2L);
    }

    // ---------- STAB SHOT ----------

    public static void stab(UnstableSMP pl, Player p, int damage) {
        World w = p.getWorld();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        double range = pl.getConfig().getDouble("stab.range", 120);

        RayTraceResult br = w.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        double len = br == null ? range : eye.toVector().distance(br.getHitPosition());

        w.playSound(eye, Sound.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 3f, 0.6f);
        w.playSound(eye, Sound.ITEM_TRIDENT_THUNDER, SoundCategory.PLAYERS, 3f, 1.4f);

        Set<UUID> hit = new HashSet<>();
        for (double d = 1.5; d <= len; d += 0.4) {
            Location l = eye.toVector().add(dir.clone().multiply(d)).toLocation(w);
            pf(w, Particle.SOUL_FIRE_FLAME, l.getX(), l.getY(), l.getZ(), 2, 0.05, 0.05, 0.05, 0.0);
            pf(w, Particle.CRIT, l.getX(), l.getY(), l.getZ(), 2, 0.1, 0.1, 0.1, 0.1);
            for (Entity e : w.getNearbyEntities(l, 1, 1, 1)) {
                if (e.equals(p) || !(e instanceof LivingEntity le)) continue;
                if (!hit.add(e.getUniqueId())) continue;
                le.setNoDamageTicks(0);
                le.damage(damage, p);
                le.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
                le.setVelocity(dir.clone().multiply(1.2).setY(0.3));
                w.playSound(e.getLocation(), Sound.ITEM_TRIDENT_HIT, SoundCategory.PLAYERS, 3f, 0.8f);
                pf(w, Particle.SWEEP_ATTACK, e.getLocation().getX(), e.getLocation().getY() + 1,
                        e.getLocation().getZ(), 3, 0.3, 0.3, 0.3, 0.0);
            }
        }

        // ujung tusukan: duri + ledakan kecil
        Location end = eye.clone().add(dir.clone().multiply(len));
        for (int s = 0; s < 10; s++) {
            Vector sd = new Vector(RND.nextDouble() - 0.5, RND.nextDouble() * 0.9, RND.nextDouble() - 0.5).normalize();
            for (double d = 0; d < 3.5; d += 0.3) {
                pf(w, Particle.END_ROD, end.getX() + sd.getX() * d, end.getY() + sd.getY() * d,
                        end.getZ() + sd.getZ() * d, 1, 0, 0, 0, 0);
            }
        }
        pf(w, Particle.ENCHANTED_HIT, end.getX(), end.getY(), end.getZ(), 40, 0.8, 0.8, 0.8, 0.3);
        w.createExplosion(end, 2f, false, false, p);
    }

    // ---------- ORBITAL ARROW CANNON ----------

    public static void arrows(UnstableSMP pl, Player shooter, Location c, int total) {
        World w = c.getWorld();
        double top = Math.min(w.getMaxHeight() - 2, c.getY() + 60);
        double radius = pl.getConfig().getDouble("arrow.radius", 7);
        Particle.DustOptions blue = new Particle.DustOptions(Color.AQUA, 3f);
        int warn = 30;

        w.playSound(c, Sound.BLOCK_BEACON_POWER_SELECT, SoundCategory.MASTER, 6f, 1.2f);

        new BukkitRunnable() {
            int t = 0;
            int spawned = 0;

            @Override
            public void run() {
                for (double y = c.getY(); y <= top; y += 2) {
                    pd(w, Particle.DUST, c.getX(), y, c.getZ(), 1, 0.1, 0, 0.1, blue);
                }
                if (t < warn) {
                    t++;
                    return;
                }
                int perTick = Math.max(1, (int) Math.ceil(total / 40.0));
                for (int i = 0; i < perTick && spawned < total; i++) {
                    double ang = RND.nextDouble() * 2 * Math.PI;
                    double rr = Math.sqrt(RND.nextDouble()) * radius;
                    Location s = new Location(w, c.getX() + Math.cos(ang) * rr, top, c.getZ() + Math.sin(ang) * rr);
                    Arrow arrow = w.spawn(s, Arrow.class, ar -> {
                        ar.setShooter(shooter);
                        ar.setCritical(true);
                        ar.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                        ar.setDamage(6);
                        ar.setVelocity(new Vector(0, -3.5, 0));
                    });
                    pl.getServer().getScheduler().runTaskLater(pl, arrow::remove, 100L);
                    spawned++;
                }
                if (t % 3 == 0) {
                    w.playSound(c, Sound.ENTITY_ARROW_SHOOT, SoundCategory.MASTER, 4f, 0.7f);
                }
                if (spawned >= total) cancel();
                t++;
            }
        }.runTaskTimer(pl, 0L, 1L);
    }

    // ---------- PEARL PULL ----------

    public static boolean pearlPull(UnstableSMP pl, Player p) {
        Location eye = p.getEyeLocation();
        Vector look = eye.getDirection();
        EnderPearl best = null;
        double bestDot = 0.96;

        for (Entity e : p.getWorld().getNearbyEntities(eye, 100, 100, 100, en -> en instanceof EnderPearl)) {
            Vector to = e.getLocation().toVector().subtract(eye.toVector());
            if (to.lengthSquared() < 4) continue;
            double dot = look.dot(to.clone().normalize());
            if (dot > bestDot) {
                bestDot = dot;
                best = (EnderPearl) e;
            }
        }
        if (best == null) return false;

        final EnderPearl pearl = best;
        p.getWorld().playSound(eye, Sound.ENTITY_FISHING_BOBBER_THROW, SoundCategory.PLAYERS, 2f, 0.8f);

        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!pearl.isValid() || !p.isOnline() || t++ > 120) {
                    cancel();
                    return;
                }
                World w = pearl.getWorld();
                Location pe = p.getLocation().add(0, 1, 0);
                Vector to = pe.toVector().subtract(pearl.getLocation().toVector());
                double d = to.length();

                // tali pancing
                Vector from = p.getEyeLocation().toVector();
                Vector line = pearl.getLocation().toVector().subtract(from);
                double ll = line.length();
                if (ll > 0.1) {
                    Vector step = line.clone().normalize();
                    for (double i = 0; i < ll; i += 1.0) {
                        Vector v = from.clone().add(step.clone().multiply(i));
                        pf(w, Particle.CRIT, v.getX(), v.getY(), v.getZ(), 1, 0, 0, 0, 0);
                    }
                }

                if (d < 2.0) {
                    if (pearl.getShooter() instanceof Player owner && owner.isOnline()) {
                        owner.teleport(p.getLocation());
                        owner.playSound(owner.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                    }
                    pearl.remove();
                    w.playSound(pe, Sound.ENTITY_FISHING_BOBBER_RETRIEVE, SoundCategory.PLAYERS, 2f, 1f);
                    cancel();
                    return;
                }
                pearl.setVelocity(to.normalize().multiply(Math.min(2.5, 0.8 + d * 0.1)));
            }
        }.runTaskTimer(pl, 0L, 1L);
        return true;
    }
}
