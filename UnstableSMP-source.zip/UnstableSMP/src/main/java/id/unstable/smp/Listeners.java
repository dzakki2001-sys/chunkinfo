package id.unstable.smp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.EntityEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class Listeners implements Listener {

    private final UnstableSMP pl;
    private final BotManager bots;

    public Listeners(UnstableSMP pl, BotManager bots) {
        this.pl = pl;
        this.bots = bots;
    }

    private void fail(Player p, String msg) {
        p.sendActionBar(Component.text(msg, NamedTextColor.RED));
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.6f);
    }

    private void consume(Player p, EquipmentSlot hand) {
        p.getEquipment().setItem(hand, null);
        p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = e.getItem();
        String type = Items.type(item);
        if (type == null || type.equals("totem")) return;

        e.setCancelled(true);
        Player p = e.getPlayer();
        EquipmentSlot hand = e.getHand();
        if (hand == null) return;
        int power = Items.power(item);

        switch (type) {
            case "nukeshot" -> {
                Location t = Cannons.target(p, 300);
                if (t == null) {
                    fail(p, "Arahkan ke blok (maks 300 blok).");
                    return;
                }
                consume(p, hand);
                Cannons.nuke(pl, p, t, power);
            }
            case "arrowcannon" -> {
                Location t = Cannons.target(p, 300);
                if (t == null) {
                    fail(p, "Arahkan ke blok (maks 300 blok).");
                    return;
                }
                consume(p, hand);
                Cannons.arrows(pl, p, t, power);
            }
            case "stabshot" -> {
                consume(p, hand);
                Cannons.stab(pl, p, power);
            }
            case "pearlpull" -> {
                if (p.hasCooldown(Material.FISHING_ROD)) return;
                p.setCooldown(Material.FISHING_ROD, 20);
                if (!Cannons.pearlPull(pl, p)) {
                    fail(p, "Tidak ada ender pearl di arah bidikanmu.");
                }
            }
            default -> {
            }
        }
    }

    // Totem of Null: kebal mati selama dipegang (tangan utama / offhand), tanpa batas pemakaian
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (p.getHealth() - e.getFinalDamage() > 0) return;
        if (!hasNullTotem(p)) return;

        e.setCancelled(true);
        var maxAttr = p.getAttribute(Attribute.MAX_HEALTH);
        p.setHealth(maxAttr == null ? 20.0 : maxAttr.getValue());
        p.setFireTicks(0);
        p.setNoDamageTicks(40);
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1));
        p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 1));
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 4));
        p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 200, 0));

        Location l = p.getLocation().add(0, 1, 0);
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, l, 80, 0.5, 1, 0.5, 0.4);
        p.getWorld().spawnParticle(Particle.SQUID_INK, l, 40, 0.5, 1, 0.5, 0.1);
        p.getWorld().playSound(l, Sound.ITEM_TOTEM_USE, 1f, 0.6f);
        p.playEffect(EntityEffect.PROTECTED_FROM_DEATH);
    }

    private boolean hasNullTotem(Player p) {
        return "totem".equals(Items.type(p.getInventory().getItemInMainHand()))
                || "totem".equals(Items.type(p.getInventory().getItemInOffHand()));
    }

    @EventHandler
    public void onBotDeath(EntityDeathEvent e) {
        LivingEntity le = e.getEntity();
        if (!le.getScoreboardTags().contains(BotManager.TAG)) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        bots.forget(le);
    }
}
